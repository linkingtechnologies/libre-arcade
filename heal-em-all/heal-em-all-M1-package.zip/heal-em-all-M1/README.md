# Heal'em All (M1 archaeological recovery, not yet playable here)

Status: **M1 complete, publication blocked.** Not linked from the arcade index. Start with [`M1-ARCHAEOLOGICAL-REPORT.md`](M1-ARCHAEOLOGICAL-REPORT.md).

Original: <https://github.com/krzysu/game-off-2013> by Krzysztof Urbas (code, story) and Paweł Madeja (graphics), GitHub Game Off 2013.

| Folder | Contents |
|---|---|
| `reference/` | Frozen upstream snapshot (bundle, trees, tars, git logs, GitHub API evidence). Never edit. Contains the 14 **quarantined audio files**: do not copy them into any build. |
| `evidence/` | Baseline results: fixed-step probe, real-time Chrome run, request log, screenshots, muted-start experiment. |
| `tools/` | Baseline server, probes, manifest/inventory generators. Dev tooling only. |

Reproduce:

```powershell
node tools/make-manifest.mjs --verify                 # snapshot checksums
node tools/serve-baseline.mjs 8765                    # unmodified original at http://127.0.0.1:8765/
# real-time run (needs a playwright-core install, kept outside the repo):
$env:PLAYWRIGHT_CORE = "<path>\node_modules\playwright-core"; node tools/realtime-baseline.mjs
```

Code is GPL-3.0 and the graphics CC BY 4.0 (declared upstream); audio is unresolved. See [`LICENSE-AUDIT.md`](LICENSE-AUDIT.md).
