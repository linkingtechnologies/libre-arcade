#!/usr/bin/env node
// SPDX-License-Identifier: GPL-3.0-or-later
// Generates SOURCE-MANIFEST.json (SHA-256 of every preserved upstream file + archive checksums) and
// ASSET-INVENTORY.csv. `--verify` recomputes the snapshot checksums and fails on any mismatch.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const ref = join(root, "reference");
const sha = b => createHash("sha256").update(b).digest("hex");
const walk = d => readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(join(d, e.name)) : [join(d, e.name)]);
function tree(dir) {
  const files = walk(dir).map(p => relative(dir, p).split("\\").join("/")).sort().map(p => ({ path: p, bytes: statSync(join(dir, p)).size, sha256: sha(readFileSync(join(dir, p))) }));
  const treeChecksum = sha(files.map(f => `${f.sha256}  ${f.path}\n`).join(""));
  return { files, treeChecksum };
}
const master = tree(join(ref, "upstream-master")), pages = tree(join(ref, "upstream-gh-pages"));
const archives = Object.fromEntries(["game-off-2013.bundle", "upstream-master-66950cd.tar", "upstream-gh-pages-2f8629d.tar"].map(n => [n, { bytes: statSync(join(ref, n)).size, sha256: sha(readFileSync(join(ref, n))) }]));
const prev = existsSync(join(root, "SOURCE-MANIFEST.json")) ? JSON.parse(readFileSync(join(root, "SOURCE-MANIFEST.json"), "utf8")) : null;
if (process.argv.includes("--verify")) {
  const ok = prev && prev.snapshot.masterTreeChecksum === master.treeChecksum && prev.snapshot.ghPagesTreeChecksum === pages.treeChecksum && JSON.stringify(prev.archives) === JSON.stringify(archives);
  console.log(ok ? "OK: reference snapshot matches SOURCE-MANIFEST.json" : "MISMATCH"); process.exit(ok ? 0 : 1);
}
const manifest = {
  schema: 1,
  generatedBy: "heal-em-all/tools/make-manifest.mjs",
  upstream: {
    url: "https://github.com/krzysu/game-off-2013", owner: "krzysu (Krzysztof Urbas)",
    creators: ["Krzysztof Urbas (programming, story)", "Pawel Madeja (graphics)"],
    selectedCommit: "66950cda39d2b91f114dcf1a0b0307972f24a68f", selectedCommitDate: "2019-07-24T17:41:42+02:00",
    selectedCommitSubject: "Clarify licensing and add GPL license (#1)",
    lastGameplayCommit: "e148bc56b8540b0b2ccf13174f61b72fbe9c738a (2013-12-02, typo + google analytics)",
    ghPagesCommit: "2f8629d385736a567ca84b775e3423f2064fa13e (2013-12-01, deploy)",
    developmentPeriod: "2013-10-14 (GitHub Game Off template commit) / 2013-10-30 (repo created) to 2013-12-02 (last game change); relicensing commit 2019-07-24",
    commitsAllRefs: 119, authors: { "Krzysztof Urbas": 103, "Lee Reilly": 14, "kmcnaught": 1, "pawelmadeja": 1 },
    fetchedOn: "2026-11-22",
  },
  snapshot: { masterDir: "reference/upstream-master", ghPagesDir: "reference/upstream-gh-pages", masterFiles: master.files.length, ghPagesFiles: pages.files.length,
    masterTreeChecksum: master.treeChecksum, ghPagesTreeChecksum: pages.treeChecksum,
    treeChecksumMethod: "sha256 over lines '<file sha256>  <path>\n', paths sorted bytewise, '/' separators, bytes exactly as committed (CRLF preserved)" },
  archives, masterFiles: master.files, ghPagesFiles: pages.files,
};
writeFileSync(join(root, "SOURCE-MANIFEST.json"), JSON.stringify(manifest, null, 1) + "\n");
console.log("manifest written:", master.files.length, "master files;", master.treeChecksum);
