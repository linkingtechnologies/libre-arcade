/* 
 * Copyright (C) 2011 Jasen Borisov
 * 
 * File created on 13.03.2011 at 13:44:38 EAT.
 * 
 * This file (Strings.java) is part of Project TAJJAVA.
 * 
 * Project TAJJAVA is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License (GNU AGPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Project TAJJAVA is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License (GNU AGPL) for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License (GNU AGPL) along with
 * Project TAJJAVA. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjava.l10n;

import java.util.ListResourceBundle;

/**
 * @author Jasen Borisov
 */
public class Strings extends ListResourceBundle {
	@Override
	protected Object[][] getContents() {
		return new String[][] {
				{"MENU_TITLE"       ,"TAJJAVA Main Menu - Select Game"},
				{"GRID_TITLE"       ,"TAJJAVA - 100-Square Challenge"},
				{"GRID_BUTTON"      ,"100-Square Challenge"},
				{"BUTTON_NEWGAME"   ,"Start New Game"},
				{"BUTTON_UNDOMOVE"  ,"Undo Last Move"},
				{"BUTTON_BACKTOMENU","Back to Main Menu"}
		};
	}
}
