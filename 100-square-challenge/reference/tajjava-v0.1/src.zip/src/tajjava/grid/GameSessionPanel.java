/* 
 * Copyright (C) 2011 Jasen Borisov
 * 
 * File created on 17.03.2011 at 16:10:14 EAT.
 * 
 * This file (GameSessionPanel.java) is part of Project TAJJAVA.
 * 
 * Project TAJJAVA is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License (GNU AGPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Project TAJJAVA is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License (GNU AGPL) for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License (GNU AGPL) along with
 * Project TAJJAVA. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjava.grid;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

import tajjava.LauncherMain;

/**
 * @author Jasen Borisov
 */
public class GameSessionPanel extends JPanel implements ActionListener {
	Square[][] grid;
	Point plsq;
	Point lastsq;
	boolean gended;
	JButton undobutton;
	
	public GameSessionPanel(){
		setLayout(new GridBagLayout());
		setBackground(Color.black);
		setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
		
		GridBagConstraints gbc = new GridBagConstraints();
		
		JPanel p;
		
		p = new JPanel(new GridLayout(10,10,-1,-1));
		p.setBackground(Color.black);
		p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
		grid = new Square[10][10];
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				grid[j][i] = new Square(this);
				p.add(grid[j][i]);
			}
		}
		grid[0][0].proposed = true;
		plsq = lastsq = new Point(0, 0);
		gbc.gridx = gbc.gridy = 0;
		gbc.weightx = gbc.weighty = 1;
		gbc.fill = GridBagConstraints.BOTH;
		add(p, gbc);
		
		p = new JPanel();
		p.setBackground(Color.black);
		JButton b;
		b = new JButton(LauncherMain.strb.getString("BUTTON_NEWGAME"));
		b.setActionCommand("newgame");
		b.addActionListener(this);
		p.add(b);
		b = new JButton(LauncherMain.strb.getString("BUTTON_UNDOMOVE"));
		b.setActionCommand("undomove");
		b.addActionListener(this);
		undobutton = b;
		p.add(b);
		b = new JButton(LauncherMain.strb.getString("BUTTON_BACKTOMENU"));
		b.setActionCommand("backtomenu");
		b.addActionListener(this);
		p.add(b);
		gbc.gridy = 1;
		gbc.weighty = 0;
		add(p, gbc);
	}
	
	public void proposeSquares() {
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				if(grid[j][i].proposed){
					grid[j][i].proposed = false;
					grid[j][i].repaint();
				}
			}
		}
		boolean gameend = false;
		if (lastsq.x >= 1 && lastsq.y >= 2) {
			gameend |= grid[lastsq.x - 1][lastsq.y - 2].propose();
		}
		if (lastsq.x <= 8 && lastsq.y >= 2) {
			gameend |= grid[lastsq.x + 1][lastsq.y - 2].propose();
		}
		if (lastsq.x >= 1 && lastsq.y <= 7) {
			gameend |= grid[lastsq.x - 1][lastsq.y + 2].propose();
		}
		if (lastsq.x <= 8 && lastsq.y <= 7) {
			gameend |= grid[lastsq.x + 1][lastsq.y + 2].propose();
		}
		if (lastsq.x >= 2 && lastsq.y >= 1) {
			gameend |= grid[lastsq.x - 2][lastsq.y - 1].propose();
		}
		if (lastsq.x >= 2 && lastsq.y <= 8) {
			gameend |= grid[lastsq.x - 2][lastsq.y + 1].propose();
		}
		if (lastsq.x <= 7 && lastsq.y >= 1) {
			gameend |= grid[lastsq.x + 2][lastsq.y - 1].propose();
		}
		if (lastsq.x <= 7 && lastsq.y <= 8) {
			gameend |= grid[lastsq.x + 2][lastsq.y + 1].propose();
		}
		gended = !gameend;
	}
	
	public void reset(){
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				grid[j][i].reset();
			}
		}
		grid[0][0].proposed = true;
		plsq = lastsq = new Point(0, 0);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("backtomenu")){
			LauncherMain.mainframe.setContentPane(LauncherMain.menu);
			LauncherMain.mainframe.setResizable(false);
			LauncherMain.mainframe.pack();
			LauncherMain.mainframe.setLocationRelativeTo(null);
			LauncherMain.mainframe.validate();
		}
		if(e.getActionCommand().equals("undomove")){
			if(plsq != lastsq){
				grid[lastsq.x][lastsq.y].value = 0;
				grid[lastsq.x][lastsq.y].repaint();
				lastsq = plsq;
				grid[lastsq.x][lastsq.y].repaint();
				proposeSquares();
				undobutton.setEnabled(false);
			}
		}
		if(e.getActionCommand().equals("newgame")){
			reset();
		}
	}
}
