/* 
 * Copyright (C) 2011 Jasen Borisov
 * 
 * File created on 17.03.2011 at 19:20:53 EAT.
 * 
 * This file (Square.java) is part of Project TAJJAVA.
 * 
 * Project TAJJAVA is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License (GNU AGPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Project TAJJAVA is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License (GNU AGPL) for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License (GNU AGPL) along with
 * Project TAJJAVA. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjava.grid;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComponent;

import tajjava.CoreGraphics;

/**
 * @author Jasen Borisov
 */
public class Square extends JComponent implements MouseListener {
	
	GameSessionPanel parent;
	boolean proposed;
	int value;
	
	public Square(GameSessionPanel p){
		addMouseListener(this);
		parent = p;
		proposed = false;
		value = 0;
	}
	
	public boolean propose(){
		if(value == 0){
			proposed = true;
			repaint();
			return true;
		}
		return false;
	}

	@Override
	public void paintComponent(Graphics gr){
		Graphics2D g = (Graphics2D)gr;
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_GASP);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		
		g.setColor(Color.gray);
		if (proposed) {
			g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, getWidth()/2, getHeight()/2);
		}
		
		g.setColor(Color.white);
		g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, getWidth()/2, getHeight()/2);
		
		if (value > 0) {
			if (parent.grid[parent.lastsq.x][parent.lastsq.y] == this) {
				g.setColor(new Color(255, 0, 0));
			}
			else {
				g.setColor(new Color(127, 128, 127));
			}
			g.setFont(new Font("Serif", Font.BOLD, (int)(Math.min(getWidth(), getHeight()) / 2)));
			CoreGraphics.drawCenterText(0, getWidth(), 0, getHeight(), "" + value, g);
		}
	}
	@Override
	public Dimension getPreferredSize(){
		return new Dimension(32,32);
	}
	public void reset(){
		proposed = false;
		value = 0;
		repaint();
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(parent.gended)parent.reset();
		if(proposed){
			value = parent.grid[parent.lastsq.x][parent.lastsq.y].value+1;
			parent.grid[parent.lastsq.x][parent.lastsq.y].repaint();
			for (int i = 0; i < parent.grid.length; i++) {
				for (int j = 0; j < parent.grid[i].length; j++) {
					if(parent.grid[j][i] == this){
						parent.plsq = parent.lastsq;
						parent.lastsq = new Point(j, i);
						parent.undobutton.setEnabled(true);
					}
				}
			}
			parent.proposeSquares();
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
	}
	@Override
	public void mouseReleased(MouseEvent e) {
	}
	@Override
	public void mouseEntered(MouseEvent e) {
	}
	@Override
	public void mouseExited(MouseEvent e) {
	}
}
