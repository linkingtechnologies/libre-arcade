/* 
 * Copyright (C) 2011 Jasen Borisov
 * 
 * File created on 15.03.2011 at 17:25:20 EAT.
 * 
 * This file (CoreGraphics.java) is part of Project TAJJAVA.
 * 
 * Project TAJJAVA is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License (GNU AGPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Project TAJJAVA is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License (GNU AGPL) for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License (GNU AGPL) along with
 * Project TAJJAVA. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjava;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

/**
 * This class contains the graphics processing methods of TAJJAVA.
 * 
 * @author Jasen Borisov
 */
public class CoreGraphics {

	/**
	 * @param i
	 *            the image
	 * @return the Dimension (size) of i
	 */
	public static Dimension getImageDimensions(BufferedImage i) {
		return new Dimension(i.getWidth(), i.getHeight());
	}

	/**
	 * Create a new identical BufferedImage.
	 * 
	 * @param src
	 *            the source image
	 * @return an identical image to src
	 */
	public static BufferedImage duplicateImage(BufferedImage src) {
		BufferedImage toret = new BufferedImage(src.getWidth(),
				src.getHeight(), BufferedImage.TYPE_INT_ARGB);
		toret.getGraphics().drawImage(src, 0, 0, null);
		return toret;
	}

	/**
	 * Colorize a raster.
	 * 
	 * @param d
	 *            the raster to work on.
	 * @param cv
	 *            the color values as an int array in the format of the raster.
	 */
	public static void colorizeRaster(WritableRaster d, int[] cv) {
		for (int i = 0; i < d.getHeight(); i++) {
			for (int j = 0; j < d.getWidth(); j++) {
				int[] a;
				a = d.getPixel(j, i, new int[4]);
				for (int k = 0; k < a.length; k++) {
					if (k < cv.length) {
						a[k] *= cv[k] / 255.0;
					}
				}
				d.setPixel(j, i, a);
			}
		}
	}

	/**
	 * Change the brightness of a raster.
	 * 
	 * @param d
	 *            the raster to work on.
	 * @param f
	 *            the multiplier for the brightness.
	 */
	public static void brighten(WritableRaster d, double f) {
		for (int i = 0; i < d.getHeight(); i++) {
			for (int j = 0; j < d.getWidth(); j++) {
				int[] a;
				a = d.getPixel(j, i, new int[4]);
				for (int k = 0; k < 3; k++) {
					if (a[k] * f < 255 && a[k] * f > 0) {
						a[k] *= f;
					}
					if (a[k] * f <= 0) {
						a[k] = 0;
					}
					if (a[k] * f >= 255) {
						a[k] = 255;
					}
				}
				d.setPixel(j, i, a);
			}
		}
	}
	
	public static void drawCenterText(int x1, int x2, int y1, int y2, String s,
			Graphics g) {
		FontMetrics m = g.getFontMetrics();
		int adv = m.stringWidth(s);
		int h = m.getHeight();
		int d = m.getAscent() - h/2;
		g.drawString(s, Math.min(x2, x1)
				+ (Math.max(x2, x1) - Math.min(x2, x1)) / 2 - adv / 2, Math.min(y2, y1)+(Math.max(y2, y1) - Math.min(y2, y1))/2 + d);
	}
}
