/* 
 * Copyright (C) 2011 Jasen Borisov
 * 
 * File created on 16.03.2011 at 23:06:21 EAT.
 * 
 * This file (LauncherMain.java) is part of Project TAJJAVA.
 * 
 * Project TAJJAVA is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License (GNU AGPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Project TAJJAVA is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License (GNU AGPL) for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License (GNU AGPL) along with
 * Project TAJJAVA. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjava;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * @author Jasen Borisov
 */
public class LauncherMain implements ActionListener {
	
	static LauncherMain myself = new LauncherMain();
	
	public static JPanel menu;
	static tajjava.grid.GameSessionPanel grid;
	public static JFrame mainframe;
	
	public static ResourceBundle strb = ResourceBundle.getBundle("tajjava.l10n.Strings");
	
	public static void makeGUI(){
		grid = new tajjava.grid.GameSessionPanel();
		
		menu = new JPanel();
		menu.setBackground(Color.black);
		JButton b;
		b = new JButton(strb.getString("GRID_BUTTON"));
		b.setActionCommand("setgrid");
		b.addActionListener(myself);
		menu.add(b);
		
		mainframe = new JFrame(strb.getString("MENU_TITLE"));
		mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainframe.setContentPane(menu);
		mainframe.setResizable(false);
		mainframe.pack();
		mainframe.setLocationRelativeTo(null);
		mainframe.setVisible(true);
	}
	
	public static void main(String[] args) {
		try {
			SwingUtilities.invokeAndWait(new Runnable(){
				@Override
				public void run() {
					makeGUI();
				}
			});
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("setgrid")){
			mainframe.setContentPane(grid);
			mainframe.setResizable(true);
			mainframe.pack();
			mainframe.setLocationRelativeTo(null);
			mainframe.validate();
		}
	}
}
