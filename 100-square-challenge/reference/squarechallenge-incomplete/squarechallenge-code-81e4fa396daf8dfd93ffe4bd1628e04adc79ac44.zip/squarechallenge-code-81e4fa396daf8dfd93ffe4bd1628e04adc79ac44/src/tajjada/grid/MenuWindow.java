/*
 * Copyright (C) 2011 Jasen Borisov
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjada.grid;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * This window should be displayed at startup. It contains buttons for launching
 * other windows.
 * 
 * @author Jasen Borisov
 */
public class MenuWindow extends JFrame implements ActionListener {

    /**
     * Create the frame and its interface.
     */
    public MenuWindow() {
        // The main panel.
        JPanel mp = new JPanel();

        // Create the buttons.
        JButton b;
        b = new JButton(SharedSettings.strb.getString("btn_play"));
        b.setActionCommand("play");
        b.addActionListener(this);
        mp.add(b);
        b = new JButton(SharedSettings.strb.getString("btn_config"));
        b.setActionCommand("config");
        b.addActionListener(this);
        mp.add(b);

        // Set the main panel as the frame's content pane.
        setContentPane(mp);

        // Set the frame's size.
        pack();

        // Set the frame's title.
        setTitle(SharedSettings.strb.getString("menu_title"));

        // This is the main window of the application; it should quit when
        // closed.
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // If the play button is pressed.
        if (e.getActionCommand().equals("play")) {
            // TODO show the game window when it is complete.
        }

        // If the config button is pressed.
        if (e.getActionCommand().equals("config")) {
            AppMain.confw.setVisible(true);
        }
    }

}
