/*
 * Copyright (C) 2011 Jasen Borisov
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjada.grid;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * This is the class for the configuration window used to change the game
 * settings.
 * 
 * @author Jasen Borisov
 */
public class ConfigWindow extends JFrame implements ActionListener {

    /**
     * The text field where the user inputs the grid width.
     */
    JTextField widthField;
    /**
     * The text field where the user inputs the grid height.
     */
    JTextField heightField;

    /**
     * Create the frame and its interface.
     */
    public ConfigWindow() {
        // Define some panels to use for laying out GUI.
        JPanel p1, p2;

        // Define the GridBag constraints to use for GridBagLayout panels.
        GridBagConstraints gbc, igbc;
        // Create the main GridBagConstraints.
        gbc = new GridBagConstraints();
        // Create the GridBagConstraints for the internal panels.
        igbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;

        // Create the top panel.
        p1 = new JPanel(new GridBagLayout());
        p1.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));

        // Create the first inner panel (grid size settings).
        p2 = new JPanel(new GridBagLayout());
        p2.setBorder(BorderFactory.createTitledBorder(SharedSettings.strb
                .getString("gridsz_panel_title")));

        // Add labels.
        igbc.anchor = GridBagConstraints.LINE_END;
        p2.add(new JLabel(SharedSettings.strb.getString("width") + ": "), igbc);
        igbc.gridy = 1;
        p2.add(new JLabel(SharedSettings.strb.getString("height") + ": "), igbc);

        // Add the text fields.
        igbc.anchor = GridBagConstraints.LINE_START;
        igbc.gridx = 1;
        igbc.gridy = 0;
        widthField = new JTextField(SharedSettings.gridSize.width + "", 4);
        widthField.setActionCommand("changeWidth");
        widthField.addActionListener(this);
        p2.add(widthField, igbc);
        igbc.gridy = 1;
        heightField = new JTextField(SharedSettings.gridSize.height + "", 4);
        heightField.setActionCommand("changeHeight");
        heightField.addActionListener(this);
        p2.add(heightField, igbc);

        // Add the inner panel to the top panel.
        gbc.weighty = 0;
        p1.add(p2, gbc);

        // Create the second inner panel (starting point settings).
        p2 = new JPanel();
        p2.setBorder(BorderFactory.createTitledBorder(SharedSettings.strb
                .getString("startpoint_panel_title")));

        // TODO create and add components to the panel.

        // Add the inner panel to the top panel.
        gbc.gridy = 1;
        gbc.weighty = 1;
        p1.add(p2, gbc);

        // Set the top panel as the frame's content pane.
        setContentPane(p1);

        // Set the size of the frame.
        pack();

        // Set the frame's title.
        setTitle(SharedSettings.strb.getString("config_title"));
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(ActionEvent arg0) {
        // If width has changed.
        if (arg0.getActionCommand().equals("changeWidth")) {
            SharedSettings.gridSize =
                new Dimension(Integer.parseInt(widthField.getText()),
                        SharedSettings.gridSize.height);
        }

        // If height has changed.
        if (arg0.getActionCommand().equals("changeHeight")) {
            SharedSettings.gridSize =
                new Dimension(SharedSettings.gridSize.width,
                        Integer.parseInt(heightField.getText()));
        }
    }

}
