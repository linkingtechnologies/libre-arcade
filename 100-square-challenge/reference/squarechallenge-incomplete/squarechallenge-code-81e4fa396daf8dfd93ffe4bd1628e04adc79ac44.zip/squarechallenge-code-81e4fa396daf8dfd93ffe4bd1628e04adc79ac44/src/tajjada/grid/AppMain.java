/*
 * Copyright (C) 2011 Jasen Borisov
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjada.grid;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * This is the main class for the 100-square challenge game. This class controls
 * the windows of the game.
 * 
 * @author Jasen Borisov
 */
public class AppMain {

    /**
     * The window with the main menu that is displayed on startup.
     */
    public static MenuWindow menu;
    /**
     * The window with the game settings.
     */
    public static ConfigWindow confw;

    /**
     * Create the application's GUI.
     */
    public static void makeAndShowGUI() {
        // We want to use the system look and feel.
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        // Create and show the main menu window.
        menu = new MenuWindow();
        menu.setLocationRelativeTo(null);
        menu.setVisible(true);

        // Create the settings window. It will be shown by an action event.
        confw = new ConfigWindow();
        confw.setLocationRelativeTo(null);
    }

    /**
     * The main method of the application.
     * 
     * @param args
     *            unused in our application.
     */
    public static void main(String[] args) {
        // Create the GUI on the proper Swing thread.
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                makeAndShowGUI();
            }
        });
    }
}
