/*
 * Copyright (C) 2011 Jasen Borisov
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjada.grid;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ResourceBundle;

/**
 * This class should only contain static fields for game settings to be shared
 * between other classes.
 * 
 * @author Jasen Borisov
 */
public class SharedSettings {

    /**
     * The size of the game grid.
     */
    public static Dimension gridSize = new Dimension(10, 10);
    /**
     * The starting point of the game.
     */
    public static Point startingPoint = new Point(0, 0);
    /**
     * The resource bundle with the localized strings.
     */
    public static ResourceBundle strb = ResourceBundle
    .getBundle("tajjada.grid.l10n.Strings");
}
