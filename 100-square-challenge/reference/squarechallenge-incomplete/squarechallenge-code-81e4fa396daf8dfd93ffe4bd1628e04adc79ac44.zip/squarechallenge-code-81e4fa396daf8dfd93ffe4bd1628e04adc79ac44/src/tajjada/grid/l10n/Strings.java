/*
 * Copyright (C) 2011 Jasen Borisov
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjada.grid.l10n;

import java.util.ListResourceBundle;

/**
 * This class contains the default (English) translations of the text strings in
 * the game.
 * 
 * @author Jasen Borisov
 */
public class Strings extends ListResourceBundle {

    /*
     * (non-Javadoc)
     * 
     * @see java.util.ListResourceBundle#getContents()
     */
    @Override
    protected Object[][] getContents() {
        return new String[][] {
                {
                    "btn_play",
                    "Play"
                },
                {
                    "btn_config",
                    "Settings"
                },
                {
                    "menu_title",
                    "Main Menu - 100-Square Challenge"
                },
                {
                    "gridsz_panel_title",
                    "Grid Size"
                },
                {
                    "config_title",
                    "Game Settings - 100-Square Challenge"
                },
                {
                    "startpoint_panel_title",
                    "Starting Point"
                },
                {
                    "width",
                    "Width"
                },
                {
                    "height",
                    "Height"
                }
        };
    }

}
