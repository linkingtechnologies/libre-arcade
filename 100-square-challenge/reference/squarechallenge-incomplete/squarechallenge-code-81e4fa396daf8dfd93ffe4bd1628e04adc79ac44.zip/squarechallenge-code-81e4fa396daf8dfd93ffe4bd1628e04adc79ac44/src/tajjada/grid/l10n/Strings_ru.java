/*
 * Copyright (C) 2011 Jasen Borisov
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

package tajjada.grid.l10n;

import java.util.ListResourceBundle;

/**
 * This class contains the Russian translations of the text strings in the game.
 * 
 * @author Jasen Borisov
 */
public class Strings_ru extends ListResourceBundle {

    /*
     * (non-Javadoc)
     * 
     * @see java.util.ListResourceBundle#getContents()
     */
    @Override
    protected Object[][] getContents() {
        return new String[][] {
                {
                    "btn_play",
                    "Играть"
                },
                {
                    "btn_config",
                    "Настройки"
                },
                {
                    "menu_title",
                    "Главное Меню - 100-квадратная задачка"
                },
                {
                    "gridsz_panel_title",
                    "Размер сетки"
                },
                {
                    "config_title",
                    "Настройки игры - 100-квадратная задачка"
                },
                {
                    "startpoint_panel_title",
                    "Начальная точка"
                },
                {
                    "width",
                    "Ширина"
                },
                {
                    "height",
                    "Высота"
                }
        };
    }

}
