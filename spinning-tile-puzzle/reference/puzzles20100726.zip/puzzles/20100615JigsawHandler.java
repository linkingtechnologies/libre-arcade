/**
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Changelog:
 * 2010 06 14 Jon
 * Worked out tile placement issues. Tiles are now randomly scattered on the board.
 * Added focus request on mousedown.
 * 
 * 2010 06 11 - Jon
 * Abstracted tilemanager creation code to NewPuzzleDialog
 * This class now communicates with PuzzleCanvas, rather than GUI
 */
import java.awt.Dimension;
import java.util.Random;
import java.awt.geom.AffineTransform;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.Point;
import java.awt.Rectangle;
import hulka.event.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import hulka.tilemanager.TileManager;

import java.util.Arrays;

public class JigsawHandler implements PuzzleHandler, MouseSensetiveShapeListener, MouseListener, MouseMotionListener, KeyListener
{
	PuzzleCanvas ui;
	private TileManager tileManager;
	private Random random=new Random();

	private int errMargin = 2;
	private int snapThreshold = 5;

	//For drawing, tileSize includes margin
	int tileSize, tileMargin;
	//For placement, margin not included
	int tileHeight,tileWidth,tileSpacingX,tileSpacingY;
	
	//z-ordering
	private int [] zIndices;
	//Connected tile set index
	private int [] connectedIndex;
	private int [] connectedTileCount;

	//Event handling
	private MouseSensetiveShapeManager boardManager;
	private MouseSensetiveTile [] tiles;
	
	//for drag operations
	private MouseSensetiveTile dragTile = null;
	private int mouseX,mouseY;
	//for tracking drag operations
	private Rectangle dragBounds=new Rectangle();
	//for temporary storage - should not be used by a function that is initializing bounds
	private Rectangle tempBounds=new Rectangle();
	private Rectangle tempBounds2=new Rectangle();
	//for very short-term storage - any function could change this
	private Rectangle immedBounds=new Rectangle();

	//related to snapping sets of tiles together
	private int [] snapSets = null;
	private Point [] snapOffsets = null;
	
	private Point tempPosition = new Point();

	private Dimension boardSize = null;
	
	public JigsawHandler(TileManager tileManager)
	{
		this.tileManager=tileManager;
	}
	
	public void connect(PuzzleCanvas canvas)
	{
		ui=canvas;
		boardSize=ui.getSize(boardSize);
		tempBounds.x=0;
		tempBounds.y=0;
		tempBounds.width=boardSize.width;
		tempBounds.height=boardSize.height;
		ui.erase(tempBounds);
		setupTiles();
		drawAllTiles();
		ui.setBuffers(tileSize,errMargin);
		ui.addMouseListener(this);
		ui.addMouseListener(boardManager);
		ui.addMouseMotionListener(this);
		ui.addKeyListener(this);
	}
	
	public void disconnect()
	{
		ui.removeMouseListener(this);
		ui.removeMouseListener(boardManager);
		ui.removeMouseMotionListener(this);
		ui.removeKeyListener(this);
		ui.clearBuffers();
	}

	private void setupTiles()
	{
		tiles = new MouseSensetiveTile [tileManager.getTileCount()];
		zIndices = new int[tiles.length];
		connectedIndex = new int[tiles.length];
		connectedTileCount = new int[tiles.length];
		tileMargin = tileManager.getTileMargin();

		tileWidth = tileManager.getTileWidth();
		tileHeight = tileManager.getTileHeight();
		tileSpacingX = tileManager.getTileSpacingX();
		tileSpacingY = tileManager.getTileSpacingY();
		int rotationSteps  = tileManager.getRotationSteps();
		tileSize = (tileHeight>tileWidth ? tileHeight : tileWidth) + tileMargin*2;
		
		for(int i =0; i < zIndices.length; i++)
		{
			zIndices[i] = i;
			connectedIndex[i] = i;
			connectedTileCount[i] = 1;
		}
		
		//Randomize the zIndices
		for(int i =0; i < zIndices.length; i++)
		{
			int t = zIndices[i];
			int index = random.nextInt(zIndices.length);
			zIndices[i] = zIndices[index];
			zIndices[index] = t;
		}
		
		boardManager = new MouseSensetiveShapeManager();
		

		int w = boardSize.width - tileSize - 1;
		int h = boardSize.height - tileSize - 1;
		for(int i=0;  i < zIndices.length; i++)
		{
			int x = random.nextInt(w);
			int y = random.nextInt(h);
			tileManager.rotate(zIndices[i],TileManager.SPIN_CW*random.nextInt(rotationSteps));
			tiles[zIndices[i]] = new MouseSensetiveTile(tileManager, zIndices[i], x, y,i,errMargin);
			boardManager.addShape(tiles[zIndices[i]]);
		}
		boardManager.addEventListener(this);
		ui.setBuffers(tileSize,errMargin);
	}
	
	/**
	 * Connects two tiles
	 * @param i tile index
	 * @param j tile index
	 * @return true if all tiles are connected(puzzle is finished) once this operation is complete, or false if there are still pieces unconnected
	 */
	private boolean connectTiles(int i, int j)
	{
		//Connect the sets
		int t = connectedIndex[i];
		connectedIndex[i] = connectedIndex[j];
		connectedIndex[j] = t;
		//Update the tile counts
		t = connectedTileCount[i] + connectedTileCount[j];
		int index = i;
		do
		{
			connectedTileCount[index] = t;
			index = connectedIndex[index];
		}while(index != i);
		return t==tiles.length;
	}
	
	private void drawAllTiles()
	{
		for(int i = zIndices.length - 1; i >= 0; i--)
		{
			initTileImage(tiles[zIndices[i]],false);
			ui.drawTile(new Rectangle(tiles[zIndices[i]].getX() - errMargin,tiles[zIndices[i]].getY() - errMargin,tileSize + errMargin*2,tileSize + errMargin*2),null,PuzzleCanvas.DRAW_TILEBUFFER,PuzzleCanvas.DRAW_BACKGROUND);
		}
		ui.clear();
		ui.repaint();
	}
	
	private void initTileImage(MouseSensetiveTile tile, boolean selected)
	{
		int tileIndex = tile.getTileIndex();
		Shape tileShape = tileManager.getTileMask(tileIndex);
		AffineTransform rotation = tileManager.getRotationTransform(tileIndex,new AffineTransform(),errMargin + tileMargin);
		if(tileManager.getOriginalTilePosition(tileIndex, tempPosition)!=null)
		{
			//GUI takes into account the errMargin, but adjustment must be made for tileMargin
			ui.buildTileImage(tempPosition.x - tileMargin,tempPosition.y - tileMargin,AffineTransform.getTranslateInstance(tileMargin,tileMargin).createTransformedShape(tileShape),rotation, errMargin, selected);
		}
	}
	
	private Rectangle pickConnectedTiles(MouseSensetiveTile tile, Rectangle result)
	{
		boolean resultInitialized=false;
		int index = tile.getIndex();
		int i = index;
		do
		{
			boardManager.removeShape(tiles[i]);
			
			Rectangle bounds = tiles[i].getBounds();
			if(resultInitialized)
			{
				result.add(bounds);
			}
			else
			{
				resultInitialized=true;
				result.x=bounds.x;
				result.y=bounds.y;
				result.width=bounds.width;
				result.height=bounds.height;
			}
			immedBounds.x=bounds.x-errMargin;
			immedBounds.y=bounds.y-errMargin;
			immedBounds.width=bounds.width+errMargin*2;
			immedBounds.height=bounds.height+errMargin*2;

			//Clear the background under this tile
			ui.erase(immedBounds);
			//move the tile to the top
			int zIndex = tiles[i].getZOrder();
			//Note that changing zOrder values is risky, but
			//we can get away with it here because the absolute
			//ordering of shapes still registered with the shape
			//manager is not changing.
			for(int j = zIndex - 1; j >= 0; j--)
			{
				tiles[zIndices[j]].setZOrder(j + 1);
				zIndices[j + 1] = zIndices[j];
			}
			tiles[i].setZOrder(0);
			zIndices[0] = i;

			i=connectedIndex[i];
		}while(i!=index);
		
		do
		{
			Rectangle bounds = tiles[i].getBounds();
		bounds.x -= errMargin;
		bounds.y -= errMargin;
		bounds.width += errMargin*2;
		bounds.height += errMargin*2;
			//Draw everything under the tile
			draw(bounds);
			i=connectedIndex[i];
		}while(i!=index);
		
		return result;
	}
	
	/**
	 * Draws tiles within the given region
	 * @param bounds the region to redraw
	 */
	private void draw(Rectangle bounds)
	{
		MouseSensetiveShape [] intersectingTiles = boardManager.getIntersectingShapes(bounds);
		if(intersectingTiles != null)
		{
			for(int j = intersectingTiles.length - 1; j >= 0; j--)
			{
				initTileImage((MouseSensetiveTile)(intersectingTiles[j]),false);
				ui.drawTile(new Rectangle(intersectingTiles[j].getX() - errMargin,intersectingTiles[j].getY() - errMargin,tileSize + errMargin*2,tileSize + errMargin*2),bounds,PuzzleCanvas.DRAW_TILEBUFFER, PuzzleCanvas.DRAW_BACKGROUND);
			}
		}
	}
	
	private void initDragBuffer(MouseSensetiveTile tile)
	{
		//Determine the bounds of the tile set
		Rectangle bounds = null;
		int index = tile.getIndex();
		int i = index;
		do
		{
			Rectangle b = tiles[i].getBounds();
			if(bounds == null)
			{
				dragBounds.x=b.x;
				dragBounds.y=b.y;
				dragBounds.width=b.width;
				dragBounds.height=b.height;
				bounds=dragBounds;
			}
			else
			{
				bounds.add(b);
			}
			i=connectedIndex[i];
		}while(i!=index);
		
		bounds.x -= errMargin;
		bounds.y -= errMargin;
		bounds.width += errMargin*2;
		bounds.height += errMargin*2;
		
		ui.clearDragBuffer(bounds.width,bounds.height);

		do
		{
			Rectangle b = tiles[i].getBounds();
			initTileImage(tiles[i],true);
			ui.drawTile(new Rectangle(tiles[i].getX() - bounds.x - errMargin, tiles[i].getY() - bounds.y - errMargin,tileSize + errMargin*2,tileSize + errMargin*2),null,PuzzleCanvas.DRAW_TILEBUFFER,PuzzleCanvas.DRAW_DRAGBUFFER);
			i=connectedIndex[i];
		}while(i!=index);
	}
	public void mouseClicked(MouseSensetiveShapeEvent e)
	{}
 
    public void mousePressed(MouseSensetiveShapeEvent e)
    {
		ui.requestFocusInWindow();
		if(dragTile!=null)
		{
			mouseReleased(e.getMouseEvent());
		}
		else
		{
			dragTile = (MouseSensetiveTile)(((MouseSensetiveShape [])(e.getSource()))[0]);
			//Remove connected tiles from the background
			tempBounds = pickConnectedTiles(dragTile,tempBounds);
			//Clean up - draw the background onto the foreground
			ui.clear(tempBounds);
			//Prepare for drawing
			initTileImage(dragTile,true);
			//Draw connected tiles to the foreground
			initDragBuffer(dragTile);
			ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
			//Update the graphics
			ui.repaint(tempBounds);
			mouseX = e.getMouseEvent().getX();
			mouseY = e.getMouseEvent().getY();
		}
		e.consume();
	}
    public void mouseReleased(MouseSensetiveShapeEvent e)
    {
	}
	
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	
	/**
	 * Checks if two tiles are in their correct relative positions, within the limits of the snap threshold
	 * @param tile1 tile to check against
	 * @param tile2 tile to check
	 * @return The x and y translation factors required to correct tile2's position relative to tile1
	 */
	private Point checkNeighbors(MouseSensetiveTile tile1, MouseSensetiveTile tile2)
	{
		Point result = null;
		//Get pixel offset
		int dX = (tile2.getX() - tile1.getX());
		int signX = dX<0?-1:1;
		//convert to index offset
		dX = (dX + signX*(tileSpacingX/2))/(tileSpacingX);
		
		//Get pixel offset
		int dY = (tile2.getY() - tile1.getY());
		int signY = dY<0?-1:1;
		//Convert to index offset
		dY = (dY + signY*(tileSpacingY/2))/(tileSpacingY);
		//Check if it is the correct neighbor for its position
		tempPosition.x=dX;
		tempPosition.y=dY;
		int index = tileManager.getNeighborIndex(tile1.getTileIndex(),tempPosition);
		int index2 = tile2.getTileIndex();
		if(index >-1 && index==index2 && tileManager.getRotation(tile1.getTileIndex()) == tileManager.getRotation(index2))
		{
			//There is a neighbor on that side, it's index matches, and rotation is the same
			int adjustX = tile2.getX() - dX*tileSpacingX - tile1.getX();
			int adjustY = tile2.getY() - dY*tileSpacingY - tile1.getY();
			//Check if the tiles are close enough to 'snap'
			if(-snapThreshold < adjustX && adjustX < snapThreshold && -snapThreshold < adjustY && adjustY < snapThreshold)
			{
				result = new Point(adjustX,adjustY);
			}
		}
		return result;
	}
	
	public void mouseReleased(MouseEvent e)
	{
		if(dragTile!=null)
		{
			clearSnapSets();
			addSnapSet(dragTile, new Point(0,0));
			tempBounds = getConnectedBounds(dragTile,tempBounds);
			//Check each connected tile for neighbors
			int index = dragTile.getIndex();
			int i = index;
			//Loop through the whole connected set
			do
			{
				MouseSensetiveShape [] intersectingTiles = boardManager.getIntersectingShapes(tiles[i].getBounds());
				if(intersectingTiles != null)
				{
					for(int j = intersectingTiles.length - 1; j >= 0; j--)
					{
						//Find out if this tile lines up as a neighbor
						Point adjustment = checkNeighbors(tiles[i],(MouseSensetiveTile)intersectingTiles[j]);
						if(adjustment != null)
						{
							//Remove the tile and its neighbors from the board
							tempBounds.add(pickConnectedTiles((MouseSensetiveTile)intersectingTiles[j],tempBounds2));
							//Add the tile and its neighbors to the list of tile sets that will be snapped together
							addSnapSet((MouseSensetiveTile)intersectingTiles[j],adjustment);
							if(j > 0)
							{
								//Reevaluate intersecting tiles - some may no longer be on the board
								intersectingTiles = boardManager.getIntersectingShapes(dragTile.getBounds());
								j = intersectingTiles==null ? 0 : intersectingTiles.length;
							}
						}
					}
				}
				i=connectedIndex[i];
			}while(i != index);
			//snap the sets together
			mergeSnapSets();
			sortConnectedSet(index);
			//reinsert the connected tiles, all should be connected to dragTile now.
			do
			{
				boardManager.addShape(tiles[i]);
				i=connectedIndex[i];
			}while(i!=index);
			draw(tempBounds);
			ui.clear(tempBounds);
			ui.repaint(tempBounds);
			dragTile = null;
		}
	}
	
	/**
	 * Adjusts z-indices so that all sets smaller than the indicated tileset will be in front of it.
	 * This function assumes that tiles of the indicated tileset are not registered with the boardManager
	 * @param index the tileset to insert
	 */
	private void sortConnectedSet(int index)
	{
		int size = connectedTileCount[index];
		if(size < tiles.length)
		{
			int maxDepth = size - 1;
			for(int i = 0; i < tiles.length; i++)
			{
				//only move sets smaller than the currnt one
				if(connectedTileCount[i] < size)
				{
					int zOrder = tiles[i].getZOrder();
					//Adjust z-order, leaving enough space to insert the connected set
					tiles[i].setZOrder(zOrder - size);
					zIndices[zOrder - size] = i;
					if(maxDepth < zOrder) maxDepth = zOrder;
				}
			}
			//Move the current set into the hole left by shifting smaller sets
			maxDepth -= size - 1;
			int i = index;
			do
			{
				int zOrder = tiles[i].getZOrder() + maxDepth;
				tiles[i].setZOrder(zOrder);
				zIndices[zOrder] = i;
				i = connectedIndex[i];
			}while(i!=index);
		}
	}

	private void clearSnapSets()
	{
		snapSets = null;
		snapOffsets = null;
	}

	private void addSnapSet(MouseSensetiveTile tile, Point adjustment)
	{
		int len = snapSets==null ? 0 : snapSets.length;
		int [] newSets = new int[len + 1];
		Point [] newOffsets = new Point[len + 1];
		int i = 0;
		for(; i < len; i++)
		{
			newSets[i] = snapSets[i];
			newOffsets[i] = snapOffsets[i];
		}
		newSets[i] = tile.getIndex();
		newOffsets[i] = adjustment;
		snapSets = newSets;
		snapOffsets = newOffsets;
	}

	private void mergeSnapSets()
	{
		int totalTiles = 0;
		int avgOffsetX = 0;
		int avgOffsetY = 0;
		
		//Work out the placement
		for(int i = 1; i < snapSets.length; i++)
		{
			int count = connectedTileCount[snapSets[i]];
			totalTiles += count;
			avgOffsetX += snapOffsets[i].x*count;
			avgOffsetY += snapOffsets[i].y*count;
		}
		if(totalTiles > 0)
		{
			avgOffsetX/=totalTiles;
			avgOffsetY/=totalTiles;
		}
		
		//Adjust placement and connect the tiles
		int prevSet = -1;
		for(int i = 0; i < snapSets.length; i++)
		{
			int xOffs = avgOffsetX - snapOffsets[i].x;
			int yOffs = avgOffsetY - snapOffsets[i].y;
			int index = snapSets[i];
			int j = index;
			do
			{
				tiles[j].moveTo(tiles[j].getX() + xOffs,tiles[j].getY() + yOffs);
				j = connectedIndex[j];
			}while(j!=index);
			
			if(prevSet >=0) connectTiles(prevSet,snapSets[i]);
			prevSet = snapSets[i];
		}
	}
	
	/**
	 * Returns the bounding box of the connected set
	 * @param tile a tile belonging to the connected set
	 */
	private Rectangle getConnectedBounds(MouseSensetiveTile tile,Rectangle result)
	{
		boolean resultInitialized=false;
		int index = tile.getIndex();
		int i = index;
		//Find the bounding box of the connected set
		do
		{
			Rectangle bounds = tiles[i].getBounds();
			if(resultInitialized)
			{
				result.add(bounds);
			}
			else
			{
				resultInitialized=true;
				result.x=bounds.x;
				result.y=bounds.y;
				result.width=bounds.width;
				result.height=bounds.height;
			}
			i = connectedIndex[i];
		}while(i!=index);
		if(result!=null)
		{
			result.x -= errMargin;
			result.y -= errMargin;
			result.width += errMargin*2;
			result.height += errMargin*2;
		}
		return result;
	}
	
	public void mouseDragged(MouseEvent e)
	{
		if(dragTile!=null)
		{
			int x = e.getX();
			x = x<10?10:x<boardSize.width-10?x:boardSize.width-11;
			int y = e.getY();
			y = y<10?10:y<boardSize.height-10?y:boardSize.height-11;
			int dX = x - mouseX;
			int dY = y - mouseY;
			mouseX = x;
			mouseY = y;

			int index = dragTile.getIndex();
			int i = index;
			do
			{
				tiles[i].moveTo(tiles[i].getX() + dX, tiles[i].getY() + dY);
				i = connectedIndex[i];
			}while(i!=index);
			immedBounds.x=dragBounds.x;
			immedBounds.y=dragBounds.y;
			immedBounds.width=dragBounds.width;
			immedBounds.height=dragBounds.height;
			ui.clear(dragBounds);
			dragBounds.x+=dX;
			dragBounds.y+=dY;
			ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
			immedBounds.add(dragBounds);
			ui.repaint(immedBounds);
		}
	}

	public void mouseMoved(MouseEvent e){}
	
	public void keyPressed(KeyEvent e)
	{
		int keyCode=e.getKeyCode();
		if(dragTile != null && (keyCode==KeyEvent.VK_LEFT||keyCode==KeyEvent.VK_RIGHT))
		{
			
			int direction = keyCode==KeyEvent.VK_LEFT ? direction = TileManager.SPIN_CCW : TileManager.SPIN_CW;
			double rotationStep = tileManager.getRotationStep();
			//Rotate around the centre of the selection
			AffineTransform rot = AffineTransform.getRotateInstance(direction*rotationStep,mouseX,mouseY);
			
			int index = dragTile.getIndex();
			int i = index;
			do
			{
				tileManager.rotate(tiles[i].getTileIndex(),direction);
				Point p = new Point(tiles[i].getX() + tileSize/2 + errMargin,tiles[i].getY() + tileSize/2 + errMargin);
				rot.transform(p,p);
				tiles[i].moveTo(p.x - tileSize/2 - errMargin,p.y - tileSize/2 - errMargin);
				i = connectedIndex[i];
			}while(i!=index);
			
			//Realign tiles to fix rotation errors
			i = connectedIndex[index];
			do
			{
				alignTiles(dragTile,tiles[i]);
				i = connectedIndex[i];
			}while(i!=index);
			tempBounds.x=dragBounds.x;
			tempBounds.y=dragBounds.y;
			tempBounds.width=dragBounds.width;
			tempBounds.height=dragBounds.height;
			//Draw connected tiles to the foreground
			initDragBuffer(dragTile);
			ui.clear(tempBounds);
			tempBounds.add(dragBounds);
			ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
			ui.repaint(tempBounds);
		}
	}

	public void keyReleased(KeyEvent e){}
	
	public void keyTyped(KeyEvent e){}

	private void alignTiles(MouseSensetiveTile anchor, MouseSensetiveTile tile)
	{
		int x1 = anchor.getX();
		int y1 = anchor.getY();

		int x2 = tile.getX();
		int y2 = tile.getY();

		int dX = (tile.getX() - anchor.getX() + (x2>x1 ? 1 : -1)*tileSpacingX/2)/tileSpacingX;
		int dY = (tile.getY() - anchor.getY() + (y2>y1 ? 1 : -1)*tileSpacingY/2)/tileSpacingY;

		tile.moveTo(anchor.getX() + dX*tileSpacingX,anchor.getY() + dY*tileSpacingY);
	}
}
