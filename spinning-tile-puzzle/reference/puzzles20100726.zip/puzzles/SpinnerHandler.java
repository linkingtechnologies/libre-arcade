/**
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.Random;
import java.awt.Dimension;
import java.awt.Shape;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import hulka.tilemanager.*;

/**
 * To do: make sure tilemask is only acquired once
 * To do: init one AffineTransform and reuse it
 * To do: init one bounding rectangle and reuse it
 */
public class SpinnerHandler implements PuzzleHandler, MouseMotionListener, KeyListener, MouseListener
{
	private GUI ui;
	private Random random;
	static final int MIX_COUNT = 5;
	private int errMargin = 8;
/*	//Suggested piece counts for the tileManager
	static final int [] preferredSizes = {6,12,18};*/
	//Combo box indices:
	Dimension boardSize = null;
	Dimension [] puzzleSizes = null;
	TileSpinnerManager tileManager;
	private int tileSize;
	private int currentTile=-1;
	private int currentVertex=-1;
	private int currentSpin = TileManager.SPIN_NONE;
	private Rectangle cursorBounds = new Rectangle(0,0,GUI.CURSOR_SIZE,GUI.CURSOR_SIZE);
	
	//Temporary storage to save heap abuse
	private Point coords=null;
	private int [] changedTiles=null;

	public SpinnerHandler(GUI gui)
	{
		ui = gui;
		random = new Random();
	}

	public int [] getPuzzleSizes(int shapeIndex)
	{
		/*calculateSizes(shapeIndex);
		int [] ps = new int[puzzleSizes.length];
		for(int i = 0; i < puzzleSizes.length; i++)
		{
			ps[i] = puzzleSizes[i].width*puzzleSizes[i].height;
		}
		return ps;*/
		return null;
	}
	
	public void load(int pieceCountIndex, int shapeIndex)
	{
		boardSize = ui.getImageSize();
/*		switch(shapeIndex)
		{
			case StateHandler.SHAPE_SQUARE:
				tileManager = new SquareSpinnerManager(boardSize.width, boardSize.height, puzzleSizes[pieceCountIndex].width);
				break;
			case StateHandler.SHAPE_HEX:
				tileManager = new HexSpinnerManager(boardSize.width, boardSize.height, puzzleSizes[pieceCountIndex].width);
				break;
			case StateHandler.SHAPE_TRIANGLE:
				break;
		}
		if(tileManager != null)
		{
			setupTiles();
			drawAllTiles();
		}*/
		tileManager = new HexSpinnerManager(boardSize.width,boardSize.height);
		setupTiles();
		drawAllTiles();
	}

	private void setupTiles()
	{
		int [] indices = new int[tileManager.getTileCount()];
		for(int i=0; i < indices.length; i++){indices[i]=i;}
		tileSize = tileManager.getTileWidth();
		int h = tileManager.getTileHeight();
		if(h > tileSize) tileSize = h;
		for(int i = 0; i < MIX_COUNT; i++)
		{
			//Randomize the order
			for(int j = 0; j < indices.length; j++)
			{
				int t = indices[j];
				int index = random.nextInt(indices.length);
				indices[j] = indices[index];
				indices[index] = t;
			}
			for(int j = 0; j < indices.length; j++)
			{
				tileManager.spin(indices[j], random.nextInt(2)==0 ? TileManager.SPIN_CCW : TileManager.SPIN_CW);
			}
		}
		ui.initCanvas(boardSize.width,boardSize.height);
		ui.setBuffers(tileSize,errMargin);
		ui.addMouseListener(this);
		ui.addMouseMotionListener(this);
		ui.addKeyListener(this);
	}
	
	private void drawAllTiles()
	{
		//Draw the whole picture to the background
		ui.drawTile(new Rectangle(0,0,boardSize.width,boardSize.height),null,GUI.DRAW_PUZZLEIMAGE,GUI.DRAW_BACKGROUND);
		ui.clearAll();
		int tileCount = tileManager.getTileCount();
		for(int i=0; i < tileCount; i++)
		{
			initTileImage(i);
			coords = tileManager.getTilePosition(i,coords);
			ui.drawTile(new Rectangle(coords.x - errMargin,coords.y - errMargin, tileSize + errMargin*2, tileSize + errMargin*2),null,GUI.DRAW_TILEBUFFER,GUI.DRAW_FOREGROUND);
		}
		ui.repaint();
	}

/*	private void calculateSizes(int shapeIndex)
	{
		boardSize=ui.getImageSize();
		puzzleSizes = new Dimension[preferredSizes.length];
		for(int i = 0; i < preferredSizes.length; i++)
		{
			int w = boardSize.width;
			int h = boardSize.height;
			int c = preferredSizes[i];
			puzzleSizes[i] = shapeIndex==StateHandler.SHAPE_SQUARE ? SquareSpinnerManager.getNearestGridDimension(w,h,c) : shapeIndex==StateHandler.SHAPE_HEX ? HexSpinnerManager.getNearestGridDimension(w,h,c) : shapeIndex==StateHandler.SHAPE_TRIANGLE ? null : null;
		}
	}*/

	private void initTileImage(int tileIndex)
	{
		Shape tileShape = tileManager.getTileMask(tileIndex);
		AffineTransform rotation = tileManager.getRotationTransform(tileIndex,new AffineTransform(),errMargin);
		coords = tileManager.getOriginalTilePosition(tileIndex,coords);
		ui.buildTileImage(coords.x,coords.y,tileShape,rotation, errMargin);
	}
	
	private Rectangle drawTile(int tileIndex)
	{
		coords = tileManager.getTilePosition(tileIndex,coords);
		Rectangle result = new Rectangle(coords.x - errMargin,coords.y - errMargin,tileSize + errMargin*2,tileSize + errMargin*2);
		ui.drawTile(result,null,GUI.DRAW_TILEBUFFER,GUI.DRAW_FOREGROUND);
		return result;
	}
	
	private void markVertex(int spin)
	{
		//Backup the image under the rotation icon
		ui.backupImage(cursorBounds, GUI.DRAW_FOREGROUND);

		//Draw the icon
		ui.drawTile(cursorBounds,null,spin==TileManager.SPIN_CW ? GUI.DRAW_ROTATECW : GUI.DRAW_ROTATECCW, GUI.DRAW_FOREGROUND);
	}
	
	private void unmarkVertex()
	{
		//redraw the saved piece of image
		ui.drawTile(cursorBounds,null,GUI.DRAW_DRAGBUFFER,GUI.DRAW_FOREGROUND);
	}
	
	public void mouseMoved(MouseEvent e)
	{
		int vertex = tileManager.getNearestVertex(e.getX(), e.getY());
		int spin = e.isShiftDown() ? TileManager.SPIN_CCW : TileManager.SPIN_CW;
		if(vertex>-1)
		{
			if(vertex != currentVertex)
			{
				if(currentVertex>-1)
				{
					unmarkVertex();
					ui.repaint(cursorBounds);
				}
				coords = tileManager.getVertexPosition(vertex,coords);
				cursorBounds.x = coords.x - GUI.CURSOR_SIZE/2;
				cursorBounds.y = coords.y - GUI.CURSOR_SIZE/2;
				markVertex(spin);
				ui.repaint(cursorBounds);
			}
		}
		else if(currentVertex>-1)
		{
			unmarkVertex();
			ui.repaint(cursorBounds);
		}
		currentSpin = spin;
		currentVertex = vertex;
	}

	public void keyPressed(KeyEvent e)
	{
		int spin = e.isShiftDown() ? TileManager.SPIN_CCW : TileManager.SPIN_CW;
		if(spin != currentSpin && currentVertex>-1)
		{
			unmarkVertex();
			markVertex(spin);
			ui.repaint(cursorBounds);
		}
		currentSpin = spin;
	}

	public void keyReleased(KeyEvent e)
	{
		int spin = e.isShiftDown() ? TileManager.SPIN_CCW : TileManager.SPIN_CW;
		if(spin != currentSpin && currentVertex>-1)
		{
			unmarkVertex();
			markVertex(spin);
			ui.repaint(cursorBounds);
		}
		currentSpin = spin;
	}
	
	public void keyTyped(KeyEvent e){}
	
	public void mouseDragged(MouseEvent e)
	{
	}
	
	public void mouseClicked(MouseEvent e)
	{
		if(currentVertex>-1)
		{
			tileManager.spin(currentVertex,currentSpin);
			changedTiles = tileManager.getChangedTiles(changedTiles);
			Rectangle bounds = null;
			for(int i = 0; i < changedTiles.length; i++)
			{
				initTileImage(changedTiles[i]);
				Rectangle r = drawTile(changedTiles[i]);
				if(bounds==null)
				{
					bounds = r;
				}
				else
				{
					bounds.add(r);
				}
			}
			markVertex(currentSpin);
			ui.repaint(bounds);
		}
	}
	
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}

}
