public interface PuzzleHandler
{
	public void connect(PuzzleCanvas canvas);
	public void disconnect();
	public boolean isGameComplete();
	public boolean isGameSaved();
	public void redraw();
}
