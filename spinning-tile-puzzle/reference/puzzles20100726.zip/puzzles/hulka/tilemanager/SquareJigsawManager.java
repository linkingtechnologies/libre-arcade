/** 
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * changelog
 * 
 * 2010 07 09 - Jon
 * - enhanced initTilesetDescriptor and randomize functions:
 *  Corner variance is now used for optimized tile sizing and edge adjustment.
 * 2010 07 26 - Jon
 * - Made tile size optimization code more consistent with HexJigsawManager
*/
package hulka.tilemanager;
import java.awt.geom.Path2D;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.awt.Point;
import java.awt.Shape;
import java.util.Random;

/**
 * Adds jigsaw shapes to SquareTileManager.
 * To do - make drawing functions more inline with HexJigsawManager:
 *  - eventually these should be abstracted to the point that they can be
 *    pulled out into a class of their own.
 */
public class SquareJigsawManager extends SquareTileManager
{
	private static int X_DIMENSION = 0;
	private static int Y_DIMENSION = 1;
	//Only count direct neighbors
	private static int NEIGHBOR_COUNT = SIDE_COUNT;
	//Tweak this to get the bubbles big enough
	private static double bubbleMinFactor = 0.3;
	//Tweak this to get the bubbles small enough
	private static double bubbleMaxFactor = 0.4;
	//Tweak this to adjust bubble stem size
	private static double bubbleStemFactor = 0.3;
	//Tweak this to adjust the curve sharpness
	private static double controlPointVarianceFactor = 0.1;
	//Tweak this to adjust the curve depth
	private static double cornerVarianceFactor = 0.2;
	//There's a lot more to tweak in buildEdge
	
	private int controlPointVariance;
	private int cornerVariance;
	private int bubbleMin;
	private int bubbleMax;
	private int leftVariance, topVariance, rightVariance, bottomVariance;
	
	//Tile drawing information
	protected int [][] cornerOffsetX;
	protected int [][] cornerOffsetY;
	protected int [][] bubbleSizeX;
	protected int [][] bubbleSizeY;
	protected int [][] bubbleSideX;
	protected int [][] bubbleSideY;
	protected int [][] controlPointOffsetX;
	protected int [][] controlPointOffsetY;
	
	Point [] neighborOffsetIndex;

	//Temporary storage to avoid excessive heap usage
	private Point tempIndex=new Point();


	public SquareJigsawManager(int width, int height, int tilesAcross, int tilesDown)
	{
		super(width, height, tilesAcross, tilesDown);
		cornerOffsetX = new int[tilesAcross + 1][tilesDown + 1];
		cornerOffsetY = new int[tilesAcross + 1][tilesDown + 1];
		controlPointOffsetX = new int[tilesAcross + 1][tilesDown + 1];
		controlPointOffsetY = new int[tilesAcross + 1][tilesDown + 1];
		bubbleSizeX = new int[tilesAcross + 1][tilesDown + 1];
		bubbleSizeY = new int[tilesAcross + 1][tilesDown + 1];
		bubbleSideX = new int[tilesAcross + 1][tilesDown + 1];
		bubbleSideY = new int[tilesAcross + 1][tilesDown + 1];

		int rightOffset=descriptor.boardWidth-descriptor.leftOffset-descriptor.tileWidth*descriptor.tilesAcross;
		int bottomOffset=descriptor.boardHeight-descriptor.topOffset-descriptor.tileHeight*descriptor.tilesDown;
		topVariance = cornerVariance>descriptor.topOffset?descriptor.topOffset:cornerVariance;
		bottomVariance = cornerVariance>bottomOffset?bottomOffset:cornerVariance;
		leftVariance = cornerVariance>descriptor.leftOffset?descriptor.leftOffset:cornerVariance;
		rightVariance=cornerVariance>rightOffset?rightOffset:cornerVariance;

		randomize();
		
		neighborOffsetIndex = new Point[NEIGHBOR_COUNT];
		int i = -1;
		int j = 0;
		int dx = 1;
		int dy = -1;
		for(int index = 0; index < NEIGHBOR_COUNT; index++)
		{
			neighborOffsetIndex[index] = new Point(i,j);
			i += dx;
			j += dy;
			if(i==dx)dx = -dx;
			if(j==dy)dy = -dy;
		}
	}

	/**
	 * Overridden for tileMargin adjustment
	 */
	public void initTileSetDescriptor(TileSetDescriptor d)
	{
		super.initTileSetDescriptor(d);

		//Adjust width and height for best fit; cornerVariance gives some allowance for stretching and squeezing edges.
		//First split the difference between optimal width and optimal height
		int tW=(descriptor.boardWidth+descriptor.boardHeight)/(descriptor.tilesAcross+descriptor.tilesDown);
		//Then make sure the result will fit inside the board boundaries.
		int maxTW=(int)((double)descriptor.boardWidth/((double)descriptor.tilesAcross-2.0*cornerVarianceFactor));
		int maxTH=(int)((double)descriptor.boardHeight/((double)descriptor.tilesDown-2.0*cornerVarianceFactor));
		tW=tW<=maxTW?(tW<=maxTH?tW:maxTH):(maxTW<=maxTH?maxTW:maxTH);
		descriptor.tileWidth=tW;
		descriptor.tileHeight=tW;
		descriptor.tileSpacingX=tW;
		descriptor.tileSpacingY=tW;

		controlPointVariance = (int)(descriptor.tileWidth*controlPointVarianceFactor);
		cornerVariance = (int)(descriptor.tileWidth*cornerVarianceFactor);
		bubbleMin = (int)((descriptor.tileWidth - cornerVariance*2)*bubbleMinFactor);
		bubbleMax = (int)((descriptor.tileWidth - cornerVariance*2)*bubbleMaxFactor);
		d.tileMargin = cornerVariance + bubbleMax;
	}

	public Shape getTileMask(int flatIndex)
	{
		Point tileIndex = getExpandedIndex(flatIndex,tempIndex);
		int x = tileIndex.x;
		int y = tileIndex.y;
		Path2D.Double path = new Path2D.Double();
		int i = 0;
		int j = 0;
		
		double pX = cornerOffsetX[x + i][y + j];
		double pY = cornerOffsetY[x + i][y + j];
		path.moveTo(pX,pY);
		double pXX = pX;
		double pYY = pY;
		
		
		i=1;
		double cp = descriptor.tileWidth/2.0 + controlPointOffsetX[x][y + j];
		pX = cornerOffsetX[x + i][y + j] + descriptor.tileWidth;
		pY = cornerOffsetY[x + i][y + j];
		buildEdge(path,pXX,pYY,pX,pY,cp,bubbleSizeY[x][y + j],bubbleSideY[x][y + j],Y_DIMENSION,1);
		pYY = pY;
		pXX = pX;

		j=1;
		cp = descriptor.tileHeight/2.0 + controlPointOffsetY[x + i][y];
		pX = cornerOffsetX[x + i][y + j] + descriptor.tileWidth;
		pY = cornerOffsetY[x + i][y + j] + descriptor.tileHeight;
		buildEdge(path,pXX,pYY,pX,pY,cp,bubbleSizeX[x + i][y],bubbleSideX[x + i][y],X_DIMENSION,1);
		pYY = pY;
		pXX = pX;

		i=0;
		cp = descriptor.tileWidth/2.0 + controlPointOffsetX[x][y + j];
		pX = cornerOffsetX[x + i][y + j];
		pY = cornerOffsetY[x + i][y + j] + descriptor.tileHeight;
		buildEdge(path,pXX,pYY,pX,pY,cp,bubbleSizeY[x][y + j],bubbleSideY[x][y + j],Y_DIMENSION,-1);
		pYY = pY;
		pXX = pX;
		
		j=0;
		cp = descriptor.tileHeight/2.0 + controlPointOffsetY[x + i][y];
		pX = cornerOffsetX[x + i][y + j];
		pY = cornerOffsetY[x + i][y + j];
		buildEdge(path,pXX,pYY,pX,pY,cp,bubbleSizeX[x + i][y],bubbleSideX[x + i][y],X_DIMENSION,-1);
	
		Area area = new Area(path);
		
		return area;
	}
	
	private void buildEdge(Path2D.Double path, double x1, double y1, double x2, double y2, double cp, double bubbleSize, double bubbleDirection, int dimension, double direction)
	{
		//There's a lot of trial and error in here. It seems to be working reasonably well
		double a1;
		double b1;
		double a2;
		double b2;
		double midB;
		if(dimension == X_DIMENSION)
		{
			a1 = x1;
			b1 = y1;
			a2 = x2;
			b2 = y2;
			midB = descriptor.tileHeight/2.0;
		}
		else
		{
			//Transpose coordinates to work in the Y dimension
			a1 = y1;
			b1 = x1;
			a2 = y2;
			b2 = x2;
			midB = descriptor.tileWidth/2.0;
		}
		//Base control point for bubble
		double midA = (a2 - a1)*(midB - b1)/(b2 - b1) + a1;
		double cpStemA1 = bubbleDirection==0 ? a1 : Math.min(bubbleDirection*a2,bubbleDirection*a1)*bubbleDirection;
		double cpStemA2 = bubbleDirection==0 ? a1 : Math.min(bubbleDirection*a2,bubbleDirection*a1)*bubbleDirection;
		//Stem points
		double stemA1 = bubbleDirection*bubbleSize*bubbleStemFactor + midA*0.25 + a1*0.75;
		double stemA2 = bubbleDirection*bubbleSize*bubbleStemFactor + midA*0.25 + a2*0.75;
		//Outer bubble point
		double bubbleA = bubbleDirection*bubbleSize + midA;
		//Outer control points for bubble - Shift the curve to fit the stem better
		double cpBubbleA1 = bubbleA + (stemA1 - stemA2);
		double cpBubbleA2 = bubbleA + (stemA2 - stemA1);
		double cpBubbleB1 = midB - 1.5*direction*Math.abs(bubbleA - stemA1);
		double cpBubbleB2 = midB + 1.5*direction*Math.abs(bubbleA - stemA2);
		//Outer bubble Point - take the middle of the control points
		double bubbleB = (cpBubbleB1 + cpBubbleB2)/2;
		//Stem points
		double stemB1 = cpBubbleB1*bubbleStemFactor + midB*(1-bubbleStemFactor);
		double stemB2 = cpBubbleB2*bubbleStemFactor + midB*(1-bubbleStemFactor);
		
		if(dimension == X_DIMENSION)
		{
			path.curveTo(a1,cp,cpStemA1,midB,stemA1,stemB1);
			path.quadTo((float)cpBubbleA1,(float)cpBubbleB1,(float)bubbleA,(float)bubbleB);
			path.quadTo((float)cpBubbleA2,(float)cpBubbleB2,(float)stemA2,(float)stemB2);
			path.curveTo((float)cpStemA2,(float)midB,(float)a2,(float)cp,(float)a2,(float)b2);
		}
		else
		{
			//Transpose coordinates to work in the Y dimension
			path.curveTo((float)cp,(float)a1,(float)midB,(float)cpStemA1,(float)stemB1,(float)stemA1);
			path.quadTo((float)cpBubbleB1,(float)cpBubbleA1,(float)bubbleB,(float)bubbleA);
			path.quadTo((float)cpBubbleB2,(float)cpBubbleA2,(float)stemB2,(float)stemA2);
			path.curveTo((float)midB,(float)cpStemA2,(float)cp,(float)a2,(float)b2,(float)a2);
		}
	}

	private void randomize()
	{
		Random random = new Random();
		//Randomize everything
		for(int i = 0; i <= descriptor.tilesAcross; i++)
		{
			for(int j = 0; j <= descriptor.tilesDown; j++)
			{
				bubbleSizeX[i][j] = random.nextInt(bubbleMax - bubbleMin) + bubbleMin;
				bubbleSideX[i][j] = random.nextInt(2)*2-1;
				cornerOffsetX[i][j] = random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
				bubbleSizeY[i][j] = random.nextInt(bubbleMax - bubbleMin) + bubbleMin;
				bubbleSideY[i][j] = random.nextInt(2)*2-1;
				cornerOffsetY[i][j] = random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
				if(controlPointVariance > 0)
				{
					controlPointOffsetX[i][j] = random.nextInt(controlPointVariance*2 - 1) - controlPointVariance + 1;
					controlPointOffsetY[i][j] = random.nextInt(controlPointVariance*2 - 1) - controlPointVariance + 1;
				}
				else
				{
					controlPointOffsetX[i][j] = 0;
					controlPointOffsetY[i][j] = 0;
				}
			}
		}

		//Fix up the edges
		for(int i = 0; i <= descriptor.tilesAcross; i++)
		{
			cornerOffsetY[i][0]=-topVariance;
			cornerOffsetY[i][descriptor.tilesDown]=bottomVariance;
			bubbleSizeY[i][0]=0;
			bubbleSizeY[i][descriptor.tilesDown]=0;
			bubbleSideY[i][0]=0;
			bubbleSideY[i][descriptor.tilesDown]=0;
			controlPointOffsetY[i][0]=0;
			controlPointOffsetY[i][descriptor.tilesDown]=0;
		}
		for(int j = 0; j <= descriptor.tilesDown; j++)
		{
			cornerOffsetX[0][j]=-leftVariance;
			cornerOffsetX[descriptor.tilesAcross][j]=rightVariance;
			bubbleSizeX[0][j]=0;
			bubbleSizeX[descriptor.tilesAcross][j]=0;
			bubbleSideX[0][j]=0;
			bubbleSideX[descriptor.tilesAcross][j]=0;
			controlPointOffsetX[0][j]=0;
			controlPointOffsetX[descriptor.tilesAcross][j]=0;
		}
		
	}
}
