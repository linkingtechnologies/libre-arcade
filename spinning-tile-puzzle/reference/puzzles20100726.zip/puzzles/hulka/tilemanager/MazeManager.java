/** 
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 package hulka.tilemanager;

/**
 * Assumptions for the TileManager (tm) used:
 * tm.getRotationCount()%2==0
 * if neighborIndex == tm.getNeighborIndex(tileIndex,direction) and neighborIndex!=-1, then tileIndex == tm.getNeighborIndex(tileIndex,(direction + rotationCount/2)%rotationCount)
 * For example, if a HexTileManager is used:
 * tm.getRotationCount()==6
 * tm.getNeighborIndex(0,1)==1 (assuming sufficient tilesAcross)
 * (1+3)%6==4
 * tm.getNeighborIndex(1,4)==0 (coming back in the other direction)
 */
public class MazeManager
{
	/**
	 * Constant value indicating that a passage between a tile and its neighbor does not exist, either because there is no neighbor or the tile has no border in a given direction (as in the case of triangular tiles, with six directions and three borders).
	 */
	public static final int PASSAGE_NONE=0;
	/**
	 * Constant value indicating that the passage between a tile and its neighbor is open.
	 */
	public static final int PASSAGE_OPEN=1;
	/**
	 * Constant value indicating that the passage between a tile and its neighbor is closed.
	 */
	public static final int PASSAGE_CLOSED=2;
	/**
	 * Constant value indicating that the passage between a tile and its neighbor is closed and cannot be opened.
	 */
	public static final int PASSAGE_BLOCKED=6;
	
	private TileManager tileManager=null;
	private int cellCount;
	private int directionCount;
	private int [] passageStates;
	
	private MazeManager(){}
	
	public MazeManager(TileManager tm)
	{
		tileManager=tm;
		cellCount=tm.getTileCount();
		directionCount=tm.getRotationSteps();
		passageStates=new int[cellCount*directionCount/2];
		for(int i=0; i < cellCount; i++)
		{
			for(int j=0; j < directionCount/2; j++)
			{
				passageStates[cellCount*j+i]=tileManager.getNeighborIndex(i,j)>=0?PASSAGE_CLOSED:PASSAGE_NONE;
			}
		}
	}
	
	/**
	 * Helper function for indexing passages
	 */
	private int getPassageIndex(int cellIndex, int direction)
	{
		int result=-1;
		if(cellIndex>=0 && cellIndex<cellCount && direction>=0)
		{
			if(direction>=directionCount/2 && direction<directionCount)
			{
				cellIndex=tileManager.getNeighborIndex(cellIndex,direction);
				direction%=(directionCount/2);
			}
			if(cellIndex>=0) result=cellCount*direction+cellIndex;
		}
		return result;
	}

	/**
	 * Returns the state of a passage between two tiles.
	 * @param flatIndex index of the starting tile.
	 * @param direction direction to search.
	 * @return one of the PASSAGE_... constants.
	 */
	public int getPassageState(int flatIndex, int direction)
	{
		int result=PASSAGE_NONE;
		int index=getPassageIndex(flatIndex,direction);
		if(index>=0) result=passageStates[index];
		return result;
	}
	
	/**
	 * Attempts to open a passage.
	 * @param flatIndex index of the starting tile.
	 * @param direction direction of the passage.
	 * @return PASSAGE_OPEN on success, PASSAGE_NONE if no neighbor exists in the specified direction, or PASSAGE_BLOCKED if the passage is marked blocked and cannot be opened.
	 */
	public int openPassage(int flatIndex, int direction)
	{
		int result=PASSAGE_NONE;
		int index=getPassageIndex(flatIndex,direction);
		if(index>=0)
		{
			if(passageStates[index]!=PASSAGE_BLOCKED)
			{
				passageStates[index]=PASSAGE_OPEN;
			}
			result=passageStates[index];
		}
		return result;
	}
	
	/**
	 * Attempts to block a passage.
	 * @param flatIndex index of the starting tile.
	 * @param direction direction of the passage.
	 * @return PASSAGE_BLOCKED on success, PASSAGE_NONE if no neighbor exists in the specified direction, or PASSAGE_OPEN if the passage cannot be blocked because it is open.
	 */
	public int blockPassage(int flatIndex, int direction)
	{
		int result=PASSAGE_NONE;
		int index=getPassageIndex(flatIndex,direction);
		if(index>=0)
		{
			if(passageStates[index]!=PASSAGE_OPEN)
			{
				passageStates[index]=PASSAGE_BLOCKED;
			}
			result=passageStates[index];
		}
		return result;
	}
	
	/**
	 * Attempts to unblock a passage.
	 * @param flatIndex index of the starting tile.
	 * @param direction direction of the passage.
	 * @return PASSAGE_CLOSED on success, PASSAGE_NONE if no neighbor exists in the specified direction, or the current state of the passage if it wasn't blocked.
	 */
	public int unblockPassage(int flatIndex, int direction)
	{
		int result=PASSAGE_NONE;
		int index=getPassageIndex(flatIndex,direction);
		if(index>=0)
		{
			if(passageStates[index]==PASSAGE_BLOCKED)
			{
				passageStates[index]=PASSAGE_CLOSED;
			}
			result=passageStates[index];
		}
		return result;
	}
	
	/**
	 * Attempts to close a passage.
	 * @param flatIndex index of the starting tile.
	 * @param direction direction of the passage.
	 * @return PASSAGE_CLOSED on success, PASSAGE_NONE if no neighbor exists in the specified direction, or PASSAGE_BLOCKED if the passage is already closed and blocked.
	 */
	public int closePassage(int flatIndex, int direction)
	{
		int result=PASSAGE_NONE;
		int index=getPassageIndex(flatIndex,direction);
		if(index>=0)
		{
			if(passageStates[index]!=PASSAGE_BLOCKED)
			{
				passageStates[index]=PASSAGE_CLOSED;
			}
			result=passageStates[index];
		}
		return result;
	}
}
