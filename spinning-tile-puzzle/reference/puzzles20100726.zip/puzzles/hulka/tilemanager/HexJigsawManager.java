/**   Copyright (C) 2010  Jonathan Hulka (jon.hulka@gmail.com)
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * changelog:
 * 2010 07 26 - Jon
 * - enhanced initTilesetDescriptor and getTileMask functions:
 *   corner variance is now used for optimized tile sizing and edge adjustment.
 */
package hulka.tilemanager;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.awt.Point;
import java.awt.Shape;
import java.util.Random;

/**
 * Adds jigsaw shapes to HexTileManager.
 * To do - rework getTileMask:
 * - Clean up rendering
 * - Shape should be stored and copied
 */

public class HexJigsawManager extends HexTileManager
{
	//Only count direct neighbors
	private static int NEIGHBOR_COUNT = SIDE_COUNT;
	//Tweak this to get the bubbles big enough
	private static double bubbleMinFactor = 0.20;
	//Tweak this to get the bubbles small enough
	private static double bubbleMaxFactor = 0.25;
	//Tweak this to adjust the curve sharpness
	private static double controlPointVarianceFactor = 0.05;
	//Tweak this to adjust shape variance and size flexibility (Values >= 0.1 should absorb most aspect ratio differences)
	private static double cornerVarianceFactor = 0.1;
	//There's a lot more to tweak in buildEdge
	
	private int controlPointVariance;
	private int cornerVariance;
	private int topVariance, bottomVariance, leftVariance, rightVariance;
	private int bubbleMin;
	private int bubbleMax;
	
	//Tile drawing information
	//Corners
	private int [][] cornerOffsetX=new int[2][];
	private int [][] cornerOffsetY=new int[2][];
	//Edges
	private int [][] bubbleSize=new int[3][];
	private int [][] bubbleDirection=new int[3][];
	private int [][] controlPointOffset=new int[3][];
	//Indices to help with drawing
	private Point cornerTileOffset[] = new Point[6];
	private int cornerIndexOffset[] = new int[6];
	private Point edgeTileOffset[] = new Point[6];
	private int edgeIndexOffset[] = new int[6];

	AffineTransform[] reverseMaskTransform = new AffineTransform[NEIGHBOR_COUNT/2];
	AffineTransform[] maskTransform = new AffineTransform[NEIGHBOR_COUNT/2];


	//Temporary storage for drawing function
	Point2D.Double [] corners = new Point2D.Double[NEIGHBOR_COUNT*4];
	Point2D.Double [] controls = new Point2D.Double[NEIGHBOR_COUNT*6];
	Point2D.Double a=new Point2D.Double(), b=new Point2D.Double();

	//Temporary storage to avoid excessive heap usage
	private Point tempIndex=new Point(), tempNeighbor=new Point();

	public HexJigsawManager(int width, int height, int tilesAcross, int tilesDown)
	{
		super(width,height,tilesAcross,tilesDown,true);

		for(int i = 0; i < 2; i++)
		{
			cornerOffsetX[i] = new int[descriptor.tileCount];
			cornerOffsetY[i] = new int[descriptor.tileCount];
		}
		
		for(int i = 0; i < 3; i++)
		{
			bubbleSize[i] = new int[descriptor.tileCount];
			bubbleDirection[i] = new int[descriptor.tileCount];
			controlPointOffset[i] = new int[descriptor.tileCount];
		}

		randomize();
		
		Point thisTile = new Point(0,0);
		cornerTileOffset[0] = thisTile;
		cornerTileOffset[1] = new Point(1,-1);
		cornerTileOffset[2] = new Point(1,1);
		for(int i = 0; i < 3; i++)
		{
			edgeTileOffset[i] = thisTile;
			edgeTileOffset[i+3]=neighborOffsetIndex[i+3];
			edgeIndexOffset[i] = i;
			edgeIndexOffset[i+3] = i;
			cornerIndexOffset[i] = i%2;
			cornerIndexOffset[i+3] = (i+3)%2;
			cornerTileOffset[i+3] = new Point(-cornerTileOffset[i].x,-cornerTileOffset[i].y);
		}

		int topOffset=descriptor.topOffset+descriptor.tileHeight/4;
		int bottomOffset=descriptor.boardHeight-topOffset-(descriptor.tilesDown*3-1)*descriptor.tileHeight/4;
		int leftOffset=descriptor.leftOffset+descriptor.tileWidth/2;
		int rightOffset=descriptor.boardWidth-leftOffset-(descriptor.tilesAcross-1)*descriptor.tileWidth/2;
		topVariance = cornerVariance>topOffset?topOffset:cornerVariance;//-((descriptor.topOffset + descriptor.tileHeight/4) > cornerVariance ? cornerVariance : (descriptor.topOffset + descriptor.tileHeight/4));
		bottomVariance = cornerVariance>bottomOffset?bottomOffset:cornerVariance;//((descriptor.boardHeight-descriptor.topOffset + descriptor.tileHeight/4) > cornerVariance ? cornerVariance : (descriptor.boardHeight-descriptor.topOffset + descriptor.tileHeight/4));
		leftVariance = cornerVariance>leftOffset?leftOffset:cornerVariance;
		rightVariance=cornerVariance>rightOffset?rightOffset:cornerVariance;
		for(int j=0; j<NEIGHBOR_COUNT; j++)
		{
			for(int i=0; i<4; i++) corners[i*NEIGHBOR_COUNT+j]=new Point2D.Double();
			for(int i=0; i<6; i++) controls[i*NEIGHBOR_COUNT+j]=new Point2D.Double();
		}
		for(int i=0; i<NEIGHBOR_COUNT/2; i++)
		{
			double theta = i*2.0*Math.PI/NEIGHBOR_COUNT + Math.PI/6.0;
			reverseMaskTransform[i] = AffineTransform.getRotateInstance(-theta,descriptor.tileWidth/2.0, descriptor.tileHeight/2.0);
			maskTransform[i] = AffineTransform.getRotateInstance(theta,descriptor.tileWidth/2.0, descriptor.tileHeight/2.0);
		}
	}
	
	/**
	 * Overridden for tileMargin adjustment and tile size optimizing
	 */
	public void initTileSetDescriptor(TileSetDescriptor d)
	{
		super.initTileSetDescriptor(d);

		//Adjust width and height for best fit; cornerVariance gives some allowance for stretching and squeezing edges.
		//Optimal tile width
		int tW=2*d.boardWidth/(d.tilesAcross-1);
		//Optimal tile height
		int tH=4*(d.boardHeight/(d.tilesDown*3-1));

		int tW2=(int)(tH*sqrt3/2);
		//Minimum corner variance - to make sure maximum width and height are safe
		int cv=(int)((tW2>tW?tW:tW2)*cornerVarianceFactor);

		//maximum tile width, allowing for corner variance
		int maxTW=(int)(((double)descriptor.boardWidth+2.0*cv)/((double)descriptor.tilesAcross-1.0)*2.0);
		//maximum tile height, allowing for corner variance
		int maxTH=(int)(((double)descriptor.boardHeight+2.0*cv)/((double)descriptor.tilesDown*3.0-1.0)*4.0);

		//Use the smallest maximum tile size
		int maxTW2=(int)(maxTH*sqrt3/2);
		maxTW=maxTW<=maxTW2?maxTW:maxTW2;

		//Get an average tile size - This has the best chance of fitting both width and height
		tW=tW/2+(int)(tH*sqrt3);

		//Make sure tile size doesn't exceed the maximum
		tW=tW<=maxTW?tW:maxTW;
		tH=(int)(2*tW/sqrt3);

		//Make tH an integral multiple of 4, to ensure accuracy calculating spacing
		tH-=tH%4;
		//Make tW an integral multiple of 2, to ensure accuracy caclulating spacing
		tW-=tW%2;

		descriptor.tileHeight=tH;
		descriptor.tileWidth=tW;
		descriptor.tileSpacingX=tW/2;
		descriptor.tileSpacingY=tH*3/4;

		controlPointVariance = (int)(descriptor.tileWidth*controlPointVarianceFactor);
		cornerVariance = (int)(descriptor.tileWidth*cornerVarianceFactor);
		bubbleMin = (int)((descriptor.tileWidth - cornerVariance*2)*bubbleMinFactor);
		bubbleMax = (int)((descriptor.tileWidth - cornerVariance*2)*bubbleMaxFactor);
		d.tileMargin = cornerVariance + bubbleMax;
	}

	public Shape getTileMask(int flatIndex)
	{
		Point tileIndex = getExpandedIndex(flatIndex,tempIndex);
		for(int i = 0; i < NEIGHBOR_COUNT; i++)
		{
			tempNeighbor.x = tileIndex.x + cornerTileOffset[i].x;
			tempNeighbor.y = tileIndex.y + cornerTileOffset[i].y;
			int xOffset = 0;
			int yOffset = 0;
//To do: make sure this condition isn't too restrictive (allow x and y to be handled independently)
			if(tempNeighbor.x >= 0 && tempNeighbor.y >= 0 && tempNeighbor.x<descriptor.tilesAcross && tempNeighbor.y<descriptor.tilesDown)
			{
				int index=getFlatIndex(tempNeighbor);
				int indexOffset = cornerIndexOffset[i];
				xOffset = cornerOffsetX[indexOffset][index];
				yOffset = cornerOffsetY[indexOffset][index];
			}
			//Apply offsets
			corners[i*4].x=maskPoints[i].x + xOffset;
			corners[i*4].y=maskPoints[i].y + yOffset;
		}
		for(int i = 0; i < NEIGHBOR_COUNT/2; i++)
		{
			a = (Point2D.Double)reverseMaskTransform[i].transform(corners[i*4],a);
			b = (Point2D.Double)reverseMaskTransform[i].transform(corners[((i+1)%NEIGHBOR_COUNT)*4],b);
			double cp = (a.x+b.x)/2 + controlPointOffset[i][flatIndex];
			double bSize = bubbleSize[i][flatIndex];
			double bDirection = bubbleDirection[i][flatIndex];
			buildEdge(corners, controls, i, a.x, a.y, b.x, b.y, cp, bSize, bDirection);
			
			tempNeighbor.x = tileIndex.x + edgeTileOffset[i + NEIGHBOR_COUNT/2].x;
			tempNeighbor.y = tileIndex.y + edgeTileOffset[i + NEIGHBOR_COUNT/2].y;
			a = (Point2D.Double)reverseMaskTransform[i].transform(corners[(i+NEIGHBOR_COUNT/2)*4],a);
			b = (Point2D.Double)reverseMaskTransform[i].transform(corners[((i+NEIGHBOR_COUNT/2+1)%NEIGHBOR_COUNT)*4],b);
			if(tempNeighbor.x >= 0 && tempNeighbor.y >= 0 && tempNeighbor.x<descriptor.tilesAcross && tempNeighbor.y<descriptor.tilesDown)
			{
				int index = getFlatIndex(tempNeighbor);

				cp = (a.x+b.x)/2 + controlPointOffset[edgeIndexOffset[(i+NEIGHBOR_COUNT/2)]][index];
				bSize = bubbleSize[edgeIndexOffset[(i+NEIGHBOR_COUNT/2)]][index];
				bDirection = bubbleDirection[edgeIndexOffset[(i+NEIGHBOR_COUNT/2)]][index];
				buildEdge(corners, controls,i+NEIGHBOR_COUNT/2, a.x, a.y, b.x, b.y, cp, bSize, bDirection);
			}
			else
			{
				for(int j = 0; j < 6; j++)
				{
					controls[(i+NEIGHBOR_COUNT/2)*6+j].x=a.x;
					controls[(i+NEIGHBOR_COUNT/2)*6+j].y=a.y;
				}
				for(int j = 1; j < 4; j++)
				{
					corners[(i+NEIGHBOR_COUNT/2)*4+j].x=a.x;
					corners[(i+NEIGHBOR_COUNT/2)*4+j].y=a.y;
				}
			}
			for(int j = 0; j < 6; j++)
			{
				maskTransform[i].transform(controls[i*6+j],controls[i*6+j]);
				maskTransform[i].transform(controls[(i+NEIGHBOR_COUNT/2)*6+j],controls[(i+NEIGHBOR_COUNT/2)*6+j]);
			}
			for(int j = 1; j < 4; j++)
			{
				maskTransform[i].transform(corners[i*4+j],corners[i*4+j]);
				maskTransform[i].transform(corners[(i+NEIGHBOR_COUNT/2)*4+j],corners[(i+NEIGHBOR_COUNT/2)*4+j]);
			}
		}
//To do: move this to randomize(), so that buildEdge can use proper endpoints
		//Handle edge clipping
		int x = tileIndex.x;
		int y = tileIndex.y;
		int midX = descriptor.tileWidth/2;
		if(x<=1)
		{
			if(x==1)
			{
				for(int i=16; i<=20; i++)
					corners[i].x=-leftVariance;
				for(int i=24; i<30; i++)
					controls[i].x=-leftVariance;
			}
			else
			{
				corners[0].x=midX-leftVariance;
				for(int i=12; i<24; i++)
					corners[i].x=midX-leftVariance;
				for(int i=18; i<36; i++)
					controls[i].x=midX-leftVariance;
			}
		}
		else if(x>=descriptor.tilesAcross-2)
		{
			if(x==descriptor.tilesAcross-1)
			{
				for(int i=0; i <= 12; i++)
					corners[i].x=midX+rightVariance;
				for(int i=0; i<18; i++)
					controls[i].x=midX+rightVariance;
			}
			else
			{
				for(int i=4; i<=8; i++)
					corners[i].x = descriptor.tileWidth+rightVariance;
				for(int i=6; i<12; i++)
					controls[i].x = descriptor.tileWidth+rightVariance;
			}
		}
		
		if(y==0)
		{
			int yValue = descriptor.tileHeight/4 - topVariance;
			for(int i=0; i<=8; i++)
				corners[(20+i)%24].y=yValue;
			for(int i=0; i<12; i++)
				controls[(i+30)%36].y=yValue;
		}
		else if(y==descriptor.tilesDown-1)
		{
			double yValue = descriptor.tileHeight*3/4 + bottomVariance;
			for(int i=8; i<=16; i++)
				corners[i].y=yValue;
			for(int i=12; i<24; i++)
				controls[i].y=yValue;
		}
		//Draw the path
		Path2D.Double path = new Path2D.Double();
		path.moveTo((float)corners[0].x,(float)corners[0].y);

		for(int i=0; i < NEIGHBOR_COUNT; i++)
		{
			path.curveTo((float)controls[i*6].x,(float)controls[i*6].y,(float)controls[i*6+1].x,(float)controls[i*6+1].y,(float)corners[i*4 + 1].x,(float)corners[i*4 + 1].y);
			path.quadTo((float)controls[i*6+2].x,(float)controls[i*6+2].y,(float)corners[i*4 + 2].x,(float)corners[i*4 + 2].y);
			path.quadTo((float)controls[i*6+3].x,(float)controls[i*6+3].y,(float)corners[i*4 + 3].x,(float)corners[i*4 + 3].y);
			path.curveTo((float)controls[i*6+4].x,(float)controls[i*6+4].y,(float)controls[i*6+5].x,(float)controls[i*6+5].y,(float)corners[((i+1)%NEIGHBOR_COUNT)*4].x,(float)corners[((i+1)%NEIGHBOR_COUNT)*4].y);
		}
		
		return new Area(path);
		
	}
	
	private void buildEdge(Point2D.Double [] corners, Point2D.Double [] controls, int index, double x1, double y1, double x2, double y2, double cp, double bubbleSize, double bubbleDirection)
	{
		double direction = x2 - x1 > 0 ? 1 : -1;
		double midY = (y1 + y2)/2.0;
		//Base control point for bubble
		double midX = cp;
		double cpStemY1 = (y1*0.65 + y2*0.35);//y1 + yDiff;
		double cpStemY2 = (y2*0.65 + y1*0.35);//yDiff;
		//Outer bubble point
		double bubbleY = bubbleDirection*bubbleSize + midY;
		//Bubble control points will almost form a triangle - this makes the sides nearly even
		double temp = direction*Math.abs(bubbleY - midY)/sqrt3;
		double cpBubbleX1 = midX - temp;
		double cpBubbleX2 = midX + temp;
		//Stem points
		double stemX1 = (cpBubbleX1*0.25 + midX*0.75);
		double stemX2 = (cpBubbleX2*0.25 + midX*0.75);
		//Move the stem points away from the base line (up or down)
		double stemY1 = (bubbleY*0.25 + cpStemY1*0.75);
		double stemY2 = (bubbleY*0.25 + cpStemY2*0.75);

		controls[index*6].x=cp*0.6 + x1*0.4;
		controls[index*6].y=y1;
		controls[index*6+1].x=midX;
		controls[index*6+1].y=cpStemY1;
		corners[index*4 + 1].x=stemX1;
		corners[index*4 + 1].y=stemY1;

		controls[index*6+2].x=cpBubbleX1;
		controls[index*6+2].y=bubbleY;
		corners[index*4 + 2].x=midX;
		corners[index*4 + 2].y=bubbleY;
		
		controls[index*6+3].x=cpBubbleX2;
		controls[index*6+3].y=bubbleY;
		corners[index*4 + 3].x=stemX2;
		corners[index*4 + 3].y=stemY2;

		controls[index*6+4].x=midX;
		controls[index*6+4].y=cpStemY2;
		controls[index*6+5].x=cp*0.6 + x2*0.4;
		controls[index*6+5].y=y2;
	}

	private void randomize()
	{
		Random random = new Random();
		for(int i = 0; i < descriptor.tilesAcross; i++)
		{
			for(int j = 0; j < descriptor.tilesDown; j++)
			{
				if((i+j)%2==0)
				{
					//Convert to flat indexing
					int index = ((j+1)/2)*((descriptor.tilesAcross+1)/2) + (j/2)*(descriptor.tilesAcross/2) + i/2;
					
					for(int k=0; k < 2; k++)
					{
						cornerOffsetX[k][index] = (i==0 || i==descriptor.tilesAcross-1) ? 0 : random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
						cornerOffsetY[k][index] = random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
					}

					for(int k=0; k < 3; k++)
					{
						bubbleSize[k][index] = random.nextInt(bubbleMax - bubbleMin) + bubbleMin;
						bubbleDirection[k][index] = random.nextInt(2)*2-1;
						controlPointOffset[k][index] = controlPointVariance==0 ? 0 : random.nextInt(controlPointVariance*2 - 1) - controlPointVariance + 1;
					}
				}
			}
/*			if(i==descriptor.tilesAcross-1)
			{
				for(int j = 0; j < descriptor.tilesDown; j++)
				{
					if((i+j)%2==0)
					{
						//Convert to flat indexing
						int index = ((j+1)/2)*((descriptor.tilesAcross+1)/2) + (j/2)*(descriptor.tilesAcross/2) + i/2;
						
						for(int k=0; k < 2; k++)
						{
							cornerOffsetX[k][index] = 0;
							cornerOffsetY[k][index] = random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
						}

						for(int k=0; k < 3; k++)
						{
							bubbleSize[k][index] = random.nextInt(bubbleMax - bubbleMin) + bubbleMin;
							bubbleDirection[k][index] = random.nextInt(2)*2-1;
							controlPointOffset[k][index] = controlPointVariance==0 ? 0 : random.nextInt(controlPointVariance*2 - 1) - controlPointVariance + 1;
						}
					}
				}
			}
			else if(i==descriptor.tilesAcross-2)
			{
				for(int j = 0; j < descriptor.tilesDown; j++)
				{
					if((i+j)%2==0)
					{
						//Convert to flat indexing
						int index = ((j+1)/2)*((descriptor.tilesAcross+1)/2) + (j/2)*(descriptor.tilesAcross/2) + i/2;
						
						for(int k=0; k < 2; k++)
						{
							cornerOffsetX[k][index] = (i==0 || i==descriptor.tilesAcross-1) ? 0 : random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
							cornerOffsetY[k][index] = random.nextInt(cornerVariance*2 - 1) - cornerVariance + 1;
						}

						for(int k=0; k < 3; k++)
						{
							bubbleSize[k][index] = random.nextInt(bubbleMax - bubbleMin) + bubbleMin;
							bubbleDirection[k][index] = random.nextInt(2)*2-1;
							controlPointOffset[k][index] = controlPointVariance==0 ? 0 : random.nextInt(controlPointVariance*2 - 1) - controlPointVariance + 1;
						}
					}
				}
			}*/
		}
	}
}
