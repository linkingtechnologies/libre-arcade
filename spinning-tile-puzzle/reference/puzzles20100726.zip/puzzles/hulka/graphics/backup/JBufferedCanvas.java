package hulka.graphics;

import java.awt.*;
import java.awt.image.*;

import javax.imageio.ImageIO;

/**
 * BEGIN COPYRIGHT NOTICE============================================<br>
 * This module may be freely modified and used in any application
 * provided that:<br>
 * 1. The distributor of the software ensures that the source code
 * for this module is freely available.<br>
 * 2. A text file, named "freeware.txt" is placed in any install
 * directory(ies) of the class file(s) for this module, containing<br>
 *   a) The name of the compiled class file(s) for this module, and<br>
 *   b) Complete instructions on how to obtain the source code for
 *   this module.<br>
 * 3. This notice (Contained between the text 'BEGIN COPYRIGHT NOTICE'
 * above and 'END COPYRIGHT NOTICE' below) remains unchanged in the 
 * source code for this module, and appears in any documentation for
 * this module.<br>
 * 4. No names or contact information of developers who have worked
 * on this module are removed from the comments of the source code
 * for this module.<br>
 * 5. Any modules upon which this module depends may be freely
 * distributed with this module.<br>
 * ==============================================END COPYRIGHT NOTICE<br>
 * 
 * @author Jonathan Hulka (jon.hulka@gmail.com)
 *
 */

public class JBufferedCanvas extends javax.swing.JPanel{
    private JBufferedCanvas(){}
    BufferedImage backgroundImage;
    BufferedImage offscreenImage;
    public JBufferedCanvas(BufferedImage backgroundImage)
    {
        super();
        this.backgroundImage = backgroundImage;
        setPreferredSize(new Dimension(backgroundImage.getWidth(), backgroundImage.getHeight()));
        offscreenImage = new BufferedImage(backgroundImage.getWidth(this), backgroundImage.getHeight(this), backgroundImage.getType());
        offscreenImage.getGraphics().drawImage(backgroundImage, 0, 0, this);
    }
    
    public void paint(Graphics g)
    {
        Rectangle clipBounds = g.getClipBounds();
        int x = clipBounds.x;
        int y = clipBounds.y;
        int width = clipBounds.width;
        int height = clipBounds.height;
        g.drawImage(offscreenImage, x, y, x + width, y + height, x, y, x + width, y + height, this);
//        System.out.println("painting " + g.getClipBounds());      
    }
    
    public Graphics getForegroundGraphics()
    {
        return offscreenImage.getGraphics();
    }

    /**
    * @deprecated use repaint(int,int,int,int) instead
    *
    */
    @Deprecated public void updateRect(int x, int y, int width, int height)
    {
        repaint(x,y,width,height);
    }
    
    public void clearRect(int x, int y, int width, int height)
    {
        offscreenImage.getGraphics().drawImage(backgroundImage, x, y, x + width, y + height, x, y, x + width, y + height, this);
    }
    
    public void drawImage(Image image, int x, int y)
    {
        offscreenImage.getGraphics().drawImage(image, x, y, this);
    }
    
}
