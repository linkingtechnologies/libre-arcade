package hulka.graphics;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.Rectangle;

/**
 * BEGIN COPYRIGHT NOTICE============================================<br>
 * This module may be freely modified and used in any application
 * provided that:<br>
 * 1. The distributor of the software ensures that the source code
 * for this module is freely available.<br>
 * 2. A text file, named "freeware.txt" is placed in any install
 * directory(ies) of the class file(s) for this module, containing<br>
 *   a) The name of the compiled class file(s) for this module, and<br>
 *   b) Complete instructions on how to obtain the source code for
 *   this module.<br>
 * 3. This notice (Contained between the text 'BEGIN COPYRIGHT NOTICE'
 * above and 'END COPYRIGHT NOTICE' below) remains unchanged in the 
 * source code for this module, and appears in any documentation for
 * this module.<br>
 * 4. No names or contact information of developers who have worked
 * on this module are removed from the comments of the source code
 * for this module.<br>
 * 5. Any modules upon which this module depends may be freely
 * distributed with this module.<br>
 * ==============================================END COPYRIGHT NOTICE<br>
 * 
 * @author Jonathan Hulka (jon.hulka@gmail.com)
 * 
 *
*/
public class AnimatedDirectionalSprite {
	private int directionIncrement, frameCount, currentDirection, currentFrame;
	private int x, y, width, height;
	private BufferedImage [][] images;
	private Rectangle updateArea;
	
	/**
	 * Loads up the images used to draw the sprite.
	 * Images are assumed to be stored together in the specified directory
	 * images are named r<rotation>f<frame>.<imageExtension>
     * rotation and frame values are numbered from 0
	 * @param frameCount the number of frames in the animation cycle
	 * frameCount must be less than or equal to 16
	 * @param directionIncrement the angle in degrees between successive rotations of the sprite
	 * directionIncrement must divide into 360.
	 * @param imagePath the base path of the image files.
	 * @param imageExtension the image file extension
	 * @throws IOException if any of the images cannot be loaded.
	 */
	
	AnimatedDirectionalSprite(int frameCount, int directionIncrement, String imagePath, String imageExtension) throws IOException
	{
		this.directionIncrement = directionIncrement;
		this.frameCount = frameCount;
		currentDirection = 0;
		currentFrame = -1;
		loadImages(imagePath, imageExtension);
		x = 0;
		y = 0;
		width = 0;
		height = 0;
	}
	
	private void loadImages(String imagePath, String imageExtension) throws IOException
	{
		File imageFile;
		images = new BufferedImage[frameCount][360/directionIncrement];
		for(int j = 0; j < 360; j+=directionIncrement)
		{
			for(int i = 0; i < frameCount; i++)
			{
				imageFile = new File(imagePath + "r" + Integer.toHexString(i) + Integer.toHexString(j) + imageExtension);
				images[i][j/directionIncrement] = ImageIO.read(imageFile);
				width = Math.max(width, images[i][j].getWidth());
				height = Math.max(height, images[i][j].getHeight());
			}
		}
	}
	
	public int getWidth()
	{
		return width;
	}
	public int getHeight()
	{
		return height;
	}
	
	public void setDirection(int angle)
	{
		int a = angle;
		while(a < 0) a += 360;
        while(a >= 360) a-=360;
		currentDirection = ((a + directionIncrement/2)/directionIncrement)*directionIncrement;
	}
    
	public int getDirection()
	{
		return currentDirection;
	}

	/**
	 * Rotate the sprite
	 * @param angle the angle to rotate by.
	 * Positive for clockwise, negative for counter clockwise;
	 */
	public void rotate(int angle)
	{
        setDirection(currentDirection + angle);
		currentDirection = (currentDirection + count + directionCount)%directionCount;
	}

	public BufferedImage getImage()
	{
		return images[currentFrame][currentDirection/directionIncrement];
	}
	
	public void iterateFrame()
	{
		currentFrame = (currentFrame + 1)%frameCount;
	}
	
	public void setPosition(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	public void drawSprite(Graphics g)
	{
		try{
		int width = images[currentFrame][currentDirection].getWidth();
		int height = images[currentFrame][currentDirection].getHeight();
		g.drawImage(images[currentFrame][currentDirection], x, y);
		Rectangle area = new Rectangle(x,y,width,height);
		updateArea = (updateArea == null) ? area : updateArea.union(area);
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println(currentDirection);
			throw(ex);
		}
	}
	
	public void eraseSprite(Graphics gBack, Graphics gFore)
	{
		int width = images[currentFrame][currentDirection].getWidth();
		int height = images[currentFrame][currentDirection].getHeight();
		g.clearRect(x,y,width,height);
		Rectangle area = new Rectangle(x,y,width,height);
		updateArea = (updateArea == null) ? area : updateArea.union(area);
	}
	
	public void update(Graphics gBack, Graphics gFore)
	{
		if(updateArea != null)
		{
			c.updateRect((int)updateArea.getX(), (int)updateArea.getY(), (int)updateArea.getWidth(), (int)updateArea.getHeight());
			updateArea = null;
		}
	}
}
