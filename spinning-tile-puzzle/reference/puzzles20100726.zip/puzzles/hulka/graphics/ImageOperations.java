package hulka.graphics;
/*
 * Created on 14-May-2005
 *
 */
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;

/**
 * BEGIN COPYRIGHT NOTICE============================================<br>
 * This module may be freely modified and used in any application
 * provided that:<br>
 * 1. The distributor of the software ensures that the source code
 * for this module is freely available.<br>
 * 2. A text file, named "freeware.txt" is placed in any install
 * directory(ies) of the class file(s) for this module, containing<br>
 *   a) The name of the compiled class file(s) for this module, and<br>
 *   b) Complete instructions on how to obtain the source code for
 *   this module.<br>
 * 3. This notice (Contained between the text 'BEGIN COPYRIGHT NOTICE'
 * above and 'END COPYRIGHT NOTICE' below) remains unchanged in the 
 * source code for this module, and appears in any documentation for
 * this module.<br>
 * 4. No names or contact information of developers who have worked
 * on this module are removed from the comments of the source code
 * for this module.<br>
 * 5. Any modules upon which this module depends may be freely
 * distributed with this module.<br>
 * ==============================================END COPYRIGHT NOTICE<br>
 * 
 * @author Jonathan Hulka (jon.hulka@gmail.com)
 * This class provides functions for watermarking and adding faded borders
 * to an image, in addition to some other image operations.  These functions
 * are much more efficient than implementing the RGBImageFilter interface.
 * 
 */
public class ImageOperations {

    private static boolean debug = false;
    
    private int [] pixels = null;
    private int imageWidth = 0;
    private int imageHeight = 0;
    public void loadImage(BufferedImage image)
    {
        imageWidth = image.getWidth();
        imageHeight = image.getHeight();
        pixels = image.getRGB(0, 0, width, height, null, 0, width);
    }
    public void unloadImage()
    {
        imageWidth = 0;
        imageHeight = 0;
        pixels = null;
    }
    public void addFadedBorder(int borderWidth, Color borderColor)
    {
        int bRGB = borderColor.getRGB();
        int rBorder = bRGB & 0x0FF0000;
        int gBorder = bRGB & 0x0FF00;
        int bBorder = bRGB & 0x0FF;
        int i, i1, i2, j, j1, j2, rBorderFactor, gBorderFactor, bBorderFactor, pRGB, r, g, b, dx, dy, end;
        
        for(dy = 0; dy < borderWidth; dy++)
        {
            j1 = dy;
            j2 = imageWidth - dy - 1;
            rBorderFactor = rBorder*(borderWidth - dy);
            gBorderFactor = gBorder*(borderWidth - dy);
            bBorderFactor = bBorder*(borderWidth - dy);
            end = imageWidth - dy - 1;
            for(i = dy + 1; i < end; i ++)
            {
                pRGB = pixels[i + j1 * imageWidth];
                b = pRGB & 0x0FF;
                g = pRGB & 0x0FF00;
                r = pRGB & 0x0FF0000;
                            
                r = ((r * dy + rBorderFactor)/borderWidth) & 0x0FF0000;
                g = ((g * dy + gBorderFactor)/borderWidth) & 0x0FF00;
                b = ((b * dy + bBorderFactor)/borderWidth) & 0x0FF;

                pixels[i + j1 * imageWidth] = pRGB & 0x0FF000000 | r & 0x0FF0000 | g & 0x0FF00 | b & 0x0FF;                

                pRGB = pixels[i + j2 * imageWidth];
                b = pRGB & 0x0FF;
                g = pRGB & 0x0FF00;
                r = pRGB & 0x0FF0000;
                            
                r = ((r * dy + rBorderFactor)/borderWidth) & 0x0FF0000;
                g = ((g * dy + gBorderFactor)/borderWidth) & 0x0FF00;
                b = ((b * dy + bBorderFactor)/borderWidth) & 0x0FF;

                pixels[i + j2 * imageWidth] = pRGB & 0x0FF000000 | r & 0x0FF0000 | g & 0x0FF00 | b & 0x0FF;                
            }            
        }
        
        for(dx = 0; dx < borderWidth; dx ++)
        {
            i1 = dx;
            i2 = imageWidth - dx - 1;
            rBorderFactor = rBorder*(borderWidth - dx);
            gBorderFactor = gBorder*(borderWidth - dx);
            bBorderFactor = bBorder*(borderWidth - dx);
            end = imageHeight - dx;
            for(j = dx; j < end; j++)
            {
                pRGB = pixels[i1 + j * imageWidth];
                b = pRGB & 0x0FF;
                g = pRGB & 0x0FF00;
                r = pRGB & 0x0FF0000;
                            
                r = ((r * dx + rBorderFactor)/borderWidth) & 0x0FF0000;
                g = ((g * dx + gBorderFactor)/borderWidth) & 0x0FF00;
                b = ((b * dx + bBorderFactor)/borderWidth) & 0x0FF;

                pixels[i1 + j * imageWidth] = pRGB & 0x0FF000000 | r & 0x0FF0000 | g & 0x0FF00 | b & 0x0FF;                

                pRGB = pixels[i2 + j * imageWidth];
                b = pRGB & 0x0FF;
                g = pRGB & 0x0FF00;
                r = pRGB & 0x0FF0000;
                            
                r = ((r * dx + rBorderFactor)/borderWidth) & 0x0FF0000;
                g = ((g * dx + gBorderFactor)/borderWidth) & 0x0FF00;
                b = ((b * dx + bBorderFactor)/borderWidth) & 0x0FF;

                pixels[i2 + j * imageWidth] = pRGB & 0x0FF000000 | r & 0x0FF0000 | g & 0x0FF00 | b & 0x0FF;                
            }
            
        }
    }
    

    
    public void addSolidBorder(int borderWidth, Color borderColor)
    {
        int bRGB = borderColor.getRGB() & 0x0FFFFFF;
        for(int dw = 0; dw < borderWidth; dw++)
        {
            int i2 = imageWidth - dw - 1;
            for(int j = 0; j < imageWidth; j++)
            {
                int yOffset = j*imageWidth;
                pixels[dw + yOffset] = pixels[dw + yOffset] & 0x0FF000000 | bRGB;
                pixels[i2 + yOffset] = pixels[i2 + yOffset] & 0x0FF000000 | bRGB;
            }
            
            int j2 = imageHeight - dw - 1;
            int yOffset1 = dw*imageWidth;
            int yOffset2 = j2*imageWidth;
            for(int i = 0; i < imageHeight; i++)
            {
                pixels[i + yOffset] = pixels[i + yOffset] & 0x0FF000000 | bRGB;
                pixels[i + yOffset2] = pixels[i + yOffset2] & 0x0FF000000 | bRGB;
            }

        }
    }
    
    public static void watermarkImageDark(BufferedImage wm, int x, int y, double opacity)
    {
        int iOpacity = (int)(opacity * 256);
        //Clip the watermark where it runs off the edge of the image
        //In case watermark runs off the left edge
        int wmX = Math.max(0, -1 * x);
        int imgX = Math.max(0, x);
        //In case watermark runs off the top
        int wmY = Math.max(0, -1 * y);
        int imgY = Math.max(0, y);

        //In case watermark runs off the right edge
        int wmWidth = Math.min(imageWidth - x, wm.getWidth());
        //In case watermark runs off the left edge
        wmWidth = Math.min(wmWidth, wmWidth + x);
        //In case watermark runs off the bottom
        int wmHeight = Math.min(imageHeight - y, wm.getHeight());
        //In case watermark runs off the top
        wmHeight = Math.min(wmHeight, wmHeight + y);

        int [] wmRGB = wm.getRGB(wmX, wmY, wmWidth, wmHeight, null, 0, wmWidth);
        

        for(int j = 0; j < wmHeight; j ++)
        {
            for(int i = 0; i < wmWidth; i ++)
            {
                int imgI = i + imgX;
                int imgJ = j + imgY;
                //Extract components of the image pixel
                int RGB = pixels[imgI + imgJ * imageWidth];
                int b = RGB & 0x0FF;
                int g = (RGB >> 8) & 0x0FF;
                int r = (RGB >> 16) & 0x0FF;

                //Extract components of the filter pixel
                int fRGB = wmRGB[i + j * wmWidth];

                int fa = (fRGB >> 24) & 0x00FF;
                //Adjust the opacity of this filter pixel for the alpha value
                int fOpacity = iOpacity*fa/0x0ff;

                int fb = fRGB & 0x0FF;
                int fg = (fRGB >> 8) & 0x0FF;
                int fr = (fRGB >> 16) & 0x0FF;
            
                r = r - ((((0x0ff - fr) * fOpacity >> 8) * r) >> 8);
                g = g - ((((0x0ff - fg) * fOpacity >> 8) * g) >> 8);
                b = b - ((((0x0ff - fb) * fOpacity >> 8) * b) >> 8);

                imageRGB[i + j * wmWidth] = RGB & 0x0FF000000 | (r << 16) & 0x0FF0000 | (g << 8) & 0x0FF00 | b & 0x0FF;
            }
        }
        image.setRGB(imgX, imgY, wmWidth, wmHeight, imageRGB, 0, wmWidth);
    }

    public static void watermarkImageLight(BufferedImage image, BufferedImage wm, int x, int y, double opacity)
    {
        int iOpacity = (int)(opacity * 256);

        //Clip the watermark where it runs off the edge of the image
        //In case watermark runs off the left edge
        int wmX = Math.max(0, -1 * x);
        int imgX = Math.max(0, x);
        //In case watermark runs off the top
        int wmY = Math.max(0, -1 * y);
        int imgY = Math.max(0, y);

        //In case watermark runs off the right edge
        int wmWidth = Math.min(image.getWidth() - x, wm.getWidth());
        //In case watermark runs off the left edge
        wmWidth = Math.min(wmWidth, wmWidth + x);
        //In case watermark runs off the bottom
        int wmHeight = Math.min(image.getHeight() - y, wm.getHeight());
        //In case watermark runs off the top
        wmHeight = Math.min(wmHeight, wmHeight + y);

        int [] wmRGB = wm.getRGB(wmX, wmY, wmWidth, wmHeight, null, 0, wmWidth);
        int [] imageRGB = image.getRGB(imgX, imgY, wmWidth, wmHeight, null, 0, wmWidth);
        

        for(int j = 0; j < wmHeight; j ++)
        {
            for(int i = 0; i < wmWidth; i ++)
            {
                //Extract components of the image pixel
                int RGB = imageRGB[i + j * wmWidth];
                int b = RGB & 0x0FF;
                int g = (RGB & 0x0FF00) >> 8;
                int r = (RGB & 0x0FF0000) >> 16;

                //Extract components of the filter pixel
                int fRGB = wmRGB[i + j * wmWidth];

                int fa = (fRGB >> 24) & 0x00FF;
                //Adjust the opacity of this filter pixel for the alpha value
                int fOpacity = iOpacity*fa/0x0FF;

                int fb = fRGB & 0x0FF;
                int fg = (fRGB >> 8) & 0x0FF;
                int fr = (fRGB >> 16) & 0x0FF;
            
                r = r + (( (fr * fOpacity >> 8) * (0x0ff - r)) >> 8);
                g = g + (( (fg * fOpacity >> 8) * (0x0ff - g)) >> 8);
                b = b + (( (fb * fOpacity >> 8) * (0x0ff - b)) >> 8);

                imageRGB[i + j * wmWidth] = (RGB & 0x0FF000000) | ((r << 16) & 0x0FF0000) | ((g << 8) & 0x0FF00) | (b & 0x0FF);
            }
        }
        image.setRGB(imgX, imgY, wmWidth, wmHeight, imageRGB, 0, wmWidth);
    }
    
    /**
     * Convert the image to an opaque rendering of the original image over a background of the specified color
     * NOTE - the original image is modified
     * @param image Image to convert
     * @param r background red component
     * @param g background green component
     * @param b background blue component
     * @return
     */
    public static BufferedImage convertAlpha(BufferedImage image, int r, int g, int b)
    {
        String debugText = null;
        if (debug) System.out.println("converting Alpha");
        for(int j = 0; j < pixelcount; j+= width)
        {
            if (debug) debugText = "";
            for(int i = 0; i < image.getWidth(); i++)
            {
                int pixel = pixels[i + j];
                //extract the foreground components
                int fa = (pixel >> 24) & 0x0ff;
                int fr = (pixel >> 16) & 0x0ff;
                int fg = (pixel >> 8) & 0x0ff;
                int fb = pixel & 0x0ff;
                if (debug) debugText += "\t" + fa;
                
                //Convert
                fr = fr*fa/0x0ff + r*(0x0ff - fa)/0x0ff;
                fg = fg*fa/0x0ff + g*(0x0ff - fa)/0x0ff;
                fb = fb*fa/0x0ff + b*(0x0ff - fa)/0x0ff;
                //make the output opaque
                fa = 0x0ff;
                
                pixels[i + j] = fa << 24 | fr << 16 | fg << 8 | fb;
            }
            if (debug) System.out.println(debugText);
        }
        image.setRGB(0, 0, width, height, pixels, 0, width);
        
        return image;    
    }

//NOTE: this will not work if the opaque and transparent colors have the same intensity
    /**
    * Convert the specified range to graduated transparency, setting all
    * pixels within the range to the color specified by the opaque components
    */
    public static BufferedImage makeTransparent(BufferedImage image, int rOpaque, int gOpaque, int bOpaque, int rTrans, int gTrans, int bTrans, double err)
    {
        int tolerance = (int)(255*Math.max(Math.min(err,1),0));
        //Calculate the intensities of the opaque and transparent colors
        //Rounded to the nearest integer
        rTrans &= 0x0ff;
        gTrans &= 0x0ff;
        bTrans &= 0x0ff;
        rOpaque &= 0x0ff;
        gOpaque &= 0x0ff;
        bOpaque &= 0x0ff;
        int rgbOpaque = rOpaque << 16 | gOpaque << 8 | bOpaque;
        int vTrans = (rTrans + gTrans + bTrans)/3;
        int vOpaque = (rOpaque + gOpaque + bOpaque)/3;
        //Determine the intensity differential
        int vDelta = vOpaque - vTrans;
        int rDelta = rOpaque - rTrans;
        int gDelta = gOpaque - gTrans;
         int bDelta = bOpaque - bTrans;
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelcount = width*height;
        int [] pixels = image.getRGB(0, 0, width, height, null, 0, width);
 //       String debug = "";
        for(int j = 0; j < pixelcount; j+= width)
        {
            for(int i = 0; i < image.getWidth(); i++)
            {
                int pixel = pixels[i + j];
                //extract the foreground components
                int r = (pixel >> 16) & 0x0ff;
                int g = (pixel >> 8) & 0x0ff;
                int b = pixel & 0x0ff;
                //Determine the pixel intensity
                int v = (r + g + b)/3;
                //Calculate the transparency based on pixel intensity
                int a = ((v - vTrans)<<8)/vDelta;
                if(a >= 0)
                {
                    int rTest = (a*rDelta)/0x0100 + rTrans;
                    if((rTest + tolerance >= r) && (rTest - tolerance <= r))
                    {
                        int gTest = (a*gDelta)/0x0100 + gTrans;
                        if((gTest + tolerance >= g) && (gTest - tolerance <= g))
                        {
                            int bTest = (a*bDelta)/0x0100 + bTrans;
                            if((bTest + tolerance >= b) && (bTest - tolerance <= b))
                            {
                                if(a >0x0ff) a=0x0ff;
                                pixels[i + j] = a << 24 | rgbOpaque;
//                                pixels[i + j] = 0xff000000| a ;

                            }
                        }
                    }
                }
                
            }
//            System.out.println(debug);
//            debug = "";
        }
        image.setRGB(0, 0, width, height, pixels, 0, width);
        
        return image;    
    }
    
    /**
     * Create a negative of the image
     * @param image
     * @return
     */
    public static BufferedImage negateImage(BufferedImage image)
    {
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelcount = width*height;
        int [] pixels = image.getRGB(0, 0, width, height, null, 0, width);
        for(int j = 0; j < pixelcount; j+= width)
        {
            for(int i = 0; i < image.getWidth(); i++)
            {
                int pixel = pixels[i + j];
                int fa = (pixel >> 24) & 0x0ff;
                int fr = (pixel >> 16) & 0x0ff;
                int fg = (pixel >> 8) & 0x0ff;
                int fb = pixel & 0x0ff;
                
                //Convert
                fr = 255-fr;
                fg = 255-fg;
                fb = 255-fb;
                
                pixels[i + j] = fa << 24 | fr << 16 | fg << 8 | fb;
            }
        }
        image.setRGB(0, 0, width, height, pixels, 0, width);
        
        return image;    
    }

    /**
     * Negate the image intensity, while preserving its hue and saturation
     * The results of this operation are unpredictable, as a nearly black pixel doesn't always
     * turn out nearly white. ie RGB 0,0,1 becomes a very intense blue, etc
     * @param image
     * @return
     */
    public static BufferedImage negateImageIntensity(BufferedImage image)
    {
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelcount = width*height;
        int [] pixels = image.getRGB(0, 0, width, height, null, 0, width);
        for(int j = 0; j < pixelcount; j+= width)
        {
            for(int i = 0; i < image.getWidth(); i++)
            {
                int pixel = pixels[i + j];
                int fa = (pixel >> 24) & 0x0ff;
                int fr = (pixel >> 16) & 0x0ff;
                int fg = (pixel >> 8) & 0x0ff;
                int fb = pixel & 0x0ff;
                float [] hsbValues;
                
                hsbValues = Color.RGBtoHSB(fr,fg,fb,null);
                float brightness = 1 - hsbValues[2];
                pixels[i + j] = (fa & 0x0ff) << 24 | (Color.HSBtoRGB(hsbValues[0],hsbValues[1],brightness) & 0x0ffffff);
            }
        }
        image.setRGB(0, 0, width, height, pixels, 0, width);
        
        return image;    
    }
     
    /**
    * Convert a range of rgb values within the image to another range of values
    */
    public static BufferedImage convertRange(BufferedImage image, int r1, int g1, int b1, int r2, int g2, int b2, int newr1, int newg1, int newb1, int newr2, int newg2, int newb2, double err)
    {
        int tolerance = (int)(255*Math.max(Math.min(err,1),0));
        //Calculate the intensities of the opaque and transparent colors
        //Rounded to the nearest integer
        r2 &= 0x0ff;
        g2 &= 0x0ff;
        b2 &= 0x0ff;
        r1 &= 0x0ff;
        g1 &= 0x0ff;
        b1 &= 0x0ff;
        int rgb1 = r1 << 16 | g1 << 8 | b1;
        int v2 = (r2 + g2 + b2)/3;
        int v1 = (r1 + g1 + b1)/3;
        //Determine the intensity differential
        int vDelta = v1 - v2;
        int rDelta = r1 - r2;
        int newrDelta = newr1 - newr2;
        int gDelta = g1 - g2;
        int newgDelta = newg1 - newg2;
         int bDelta = b1 - b2;
        int newbDelta = newb1 - newb2;
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelcount = width*height;
        int [] pixels = image.getRGB(0, 0, width, height, null, 0, width);
        for(int j = 0; j < pixelcount; j+= width)
        {
            for(int i = 0; i < image.getWidth(); i++)
            {
                int pixel = pixels[i + j];
                //extract the foreground components
                int a = pixel & 0x0ff000000;
                int r = (pixel >> 16) & 0x0ff;
                int g = (pixel >> 8) & 0x0ff;
                int b = pixel & 0x0ff;
                //Determine the pixel intensity
                int v = (r + g + b)/3;
                //Calculate the coefficient based on pixel intensity
                int c = ((v - v2)<<8)/vDelta;
                if(c >= 0)
                {
                    int rTest = (c*rDelta)/0x0100 + r2;
                    if((rTest + tolerance >= r) && (rTest - tolerance <= r))
                    {
                        int gTest = (c*gDelta)/0x0100 + g2;
                        if((gTest + tolerance >= g) && (gTest - tolerance <= g))
                        {
                            int bTest = (c*bDelta)/0x0100 + b2;
                            if((bTest + tolerance >= b) && (bTest - tolerance <= b))
                            {
                                int rOut = (c*newrDelta)/0x0100 + newr2;
                                int gOut = (c*newgDelta)/0x0100 + newg2;
                                int bOut = (c*newbDelta)/0x0100 + newb2;
                                pixels[i + j] = a | (rOut << 16) | (gOut << 8) | bOut;

                            }
                        }
                    }
                }
                
            }
        }
        image.setRGB(0, 0, width, height, pixels, 0, width);
        
        return image;    
    }
//NOTE: this will not work if the opaque and transparent colors have the same intensity
//To do - change the algorithm to test using the color component with the greatest
//        intensity differential
    /**
    * Convert the specified range to graduated transparency, preserving the
    * rgb values of all pixels
    */
    public static BufferedImage makeTransparent2(BufferedImage image, int rOpaque, int gOpaque, int bOpaque, int rTrans, int gTrans, int bTrans, double err)
    {
        int tolerance = (int)(255*Math.max(Math.min(err,1),0));
        //Calculate the intensities of the opaque and transparent colors
        //Rounded to the nearest integer
        rTrans &= 0x0ff;
        gTrans &= 0x0ff;
        bTrans &= 0x0ff;
        rOpaque &= 0x0ff;
        gOpaque &= 0x0ff;
        bOpaque &= 0x0ff;
        int rgbOpaque = rOpaque << 16 | gOpaque << 8 | bOpaque;
        int vTrans = (rTrans + gTrans + bTrans)/3;
        int vOpaque = (rOpaque + gOpaque + bOpaque)/3;
        //Determine the intensity differential
        int vDelta = vOpaque - vTrans;
        int rDelta = rOpaque - rTrans;
        int gDelta = gOpaque - gTrans;
         int bDelta = bOpaque - bTrans;
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelcount = width*height;
        int [] pixels = image.getRGB(0, 0, width, height, null, 0, width);
        for(int j = 0; j < pixelcount; j+= width)
        {
            for(int i = 0; i < image.getWidth(); i++)
            {
                int pixel = pixels[i + j];
                //extract the foreground components
                int r = (pixel >> 16) & 0x0ff;
                int g = (pixel >> 8) & 0x0ff;
                int b = pixel & 0x0ff;
                //Determine the pixel intensity
                int v = (r + g + b)/3;
                //Calculate the transparency based on pixel intensity
                int a = ((v - vTrans)<<8)/vDelta;
                if(a >= 0)
                {
                    int rTest = (a*rDelta)/0x0100 + rTrans;
                    if((rTest + tolerance >= r) && (rTest - tolerance <= r))
                    {
                        int gTest = (a*gDelta)/0x0100 + gTrans;
                        if((gTest + tolerance >= g) && (gTest - tolerance <= g))
                        {
                            int bTest = (a*bDelta)/0x0100 + bTrans;
                            if((bTest + tolerance >= b) && (bTest - tolerance <= b))
                            {
                                if(a >0x0ff) a=0x0ff;
                                pixels[i + j] = a << 24 | (pixel & 0x0ffffff);

                            }
                        }
                    }
                }
                
            }
        }
        image.setRGB(0, 0, width, height, pixels, 0, width);
        
        return image;    
    }

}
