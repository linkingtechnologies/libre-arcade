/*
 *      Copyright 2009 Jonathan Hulka <jon.hulka@gmail.com>
 *      
 *      This is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      This software is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with the software.  If not, see <http://www.gnu.org/licenses/>.
 *      
 * 
 * @author Jonathan Hulka (jon.hulka@gmail.com)
 * 
 */

package hulka.license;
import hulka.util.MiscUtils;
import java.awt.event.*;
import java.awt.event.*;
import javax.swing.*;

class LicenseDialogListener implements ActionListener
{
	private JDialog dialog;
	private LicenseParameters parameters;
	public LicenseDialogListener(JDialog dialog, LicenseParameters parameters)
	{
		this.dialog = dialog;
		this.parameters = parameters;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String cmd = e.getActionCommand();
		if(cmd.equals("ok"))
		{
			dialog.setVisible(false);
		}
		else if(cmd.equals("website"))
		{
			MiscUtils.openBrowser(parameters.getHomePage());
		}
	}
}
