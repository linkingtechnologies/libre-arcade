/*
 *      LicenseUI.java
 * 
 *      Copyright 2009 Jonathan Hulka <jon.hulka@gmail.com>
 *      
 *      This is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      This software is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with the software.  If not, see <http://www.gnu.org/licenses/>.
 *      
 * 
 * @author Jonathan Hulka (jon.hulka@gmail.com)
 * 
 */

package hulka.license;

import hulka.util.MiscUtils;

import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.image.*;


public class LicenseUI
{
	public static JDialog getLicenseDialog(LicenseParameters parameters, JFrame owner)
	{
		JDialog licenseDialog = new JDialog(owner, parameters.getAppName() + " " + parameters.getAppVersion(), true);
		LicenseDialogListener listener = new LicenseDialogListener(licenseDialog, parameters);
		licenseDialog.setContentPane(buildLicensePane(parameters, listener));
//Not compatible with 1.5
//		licenseDialog.setIconImage(loadImage(parameters.getAppIconPath(),32,32));
		return licenseDialog;
	}

	private static JPanel buildLicensePane(LicenseParameters parameters, LicenseDialogListener listener)
	{
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		JPanel licensePane = new JPanel();

		GridBagLayout layout = new GridBagLayout();
		licensePane.setLayout(layout);
		GridBagConstraints constraints = new GridBagConstraints();

		
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.weightx=1;
		constraints.weighty=0;
		constraints.gridwidth = 1;
		constraints.gridheight = 1;
		constraints.fill = GridBagConstraints.BOTH;
		constraints.insets = new Insets(5,5,5,5);
		JTextPane noticeTextPane = new JTextPane();
		try
		{
			URL url = classLoader.getResource(parameters.getCopyrightPath());
			noticeTextPane.setPage(url);
		} 
		catch (Exception ex)
		{
			ex.printStackTrace();
		}

		noticeTextPane.setEditable(false);
		layout.setConstraints(noticeTextPane,constraints);
		licensePane.add(noticeTextPane);

		JButton licenseConnectButton = new JButton(new ImageIcon(MiscUtils.loadImage(parameters.getWebsiteIconPath(),256,256)));
		licenseConnectButton.setToolTipText("visit " + parameters.getHomePage());
		licenseConnectButton.setActionCommand("website");
		constraints.gridx++;
		constraints.weightx=0;
		layout.setConstraints(licenseConnectButton,constraints);
		licensePane.add(licenseConnectButton);
 
		JTextPane licenseTextPane = new JTextPane();
		licenseTextPane.setEditable(false);
		JScrollPane licenseScrollPane = new JScrollPane();
		licenseScrollPane.getViewport().add(licenseTextPane);
  
		try
		{
			URL url = classLoader.getResource(parameters.getLicensePath());
			licenseTextPane.setPage(url);
		} 
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		
		constraints.gridy++;
		constraints.gridx=0;
		constraints.gridwidth = 2;
		constraints.weighty=1;
		constraints.weightx=1;
		licenseScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		layout.setConstraints(licenseScrollPane,constraints);
		licensePane.add(licenseScrollPane);

		constraints.weighty=0;
		JButton licenseContinueButton = new JButton(new ImageIcon(MiscUtils.loadImage(parameters.getOKIconPath(),32,32)));
		licenseContinueButton.setToolTipText("ok");
		licenseContinueButton.setActionCommand("ok");
		constraints.fill = GridBagConstraints.NONE;
		constraints.gridx = 0;
		constraints.gridy++;
		layout.setConstraints(licenseContinueButton,constraints);
		licensePane.add(licenseContinueButton);

		licenseConnectButton.addActionListener(listener);
		licenseContinueButton.addActionListener(listener);

		return licensePane;
	}

}
