/*
 *      KeyStrokeAction.java
 *      
 *      Copyright 2008 Jonathan Hulka <jon.hulka@gmail.com>
 *      
 *      This file is part of aMaze.
 *      
 *      aMaze is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      aMaze is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with aMaze.  If not, see <http://www.gnu.org/licenses/>.
 *      
 */
package hulka.event;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
 	public class KeyStrokeAction extends AbstractAction
	{
		String command;
		ActionListener listener;
		public KeyStrokeAction(String command, ActionListener listener)
		{
			super();
			this.command = command;
			this.listener = listener;
		}
		public void actionPerformed(ActionEvent e)
		{
			listener.actionPerformed(new ActionEvent(e.getSource(), e.getID(), command, e.getModifiers()));
		}
	}
