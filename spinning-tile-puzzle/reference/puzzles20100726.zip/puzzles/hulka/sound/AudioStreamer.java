/*
 * AudioStreamer.java
 *       Copyright 2005, 2009 Jonathan Hulka <jon.hulka@gmail.com>
 *      
 *      This is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      This software is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with the software.  If not, see <http://www.gnu.org/licenses/>.
 *      
 * 
 * @author Jonathan Hulka (jon.hulka@gmail.com)
 * 
 */

package hulka.sound;

/*This class implements the ability to merge multiple sound streams
 * into one data line
 */
import javax.sound.sampled.*;

import java.io.FileInputStream;
import java.io.File;
import java.util.Hashtable;
import java.net.URL;


public class AudioStreamer implements Runnable
{
	//Controls the amount of data that will be stored in the buffer
	//at any time. Making this smaller will cause the sound stream
	//to be more responsive, but will be more CPU intensive
	private static int bufferThresholdMillis = 50;
	private SourceDataLine line = null;
	
	private int bufferThresholdBytes;
	private int bufferSize;
	
	private int bytesPerSample;
	private long [] longSamples;
	private byte [] byteSamples;
	
	//PLEASE NOTE: These two could be accessed by asynchronous threads
	//Make sure access is synchronized
	private long [][] inputStreams;
	private int [] streamIndex;

	/*Following are the critical sections. These perform operations on the
	 * shared resource - inputStreams*/
	
	//add an input stream
	public synchronized void addStream(long [] stream)
	{
		if(inputStreams==null)
		{
			inputStreams = new long[1][];
			inputStreams[0] = stream;
			streamIndex = new int[1];
			streamIndex[0] = 0;
		}
		else
		{
			long [][] temp = inputStreams;
			inputStreams = new long[temp.length + 1][];
			for(int i = 0; i < temp.length; i++)
			{
				inputStreams[i] = temp[i];
			}
			int [] tempIndex = streamIndex;
			streamIndex = new int[inputStreams.length];
			for(int i = 0; i < tempIndex.length; i++)
			{
				streamIndex[i] = tempIndex[i];
			}
			inputStreams[temp.length] = stream;
			streamIndex[temp.length] = 0;
		}
	}
	
	//Merge any streams that are present into one output stream,
	//adjusting stream indices and damping the attenuation
	private synchronized void calculateOutput(long [] output, int length)
	{
		for(int i = 0; i < length; i++)
		{
			int streamCount = inputStreams == null ? 0 : inputStreams.length;
//			double maxPossibleSignal = streamCount*attenuationLimit;
			long value = 0;
			
			//Get values from each stream
			//Iterate backwards so that finished streams can be removed
			//without affecting the next iteration
			for(int j = streamCount - 1; j >= 0; j--)
			{
				value += inputStreams[j][streamIndex[j]];
				streamIndex[j] ++;
				//Check if any streams end at this point
				if(streamIndex[j]>=inputStreams[j].length)
				{
					//Stream ends here
					if(inputStreams.length==1)
					{
						//There are no more streams
						inputStreams = null;
						streamIndex = null;
					}
					else
					{
						//Remove the stream
						long [][] temp = inputStreams;
						inputStreams = new long[temp.length - 1][];
						int [] tempIndex = streamIndex;
						streamIndex = new int[inputStreams.length];
						for(int k = 0; k < j; k++)
						{
							inputStreams[k] = temp[k];
							streamIndex[k] = tempIndex[k];
						}
						for(int k = j + 1; k < inputStreams.length; k++)
						{
							inputStreams[k - 1] = temp[k];
							streamIndex[k - 1] = tempIndex[k];
						}
					}
				}
			}
			

			//Only merge streams if there are more than one to merge
			if(streamCount > 1)
			{
//				long sign = value > 0 ? 1 : -1;
//				double dValue = (double)(value*sign);
				
				//uber simple gain control function, seems to work perfectly
				//ask the DSP guys if this is the way to do it.
				value /= streamCount;
				
//				value = sign*(long)dValue;
			}
			output[i] = value;
		}
	}

	/*End of critical sections*/

	public AudioStreamer(AudioFormat format) throws LineUnavailableException
	{
		//Set up the DataLine
		line = null;
		SourceDataLine.Info	info = new DataLine.Info(SourceDataLine.class,
												 format);
		line = (SourceDataLine) AudioSystem.getLine(info);
		bufferSize = line.getBufferSize();
		line.open(format);
		bytesPerSample = format.getSampleSizeInBits()/8;
		
		//Set up the buffer
		int bufferThresholdLong =  (int)format.getSampleRate() * bufferThresholdMillis / 1000;
		longSamples = new long [bufferThresholdLong];

		bufferThresholdBytes = bufferThresholdLong*bytesPerSample;
		byteSamples = new byte [bufferThresholdBytes];
		
		//Start waiting for audio
		line.start();
		new Thread(this).start();
	}
	
	public void stop()
	{
		line.stop();
		line.close();
	}

	public void run()
	{
		//This is the working loop, it feeds data into the line
		while(line.isOpen())
		{
			if(bufferSize - line.available() < bufferThresholdBytes)
			{
				//Get the next chunk of data
				calculateOutput(longSamples,longSamples.length);
				for(int i = 0; i < longSamples.length; i++)
				{
					long sample = longSamples[i];
					for(int j = 0; j < bytesPerSample; j++)
					{
						//Convert back to bytes for output
						byteSamples[i*bytesPerSample + j] = (byte)((sample >> ((bytesPerSample - j)*8)) & 0x00ff);

					}
				}
				//Output to the audio system
				line.write(byteSamples,0,bufferThresholdBytes);
			}
			//Wait for a bit less than half the time it should take to empty the buffer
			try{Thread.sleep(bufferThresholdMillis*2/5);}catch(Exception ex){}
		}
	}
	
}
