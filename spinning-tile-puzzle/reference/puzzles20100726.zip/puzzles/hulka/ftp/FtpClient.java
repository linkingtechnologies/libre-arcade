import java.net.*;
import java.io.*;
import java.util.*;

/**
 * @author Jonathan Hulka
 *
 * If an exception is thrown, the getResponse and getResponseCode functions may help to determine the cause.
 * This class may need modification to work with some servers.
 */
public class FtpClient {
	private String response;
	private int responseCode;
	private Socket commandConnection;
//	private int commandPort;
	private boolean dataPortOpen;

	private ServerSocket dataConnection;
	private BufferedReader commandIn;
	private BufferedWriter commandOut;
	private static String newLine = "\r\n";
	
	public FtpClient()
	{
		dataPortOpen = false;
		response = null;
		responseCode = 0;
		commandConnection = null;
		dataConnection = null;
		commandIn = null;
		commandOut = null;
	}
	
	/**
	 * 
	 * @param server
	 * @return on success - 220 (welcome message)
	 * @throws FtpClientException
	 */
	public int connect(String server) throws FtpClientException
	{
		assertDisconnected();

		try
		{
			commandConnection = new Socket(server,21);
		}
		catch(IOException ex)
		{
			commandConnection = null;
			response = null;
			responseCode = 0;
			throw new FtpClientException("Unable to connect to the server.", ex);
		}
		
		try
		{
			commandIn = new BufferedReader(new InputStreamReader(commandConnection.getInputStream()));
		}
		catch(IOException ex)
		{
			try
			{
				commandConnection.close();
			}
			catch(IOException exex){}
			commandConnection = null;
			response = null;
			responseCode = 0;
			throw new FtpClientException("Unable to open an input stream.", ex);
		}
		
		try
		{
			commandOut = new BufferedWriter(new OutputStreamWriter(commandConnection.getOutputStream()));
		}
		catch(IOException ex)
		{
			try
			{
				commandConnection.close();
			}
			catch(IOException exex){}
			commandConnection = null;
			response = null;
			responseCode = 0;
			throw new FtpClientException("Unable to open an output stream.", ex);
		}
		
		assertResponse(220); //Welcome message
		
		return responseCode;
	}
	
	/**
	 * 
	 * @throws FtpClientException
	 */
	public void disconnect() throws FtpClientException
	{
		assertConnected();
		try
		{
			commandConnection.close();
		}
		catch(IOException ex)
		{
			throw new FtpClientException("Unable to disconnect.", ex);
		}
	}
	
	/**
	 * 
	 * @param userName
	 * @param password
	 * @return on success - 230 (User logged in, proceed.)
	 * @throws FtpClientException
	 * 
	 */
	public int login(String userName, String password) throws FtpClientException
	{
		assertConnected();
		
		sendCommand("USER " + userName);
		assertResponse(331); //User name okay, need password.
		sendCommand("PASS " + password);
		assertResponse(230); //User logged in, proceed.
		return responseCode;
	}
	
	/**
	 * 
	 * @return on success - 221 (Goodbye.)
	 * @throws FtpClientException
	 */
	public int quit() throws FtpClientException
	{
		sendCommand("QUIT");
		assertResponse(221); //Goodbye.
		return responseCode;
	}
	
	/**
	 * 
	 * @return on success - 200 (PORT command successful.)
	 * @throws FtpClientException
	 */
	private int openDataPort() throws FtpClientException
	{
		int port;
//		InetAddress address;
		byte [] addressBytes;
//		int [] addressInts;
		String addressString;
		
		responseCode = 0;
		response = null;
		
		assertConnected();
		try
		{
			dataConnection = new ServerSocket(0,1);
		}
		catch(IOException ex)
		{
			throw new FtpClientException("Unable to open a data port.", ex);
		}
		
		port = dataConnection.getLocalPort();
		
		try
		{
			addressBytes = InetAddress.getLocalHost().getAddress();
		}
		catch(UnknownHostException ex)
		{
			throw new FtpClientException("Unable to determine local host.", ex);
		}
		addressString = "";
		addressString += ((int)addressBytes[0] & 0x00FF);
		for(int i = 1 ; i < addressBytes.length; i++)
		{
			addressString += "," + ((int)addressBytes[i] & 0x00FF);
		}
		addressString += "," + (port >> 8 & 0x00FF);
		addressString += "," + (port & 0x00FF);
		
		sendCommand("PORT " + addressString);
		assertResponse(200); //PORT command successful.
		
		dataPortOpen = true;

		return responseCode;
	}
	
	/**
	 * 
	 * @return list of file names
	 * @throws FtpClientException
	 */
	public String [] nList() throws FtpClientException
	{
		responseCode = 0;
		response = null;
		String [] result = null;
		Socket inputSocket = null;
		BufferedReader inputReader;
		String inputLine;
		ArrayList inputLines;
		

		assertConnected();
		openDataPort();
		sendCommand("NLST");

		assertResponse(125); //File status okay; about to open data connection.
		
		inputSocket = getDataSocket();
		inputLines = new ArrayList();
		
		try
		{
			inputReader = new BufferedReader(new InputStreamReader(inputSocket.getInputStream()));
			inputLine = inputReader.readLine();
			while(inputLine != null)
			{
				inputLines.add(inputLine);
				inputLine = inputReader.readLine();
			}
			inputReader.close();
		}
		catch(IOException ex)
		{
			throw new FtpClientException("Unable to read directory listing.", ex);
		}

		assertResponse(226); //Transfer complete, closing data connection.
		
		closeDataSocket(inputSocket);
		closeDataPort();

		//Give the system a second to recover
		// - I found that the next command wasn't always picked up without a short pause here.
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException ex){}
		
		result = new String[inputLines.size()];
		for(int i = 0; i < inputLines.size(); i++)
		{
			result[i] = (String)inputLines.get(i);
		}

		return result;
	}
	
	public int stor(String path, InputStream data) throws FtpClientException
	{
		responseCode = 0;
		response = null;
		Socket outputSocket = null;
		OutputStream output;
		byte [] buffer;
		int readCount;
		
		assertConnected();
		openDataPort();
		sendCommand("TYPE I");
		assertResponse(200); //Type set to I.
		
		sendCommand("STOR " + path);
		assertResponse(150); //File status okay; about to open data connection.
		
		outputSocket = getDataSocket();
		try
		{
			output = outputSocket.getOutputStream();
			buffer = new byte[1024];
			readCount = data.read(buffer);
			while(readCount > 0)
			{
				output.write(buffer, 0, readCount);
				readCount = data.read(buffer);
			}
			output.close();
		}
		catch(IOException ex)
		{
			throw new FtpClientException("Unable to write to file.", ex);
		}
		
		assertResponse(226); //Transfer complete, closing data connection.
		
		closeDataSocket(outputSocket);
		closeDataPort();
		
		//Give the system a second to recover
		// - I found that the next command wasn't always picked up without a short pause here.
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException ex){}
		
		return responseCode;
	}
	
	public int cwd(String path) throws FtpClientException
	{
		responseCode = 0;
		response = null;
		sendCommand("CWD " + path);
		assertResponse(250); //CWD Command successful.
		return responseCode;
	}

	public String cdup() throws FtpClientException
	{
		responseCode = 0;
		response = null;
		sendCommand("CDUP");
		assertResponse(200); //"<path>" is working directory.
		return (response.substring(response.indexOf("\"") + 1, response.lastIndexOf("\"")));
	}

	public String pwd() throws FtpClientException
	{
		responseCode = 0;
		response = null;
		sendCommand("PWD");
		assertResponse(257); //"<path>" is working directory.
		return (response.substring(response.indexOf("\"") + 1, response.lastIndexOf("\"")));
	}
	
	public int mkd(String path) throws FtpClientException
	{
		responseCode = 0;
		response = null;
		sendCommand("MKD " + path);
		assertResponse(257); //Requested file action okay, completed.
		return (responseCode);
	}
	
	public int dele(String path) throws FtpClientException
	{
		responseCode = 0;
		response = null;
		sendCommand("DELE " + path);
		assertResponse(250); //Requested file action okay, completed.
		return (responseCode);
	}
	
	//Wrap this functionality to avoid catching so many exceptions
	private Socket getDataSocket() throws FtpClientException
	{
		try
		{
			return dataConnection.accept();
		}
		catch(IOException ex)
		{
			closeDataPort();
			throw new FtpClientException("Unable to accept data connection.", ex);
		}
	}
	
	private void closeDataPort() throws FtpClientException
	{
		if(dataConnection != null)
		{
			try
			{
				dataConnection.close();
				dataConnection = null;
				dataPortOpen = false;
			}
			catch(IOException ex)
			{
				throw new FtpClientException("Unable to close data port.", ex);
			}
		}		
	}

	//Wrap this functionality to avoid catching so many exceptions
	private void closeDataSocket(Socket s) throws FtpClientException
	{
		try
		{
			s.close();
		}
		catch(IOException ex)
		{
			//To prevent the data connection from hanging indefinitely
			closeDataPort();
			throw new FtpClientException("Unable to close data connection.", ex);
		}
	}
	
	public String getResponse()
	{
		return response;
	}
	
	public int getResponseCode()
	{
		return responseCode;
	}
	
	private void assertConnected() throws FtpClientException
	{
		if(commandConnection == null || !commandConnection.isConnected())
		{
			response = null;
			responseCode = 0;
			throw new FtpClientException("Not connected.");
		}
	}
	
	private void assertDisconnected() throws FtpClientException
	{
		if(commandConnection != null)
		{
			if(commandConnection.isConnected())
			{
				response = null;
				responseCode = 0;
				throw new FtpClientException("Already connected.");
			} 
		}
	}
	
/*	private void assertDataPortOpen() throws FtpClientException
	{
		if(dataConnection == null || !dataConnection.isBound())
		{
			response = null;
			responseCode = 0;
			throw new FtpClientException("Data port not open.");
		}
	}*/

	/**
	 * Reads the response from the server and throws an exception if the expected code is not returned.
	 * @param expected response code expected from the server
	 * @throws FtpClientException if the expected response is not read from the server
	 * The description of the thrown exception is the actual response encountered.
	 */
	private void assertResponse(int expected) throws FtpClientException
	{
		if(readResponse() != expected)
		{
			//To prevent the data connection from hanging indefinitely
			closeDataPort();
			throw new FtpClientException(response + " where " + expected + " expected.");
		}
	}
	
	private void sendCommand(String Command) throws FtpClientException
	{
		response = null;
		responseCode = 0;
		try
		{
			commandOut.write(Command + newLine);
			commandOut.flush();
		}
		catch(IOException ex)
		{
			//To prevent the data connection from hanging indefinitely
			closeDataPort();
			throw new FtpClientException("Unable to write to control port.", ex);
		}
	}
	
	private int readResponse() throws FtpClientException
	{
		response = null;
		responseCode = 0;
		try
		{
			response = commandIn.readLine();
//			System.out.println(response);
			if(response != null)
			{
				responseCode = Integer.valueOf(response.substring(0, 3)).intValue();
				while(response.charAt(3) == '-')
				{
					response = commandIn.readLine();
//					System.out.println(response);
				}
/*				if(response.charAt(3) == '-')
				{
					String input = commandIn.readLine();
					while(Integer.getInteger(input.substring(0,3)).intValue() != responseCode)
					{
						response += "\n" + input;
						input = commandIn.readLine();
					}
					response += "\n" + input;
				}*/
			}
			else
			{
				//To prevent the data connection from hanging indefinitely
				closeDataPort();
				throw new FtpClientException("Control connection lost.");
			}
		}
		catch(IOException ex)
		{
			//To prevent the data connection from hanging indefinitely
			closeDataPort();
			throw new FtpClientException("Unable to read from control port.", ex);
		}
		return responseCode;
	}	
}
