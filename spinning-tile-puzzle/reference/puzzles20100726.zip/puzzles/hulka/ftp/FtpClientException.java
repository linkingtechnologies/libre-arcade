/*
Use of this code module (herein "the module") shall be governed by
the agreement laid out in this notice (herein "this license")

The module may be freely distributed, modified, and included in
software applications provided that the following conditions
are met:
 
 1. This notice shall remain in the module, unchanged.
 
 2. Any other module(s) upon which the module is made dependent
    must be covered by this license and this notice must be
    included in the source code of said module(s).
 
 3. If part(s) of the module is/are extracted to other module(s),
    the module(s) containing the extracted part(s) must be
    covered by this license and this notice must be included in
    the source code of said module(s).
    
 4. The module's uncompiled source code must be made available
    upon request to anyone who asks.
    
 5. The module must not be used in any way that invalidates this
    license.
    
 6. This license shall be the only agreement governing the use of
    the module.

 7. The name of, contact information of, and description of work
    done by any programmer who works on the module must remain in
    the comments of the module's source code immediately following
    this notice.
 */

/*
 created by:
 Jonathan Hulka
 jon.hulka@gmail.com
 PO Box 184
 McBride BC
 V0J 2E0
 Canada
 */

/*
 * Created on 9-May-2005
 *
 */

/**
 * @author Jonathan Hulka
 */

public class FtpClientException extends Exception {

	public FtpClientException() {
		super();
	}

	public FtpClientException(String description) {
		super(description);
	}

	public FtpClientException(Throwable cause) {
		super(cause);
	}

	public FtpClientException(String description, Throwable cause) {
		super(description, cause);
	}

}
