/**
 *      GameMenuListener.java
 *      
 *      Copyright 2010 Jonathan Hulka <jon.hulka@gmail.com>
 *      
 *      This program is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Hooks the game menu options (new, load, save and quit)
 */
public class GameMenuListener extends WindowAdapter implements ActionListener
{
	public static String ACTION_PREVIEW="game:preview";
	public static String ACTION_COLOR="game:color";
	public static String ACTION_LAYER1="game:layer1";
	public static String ACTION_LAYER2="game:layer2";
	public static String ACTION_LAYER3="game:layer3";
	
	private GUI gui;
	
	GameMenuListener(GUI gui)
	{
		this.gui=gui;
	}

	public void actionPerformed(ActionEvent e)
	{
		doCommand(e.getActionCommand());
	}
	
	public void doCommand(String cmd)
	{
		if(cmd.equals(ACTION_PREVIEW)){gui.showPreview();}
		else if(cmd.equals(ACTION_COLOR)){gui.chooseColor();}
		else if(cmd.equals(ACTION_LAYER1)){gui.setLayer(0);}
		else if(cmd.equals(ACTION_LAYER2)){gui.setLayer(1);}
		else if(cmd.equals(ACTION_LAYER3)){gui.setLayer(2);}
	}
}
