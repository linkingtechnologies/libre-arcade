/**
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.Random;
import java.awt.Dimension;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import hulka.tilemanager.*;
/**
 * To do: make sure tilemask is only acquired once
 * To do: init one AffineTransform and reuse it
 * To do: init one bounding rectangle and reuse it
 */

public class SliderHandler implements PuzzleHandler, MouseListener
{
	private GUI ui;
	private Random random;
	//This is the tiles across value, not the tile count
	static final int [] preferredSizes = {3,4,5};
	private Dimension [] puzzleSizes;
	private Dimension boardSize;
	private SquareTileManager tileManager;
	private int missingTile;
	private int tilesAcross;
	private int tileCount;
	private int tileWidth;
	private Rectangle clipRect;
	boolean solved = false;
	
	//Temporary storage to save heap abuse
	Point coords=new Point(0,0);
	int [] neighbors;
	
	public SliderHandler(GUI gui)
	{
		ui = gui;
		random = new Random();
		calculateSizes();
	}

	public int [] getPuzzleSizes(int shapeIndex)
	{
		calculateSizes();
		int [] ps = new int[puzzleSizes.length];
		for(int i = 0; i < puzzleSizes.length; i++)
		{
			ps[i] = puzzleSizes[i].width*puzzleSizes[i].height - 1;
		}
		return ps;
	}

	private void calculateSizes()
	{
		puzzleSizes = new Dimension[preferredSizes.length];
		for(int i = 0; i < preferredSizes.length; i++)
		{
			puzzleSizes[i] = new Dimension(preferredSizes[i],preferredSizes[i]);
		}
	}

	public void load(int pieceCountIndex, int shapeIndex)
	{
		boardSize = ui.getImageSize();
		tileManager = new SquareTileManager(boardSize.width,boardSize.height,puzzleSizes[pieceCountIndex].width,puzzleSizes[pieceCountIndex].width);
		solved = false;
		setupTiles();
		drawAllTiles();
	}
	
	private boolean checkSolved()
	{
		boolean solved = true;
		for(int i = 0; i < tileCount && solved; i++)
		{
			solved = tileManager.getOriginalTileIndex(i)==i;
		}
		return solved;
	}
	private void setupTiles()
	{
		tileCount = tileManager.getTileCount();
		tilesAcross = tileManager.getTilesAcross();
		tileWidth = tileManager.getTileWidth();
		clipRect = new Rectangle(0,0,tileWidth,tileWidth);
		missingTile = random.nextInt(tileCount);
		int [] tiles = new int[tileCount];
		for(int i=0; i < tileCount; i++) tiles[i]=i;
		//mix it up
		int cycles = 24/tileCount + 3;
		for(int j = 0 ; j < cycles; j++)
		{
			for(int i=0; i < tileCount; i++)
			{
				int t = random.nextInt(tileCount);
				int temp = tiles[t];
				tiles[t] = tiles[i];
				tiles[i] = temp;
			}
			for(int i=0; i < tiles.length; i++)
			{
				//Slide missingTile to the next random tile position
				coords = moveMissingTileTo(tiles[i],coords);
				//Then slide sideways from the last slide direction, to avoid moving the tiles back again
				if(coords.x==0)
				{
					//get the tile position
					coords = tileManager.getExpandedIndex(tiles[i],coords);
					//adjust tile position, sliding on the x axis
					coords.x += coords.x == 0 ? 1 : coords.x == tilesAcross - 1 ? -1 : random.nextInt(1)*2 - 1;
				}
				else
				{
					//get the tile position
					coords = tileManager.getExpandedIndex(tiles[i],coords);
					//adjust tile position, sliding on the y axis
					coords.y += coords.y == 0 ? 1 : coords.y == tilesAcross - 1 ? -1 : random.nextInt(1)*2 - 1;
				}
				slide(tileManager.getFlatIndex(coords));
			}
		}
		ui.initCanvas(boardSize.width,boardSize.height);
		ui.setBuffers(tileWidth,0);
		ui.addMouseListener(this);
	}
//Good to here
	
	/**
	 * This is a randomizing helper function.
	 * Moves the blank tile to the specified index.
	 * @param tileIndex index of the location to move the blank tile.
	 * @param direction storage for the return value. Must not be null.
	 * @return Direction of the operation's last move.
	 */
	private Point moveMissingTileTo(int tileIndex, Point direction)
	{
		Point nextTile = null;
		//Final position
		Point destination = tileManager.getExpandedIndex(tileIndex,null);
		direction.x = 0;
		direction.y = 0;
		while(missingTile != tileIndex)
		{
			nextTile = tileManager.getExpandedIndex(missingTile,nextTile);
			
			direction.x=0;
			direction.y=0;
			int axis;
			if(nextTile.x == destination.x)
			{
				direction.y = destination.y > nextTile.y ? 1 : -1;
			}
			else
			{
				if(nextTile.y == destination.y)
				{
					direction.x = destination.x > nextTile.x ? 1 : -1;
				}
				else
				{
					if(random.nextInt(2)==0)
					{direction.y = destination.y > nextTile.y ? 1 : -1;}
					else
					{direction.x = destination.x > nextTile.x ? 1 : -1;}
				}
			}
			nextTile.x += direction.x;
			nextTile.y += direction.y;
			slide(tileManager.getFlatIndex(nextTile));
		}
		return direction;
	}
	
	private void drawAllTiles()
	{
		ui.drawTile(new Rectangle(0,0,boardSize.width,boardSize.height),null,GUI.DRAW_PUZZLEIMAGE,GUI.DRAW_BACKGROUND);
		coords = tileManager.getTilePosition(0,coords);
		ui.eraseRect(new Rectangle(coords.x,coords.y,tilesAcross*tileWidth,tilesAcross*tileWidth));
		ui.clearAll();
		for(int i = 0; i < tileCount; i++)
		{
			if(missingTile!=i)
			{
				initTileImage(i);
				coords = tileManager.getTilePosition(i,coords);
				clipRect.x = coords.x;
				clipRect.y = coords.y;
				ui.drawTile(clipRect,null,GUI.DRAW_TILEBUFFER,GUI.DRAW_FOREGROUND);
			}
		}
		ui.repaint();
	}
	
	/**
	 * This function assumes that tileIndex is adjacent to missingTile
	 * if it isn't, the puzzle could end up in an unsolvable state
	 */
	private void slide(int tileIndex)
	{
		tileManager.swap(tileIndex,missingTile);
		missingTile = tileIndex;
	}

	private void initTileImage(int tileIndex)
	{
		Shape tileShape = tileManager.getTileMask(tileIndex);
		coords = tileManager.getOriginalTilePosition(tileIndex,coords);
		ui.buildTileImage(coords.x,coords.y,tileShape,null,0);
	}
	
	public void mouseClicked(MouseEvent e)
	{
		int tileIndex = tileManager.getTileAt(e.getX(),e.getY());
		if(solved)
		{
			ui.resetPuzzle();
		}
		else if(tileIndex != -1 && missingTile != tileIndex)
		{
			neighbors = tileManager.getNeighbors(tileIndex,neighbors);
			boolean ok = false;
			//See if the clicked tile can slide
			for(int i = 0; i < neighbors.length && !ok; i++)
			{
				ok = missingTile==neighbors[i];
			}
			if(ok)
			{
				int temp = missingTile;
				slide(tileIndex);
				//Draw the tile in its new location
				initTileImage(temp);
				coords = tileManager.getTilePosition(temp,coords);
				clipRect.x = coords.x;
				clipRect.y = coords.y;
				ui.drawTile(clipRect,null,GUI.DRAW_TILEBUFFER,GUI.DRAW_FOREGROUND);
				ui.repaint(clipRect);
				coords = tileManager.getTilePosition(missingTile,coords);
				clipRect.x = coords.x;
				clipRect.y = coords.y;
				if(checkSolved())
				{
					//The puzzle is finished, draw the missing tile
					initTileImage(missingTile);
					ui.drawTile(clipRect,null,GUI.DRAW_TILEBUFFER,GUI.DRAW_FOREGROUND);
					solved = true;
				}
				else
				{
					//Clear the missing tile
					ui.clearRect(clipRect);
				}
				ui.repaint(clipRect);
			}
		}
	}
	
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}

}
