/**
 *      PuzzleCanvas.java
 *      
 *      Copyright 2010 Jonathan Hulka <jon.hulka@gmail.com>
 *      
 *      This program is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Changelog:
 * 2010 06 15 - Jon
 * Added select flag to buildTileImage
 * 2010 06 14 - Jon
 * Added preview dialog.
 * 2010 07 26 - Jon
 * Changed contrast color mapping (for selection box) to hsb(h+0.5,1-s,1-b) for better contrast
 */
import hulka.gui.JBufferedCanvas;
import hulka.util.MiscUtils;

//Geometry
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;

//Graphics
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.AlphaComposite;
import java.awt.RenderingHints;

//Events
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ActionMap;
import javax.swing.InputMap;

import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JColorChooser;
import hulka.event.KeyStrokeAction;

import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;

public class PuzzleCanvas extends JBufferedCanvas
{
	public static final int DRAW_BACKGROUND = 0;
	public static final int DRAW_FOREGROUND = 1;
	public static final int DRAW_DRAGBUFFER = 2;
	public static final int DRAW_TILEBUFFER = 3;
	public static final int DRAW_PUZZLEIMAGE = 4;
	public static final int DRAW_ROTATECCW = 5;
	public static final int DRAW_ROTATECW = 6;
	public static final int CURSOR_SIZE = 32;

	private BufferedImage puzzleImage=null;
	private BufferedImage tileBuffer=null;
	private BufferedImage tileIntermediate=null;
	private BufferedImage dragBuffer=null;
	private BufferedImage cwImage=null;
	private BufferedImage ccwImage=null;

	private AffineTransform lightTransform = AffineTransform.getTranslateInstance(1,1);
	private AffineTransform shadowTransform = AffineTransform.getTranslateInstance(-1,-1);
	private Color selectedColor=new Color(0x07f,0x07f,0x07f,0x07f);
	private Color lightColor=new Color(0x0ff,0x0ff,0x0ff,0x060);
	private Color shadowColor=new Color(0,0,0,0x060);
	private Color transparentColor=new Color(0,0,0,0);
	private Color backgroundColor=Color.WHITE;
	private Color contrastColor=Color.BLACK;
	private float[] hsb=new float[3];
	private PreviewDialog previewDialog;

	int tileSize;//, imageWidth, imageHeight;

	public PuzzleCanvas(Dimension size)
	{
		super(new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_ARGB));
		
		cwImage = MiscUtils.loadImage("images/cwcursor.png",CURSOR_SIZE,CURSOR_SIZE);
		ccwImage = MiscUtils.loadImage("images/ccwcursor.png",CURSOR_SIZE,CURSOR_SIZE);
			
		setMinimumSize(size);
		setMaximumSize(size);
		setFocusable(true);
		previewDialog=new PreviewDialog();
	}
	
	public void setPuzzleImage(BufferedImage image)
	{
		puzzleImage=image;
		previewDialog.setImage(image);
	}

	/**
	 * If the puzzle image is not loaded this will throw a NullPointerException
	 */
	public Dimension getImageSize(Dimension d)
	{
		if(d==null)d=new Dimension();
		d.width=puzzleImage.getWidth();
		d.height=puzzleImage.getHeight();
		return d;
	}
	
	/**
	 * Erases a section of the drawing area by setting it to the background color
	 * @param bounds the area to erase
	 */
	public void erase(Rectangle bounds)
	{
		Graphics2D g2d = (Graphics2D)getBackgroundGraphics();
		g2d.setBackground(backgroundColor);
		g2d.clearRect(bounds.x,bounds.y,bounds.width,bounds.height);
		g2d.dispose();
	}
	
	/**
	 * Erases the entire drawing area by setting it to the background color
	 */
	public void erase()
	{
		Graphics2D g2d = (Graphics2D)getBackgroundGraphics();
		g2d.setBackground(backgroundColor);
		g2d.clearRect(0,0,getWidth(),getHeight());
		g2d.dispose();
	}
	
	/**
	 * Saves a piece of image to the dragBuffer
	 * @param bounds position and size
	 * @param sourceLayer DRAW_BACKGROUND or DRAW_FOREGROUND
	 */
	public void backupImage(Rectangle bounds, int sourceLayer)
	{
		Graphics2D g2d = (Graphics2D)(dragBuffer.getGraphics());
		BufferedImage img = null;
		switch(sourceLayer)
		{
			case DRAW_BACKGROUND:
				img = getBackgroundImage();
			break;
			case DRAW_FOREGROUND:
				img = getForegroundImage();
			break;
		}
		g2d.drawImage(img,0,0,bounds.width,bounds.height,bounds.x,bounds.y,bounds.x+bounds.width,bounds.y+bounds.height,null);
		g2d.dispose();
	}

	/**
	 * Draws a tile on the drawing area
	 * @param bounds location and size
	 * @param clipRect the clipping region
	 * @param sourceLayer DRAW_DRAGBUFFER, DRAW_TILEBUFFER, or DRAW_PUZZLEIMAGE
	 * @param drawLayer DRAW_BACKGROUND, DRAW_FOREGROUND or DRAW_DRAGBUFFER
	 */
	public void drawTile(Rectangle bounds, Rectangle clipRect, int sourceLayer, int drawLayer)
	{
		Graphics2D g2d = null;
		BufferedImage img = null;
		switch(drawLayer)
		{
			case DRAW_BACKGROUND:
				g2d = (Graphics2D)getBackgroundGraphics();
			break;
			case DRAW_FOREGROUND:
				g2d = (Graphics2D)getForegroundGraphics();
			break;
			case DRAW_DRAGBUFFER:
				g2d = (Graphics2D)(dragBuffer.getGraphics());
			break;
		}
		switch(sourceLayer)
		{
			case DRAW_DRAGBUFFER:
				img = dragBuffer;
			break;
			case DRAW_TILEBUFFER:
				img = tileBuffer;
			break;
			case DRAW_PUZZLEIMAGE:
				img = puzzleImage;
			break;
			case DRAW_ROTATECCW:
				img = ccwImage;
			break;
			case DRAW_ROTATECW:
				img = cwImage;
			break;
		}
		g2d.setClip(null);
		if(clipRect != null)
		{
			g2d.setClip(clipRect.x, clipRect.y, clipRect.width, clipRect.height);
		}
		g2d.drawImage(img,bounds.x,bounds.y,bounds.x+bounds.width,bounds.y+bounds.height,0,0,bounds.width,bounds.height,null);
		g2d.dispose();
	}

	/**
	 * Just using shape clipping doesn't apply antialiasing, this gives a smoother result.
	 */
	private void applyAntialiasedMask(Graphics2D g2d,Shape mask)
	{
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		//Clear the alpha
		g2d.setComposite(AlphaComposite.Clear);
		g2d.fillRect(0, 0, tileSize, tileSize);
		//render the clip shape to alpha
		g2d.setComposite(AlphaComposite.Src);
		g2d.setColor(Color.WHITE);
		g2d.fill(mask);
		g2d.setComposite(AlphaComposite.SrcAtop);
	}
	
	public void drawRect(Rectangle rect, int drawLayer)
	{
		Graphics2D g2d = (Graphics2D)getForegroundGraphics();
		g2d.setColor(contrastColor);
		g2d.drawRect(rect.x,rect.y,rect.width,rect.height);
		g2d.dispose();
	}

	/**
	 * Draws a tile to the tile buffer
	 * To do: find a way to persist some of these to avoid recalculating the masks every time.
	 */
	public void buildTileImage(int fromX, int fromY, Shape tileShape, AffineTransform rotation, int errMargin, boolean selected)
	{
		//Draw the tile's image
		Graphics2D gInt = (Graphics2D)tileIntermediate.getGraphics();
		AffineTransform tf = gInt.getTransform();
		if(rotation != null) gInt.transform(rotation);
		int size = tileSize + errMargin*2;
		int x = fromX - errMargin;
		int y = fromY - errMargin;
		gInt.drawImage(puzzleImage,0,0,size,size,x,y,x + size,y + size, null);
		if(selected)
		{
			gInt.setColor(selectedColor);
			gInt.fillRect(0,0,size,size);
		}
		gInt.setTransform(tf);

		Rectangle unMask = new Rectangle(0,0,size,size);
		Shape tShape = rotation != null ? rotation.createTransformedShape(AffineTransform.getTranslateInstance(errMargin,errMargin).createTransformedShape(tileShape)) : tileShape;

		gInt.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		//light hints
		Area mask = new Area(unMask);
		Shape shifted = lightTransform.createTransformedShape(tShape);
		mask.subtract(new Area(shifted));
		gInt.setColor(lightColor);
		gInt.fill(mask);

		//shadow hints
		mask = new Area(unMask);
		shifted = shadowTransform.createTransformedShape(tShape);
		mask.subtract(new Area(shifted));
		gInt.setColor(shadowColor);
		gInt.fill(mask);

		gInt.dispose();

		Graphics2D g2d = (Graphics2D)tileBuffer.getGraphics();
		
		//tile shape
		applyAntialiasedMask(g2d,tShape);
		g2d.drawImage(tileIntermediate,0,0,null);
		g2d.dispose();
	}
	
	public void clearDragBuffer(int width, int height)
	{
		Graphics2D g2d = (Graphics2D)dragBuffer.getGraphics();
		g2d.setBackground(transparentColor);
		g2d.clearRect(0,0,width,height);
		g2d.dispose();
	}
	public void setBuffers(int tileSize, int errMargin)
	{
		int w=puzzleImage.getWidth();
		int h=puzzleImage.getHeight();
		this.tileSize = tileSize;
		tileBuffer = new BufferedImage(tileSize + errMargin*2,tileSize + errMargin*2,BufferedImage.TYPE_INT_ARGB);
		tileIntermediate = new BufferedImage(tileSize + errMargin*2,tileSize + errMargin*2,BufferedImage.TYPE_INT_ARGB);
		//the dragbuffer must be able to accommodate the whole image at any rotation - use the corner to corner distance
		int bufferSize = (int)Math.sqrt(w*w + h*h) + errMargin*2;
		dragBuffer = new BufferedImage(bufferSize,bufferSize,BufferedImage.TYPE_INT_ARGB);
	}
	
	public void clearBuffers()
	{
		tileSize = -1;
		tileBuffer = null;
		tileIntermediate = null;
	}
	
	public void showPreview()
	{
		previewDialog.setVisible(true);
	}
	
	public void setBackground(Color color)
	{
		backgroundColor=color;
		hsb=Color.RGBtoHSB(color.getRed(),color.getGreen(),color.getBlue(),hsb);
		contrastColor=Color.getHSBColor(hsb[0]+0.5f,1-hsb[1],1-hsb[2]);
	}
	
	public void chooseColor(JFrame parent)
	{
		Color newColor=JColorChooser.showDialog(parent, "Choose Puzzle Background", backgroundColor);
		if(newColor!=null)
		{
			setBackground(newColor);
		}
	}
}
