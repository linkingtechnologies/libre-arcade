/**
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Changelog:
 * 2010 07 08 - Jon
 * - debugged second button click issues.
 *   Event handlers now keep a mouse count and only respond to the first mousePressed / last mouseReleased.
 *   As a result, second clicks have no effect. This modifies previous behaviour, where second clicks acted as a mouseReleased.
 * - reworked drag constraints.
 *   Dragged tiles are now constrained by a dragAllowance rectangle that ensures each group is at least partly visible.
 * 
 * 2010 07 07 - Jon
 * - Implemented layers
 * 
 * 2010 07 06 - Jon
 * - Created temp variables for each function (Rectangles and Points).
 * This will require a tiny bit more memory usage, but will make future maintenance much easier.
 * 
 * 2010 06 28 - Jon
 * - Debugged multi-select
 * 
 * 2010 06 27 - Jon
 * Modified tile dragging - now tiles cannot overlap edge of the board
 * Integrated multi-select for moving tiles
 * 
 * 2010 06 17 - Jon
 * Retrofitted to use ConnectedSet for managing connected tiles and tile snapping.
 * 
 * 2010 06 14 - Jon
 * Worked out tile placement issues. Tiles are now randomly scattered on the board.
 * Added focus request on mousedown.
 * 
 * 2010 06 11 - Jon
 * Abstracted tilemanager creation code to NewPuzzleDialog
 * This class now communicates with PuzzleCanvas, rather than GUI
 */


import java.awt.Dimension;
import java.util.Random;
import java.awt.geom.AffineTransform;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.Point;
import java.awt.Rectangle;
import hulka.event.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import hulka.tilemanager.TileManager;

import java.util.Arrays;

public class JigsawHandler implements PuzzleHandler, MouseSensetiveShapeListener, MouseListener, MouseMotionListener, KeyListener
{
	PuzzleCanvas ui;
	private TileManager tileManager;
	private Random random=new Random();

	private int errMargin=2;
	private int snapThreshold=5;
	private int mouseCount=0;

	//For drawing, tileSize includes margin
	int tileSize, tileMargin;
	//For placement, margin not included
	int tileHeight,tileWidth,tileSpacingX,tileSpacingY;
	
	//Event handling
	private MouseSensetiveShapeManager boardManager;
	private MouseSensetiveTile [] tiles;

	//z-ordering
	private int [] zIndices;
	//
	private ConnectedSet connectedTiles;
	private ConnectedSet selectedTiles;
	
	private int [] layerIndices;
	private int layerCount=3;
	private int currentLayer=0;
	
	private boolean gameComplete=false;
	public boolean isGameComplete(){return gameComplete;}
	private boolean gameSaved=false;
	public boolean isGameSaved(){return gameSaved;}

	private Rectangle boardBounds=null;
	
	//for drag operations
	private int dragIndex=-1;
	private int mouseX,mouseY,adjustedMouseX,adjustedMouseY,dX,dY;
	private boolean dragging=false;
	//boundary of the selected/dragging tileset, or of the selection rectangle
	private Rectangle dragBounds=new Rectangle();
	//while dragging, this must stay within the play area
	private Rectangle dragAllowance=new Rectangle();
	
	//for multi-select
	private int selectedGroup=-1;

	public JigsawHandler(TileManager tileManager)
	{
		this.tileManager=tileManager;
	}
	
	public void connect(PuzzleCanvas canvas)
	{
		ui=canvas;
		boardBounds=ui.getBounds(boardBounds);
		boardBounds.x=0;
		boardBounds.y=0;
//		ui.erase();
		setupTiles();
		redraw();
//		drawAllTiles();
//		ui.clear();
//		ui.repaint();
		ui.setBuffers(tileSize,errMargin);
		ui.addMouseListener(boardManager);
		ui.addMouseListener(this);
		ui.addMouseMotionListener(this);
		ui.addKeyListener(this);
	}
	
	public void disconnect()
	{
		ui.removeMouseListener(this);
		ui.removeMouseListener(boardManager);
		ui.removeMouseMotionListener(this);
		ui.removeKeyListener(this);
		ui.clearBuffers();
	}
	
	public void setLayer(int layer)
	{
		if(layer>=0&&layer<layerCount)
		{
			int sg=dragIndex>=0?dragIndex:selectedGroup>=0?selectedGroup:-1;
			//Mark selected or dragging tiles to be ignored for the moment
			if(sg>=0)
			{
				selectedTiles.setGroup(sg);
				for(int i=selectedTiles.getNext();i>=0;i=selectedTiles.getNext())
				{
					connectedTiles.setGroup(i);
					for(int j=connectedTiles.getNext();j>=0;j=connectedTiles.getNext())
						layerIndices[j]=-1;
				}
			}

			//remove old current layer tiles from the event manager
			for(int i=0;i<tiles.length;i++)
			{
				if(layerIndices[i]==currentLayer)boardManager.removeShape(tiles[i]);
			}

			currentLayer=layer;
			
			//insert new current layer tiles into the event manager
			for(int i=0;i<tiles.length;i++)
			{
				if(layerIndices[i]==currentLayer)boardManager.addShape(tiles[i]);
			}
			
			//Move selected or dragging tiles to the current layer
			if(sg>=0)
			{
				selectedTiles.setGroup(sg);
				for(int i=selectedTiles.getNext();i>=0;i=selectedTiles.getNext())
				{
					connectedTiles.setGroup(i);
					for(int j=connectedTiles.getNext();j>=0;j=connectedTiles.getNext())
						layerIndices[j]=currentLayer;
				}
			}
			redraw();
		}
	}
	
	public void redraw()
	{
		ui.erase();

		//Redraw the background
		drawAllTiles();
		ui.clear();
		
		//Redraw the selection
		if(dragIndex>=0||selectedGroup>=0)ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);

		ui.repaint();
	}

	private void setupTiles()
	{
		tiles = new MouseSensetiveTile [tileManager.getTileCount()];
		connectedTiles=new ConnectedSet(tiles.length);
		selectedTiles=new ConnectedSet(tiles.length);
		zIndices = new int[tiles.length];
		tileMargin = tileManager.getTileMargin();

		tileWidth = tileManager.getTileWidth();
		tileHeight = tileManager.getTileHeight();
		tileSpacingX = tileManager.getTileSpacingX();
		tileSpacingY = tileManager.getTileSpacingY();
		int rotationSteps  = tileManager.getRotationSteps();
		tileSize = (tileHeight>tileWidth ? tileHeight : tileWidth) + tileMargin*2;
		
		//initialize layers
		layerIndices=new int[tiles.length];
		
		for(int i=0; i < zIndices.length; i++)
		{
			//All tiles to layer 0
			layerIndices[i]=0;
			zIndices[i] = i;
		}
	
		//Randomize the zIndices
		for(int i =0; i < zIndices.length; i++)
		{
			int t = zIndices[i];
			int index = random.nextInt(zIndices.length);
			zIndices[i] = zIndices[index];
			zIndices[index] = t;
		}
		
		boardManager = new MouseSensetiveShapeManager();
		
		int w=boardBounds.width-tileSize-1;
		int h=boardBounds.height-tileSize-1;
		for(int i=0;  i < zIndices.length; i++)
		{
			int x = random.nextInt(w);
			int y = random.nextInt(h);
			tileManager.rotate(zIndices[i],TileManager.SPIN_CW*random.nextInt(rotationSteps));
			tiles[zIndices[i]] = new MouseSensetiveTile(tileManager, zIndices[i], x, y,i,errMargin);
			boardManager.addShape(tiles[zIndices[i]]);
		}
		boardManager.addEventListener(this);
		ui.setBuffers(tileSize,errMargin);
	}
	
	private Rectangle datBounds=null;
	private void drawAllTiles()
	{
		if(datBounds==null)datBounds=new Rectangle(0,0,tileSize+errMargin*2,tileSize+errMargin*2);
		for(int i = zIndices.length - 1; i >= 0; i--)
		{
			if(zIndices[i]>=0 && layerIndices[zIndices[i]]==currentLayer)
			{
				initTileImage(zIndices[i],false);
				datBounds.x=tiles[zIndices[i]].getX()-errMargin;datBounds.y=tiles[zIndices[i]].getY()-errMargin;
				ui.drawTile(datBounds,null,PuzzleCanvas.DRAW_TILEBUFFER,PuzzleCanvas.DRAW_BACKGROUND);
			}
		}
	}
	
	private Point itiPos=new Point();
	private void initTileImage(int tileIndex, boolean selected)
	{
		Shape tileShape = tileManager.getTileMask(tileIndex);
//To do: make sure tileManager is not allocating excessive memory in getRotationTransform
//To do: reuse transform here
		AffineTransform rotation = tileManager.getRotationTransform(tileIndex,new AffineTransform(),errMargin + tileMargin);
		if(tileManager.getOriginalTilePosition(tileIndex, itiPos)!=null)
		{
			//GUI takes into account the errMargin, but adjustment must be made for tileMargin
			ui.buildTileImage(itiPos.x - tileMargin,itiPos.y - tileMargin,AffineTransform.getTranslateInstance(tileMargin,tileMargin).createTransformedShape(tileShape),rotation, errMargin, selected);
		}
	}
	
	private void dropConnectedTiles(int tileIndex,ConnectedSet tileSet)
	{
		//Adjust z indices
		int tileCount=tileSet.getGroupSize(tileIndex);
		int offset=tileSet.insertConnectedElements(tileIndex,zIndices);
		for(int i=0;i<tileCount+offset;i++)
		{
			if(zIndices[i]>=0) tiles[zIndices[i]].setZOrder(i);
		}

		//insert the connected tiles.
		tileSet.setGroup(tileIndex);
		for(int i=tileSet.getNext(); i>=0; i=tileSet.getNext())
		{
			boardManager.addShape(tiles[i]);
		}
	}

	private void copyRect(Rectangle in,Rectangle out){out.x=in.x;out.width=in.width;out.y=in.y;out.height=in.height;}
	private Rectangle gdaTop=new Rectangle();
	private Rectangle gdaBottom=new Rectangle();
	private Rectangle gdaLeft=new Rectangle();
	private Rectangle gdaRight=new Rectangle();
	//Adjust as necessary. Currently one third total width or height.
	private int gdaEdgeFactor=3;
	private Rectangle getDragAllowance(int tileIndex,ConnectedSet tileSet,Rectangle bounds,Rectangle result)
	{
		//Adjust as necessary. Currently one half total width or height.
		int hAllowance=bounds.width/2;
		int vAllowance=bounds.height/2;
		copyRect(bounds,gdaTop);
		gdaTop.height/=gdaEdgeFactor;
		copyRect(gdaTop,gdaBottom);
		gdaBottom.y+=bounds.height-gdaTop.height;
		
		copyRect(bounds,gdaLeft);
		gdaLeft.width/=gdaEdgeFactor;
		copyRect(gdaLeft,gdaRight);
		gdaRight.x+=bounds.width-gdaLeft.width;
		
		//Start with minimum allowance
		copyRect(bounds,result);

		tileSet.setGroup(tileIndex);
		int bl=result.x;
		int br=result.x+result.width;
		int tl=bl;
		int tr=br;
		int lt=result.y;
		int lb=result.y+result.height;
		int rt=lt;
		int rb=lb;
		for(int i=tileSet.getNext();i>=0;i=tileSet.getNext())
		{
			Rectangle r = tiles[i].getBounds();

			//Figure out the allowance for this tile
			int left=r.x+r.width-hAllowance;
			int right=r.x+hAllowance;
			int top=r.y+r.height-vAllowance;
			int bottom=r.y+vAllowance;

			//See if the improved allowances apply
			if(r.intersects(gdaTop))
			{
				//This tile will show if the selection is dragged as far down as possible.
				//Adjust left and right margins accordingly.
				if(left>tl)tl=left;
				if(right<tr)tr=right;
			}
			if(r.intersects(gdaBottom))
			{
				//This tile will show if the selection is dragged as far up as possible.
				//Adjust left and right margins accordingly.
				if(left>bl)bl=left;
				if(right<br)br=right;
			}
			if(r.intersects(gdaLeft))
			{
				//This tile will show if the selection is dragged as far right as possible.
				//Adjust top and bottom margins accordingly.
				if(top>lt)lt=top;
				if(bottom<lb)lb=bottom;
			}
			if(r.intersects(gdaRight))
			{
				//This tile will show if the selection is dragged as far left as possible.
				//Adjust top and bottom margins accordingly.
				if(top>rt)rt=top;
				if(bottom<rb)rb=bottom;
			}
		}
		
		//Choose the region that is guaranteed to show something
		result.y=rt>lt?lt:rt;
		result.height=(rb<lb?lb:rb)-result.y;
		result.x=tl>bl?bl:tl;
		result.width=(tr<br?br:tr)-result.x;

		return result;
	}

	private Rectangle pickConnectedTiles(int tileIndex,ConnectedSet tileSet,Rectangle result)
	{
		boolean resultInitialized=false;
		int groupSize=tileSet.getGroupSize(tileIndex);

		//remove the connected tiles
		tileSet.setGroup(tileIndex);
		for(int i=tileSet.getNext();i>=0;i=tileSet.getNext())
		{
			boardManager.removeShape(tiles[i]);
			
			Rectangle bounds = tiles[i].getBounds();
			if(resultInitialized)
			{
				result.add(bounds);
			}
			else
			{
				resultInitialized=true;
				result.x=bounds.x;
				result.y=bounds.y;
				result.width=bounds.width;
				result.height=bounds.height;
			}
		}
		
		//Adjust z-indices
		int endIndex=tileSet.removeConnectedElements(tileIndex,zIndices);
		for(int i=groupSize;i<endIndex;i++)
		{
			if(zIndices[i]>=0) tiles[zIndices[i]].setZOrder(i);
		}

		result.x-=errMargin;
		result.y-=errMargin;
		result.width+=errMargin*2;
		result.height+=errMargin*2;
		return result;
	}
	
	Rectangle dBounds=null;
	/**
	 * Draws tiles within the given region
	 * @param bounds the region to redraw
	 */
	private void draw(Rectangle bounds)
	{
		MouseSensetiveShape [] intersectingTiles = boardManager.getIntersectingShapes(bounds);
		if(dBounds==null)dBounds=new Rectangle(0,0,tileSize+errMargin*2,tileSize+errMargin*2);
		if(intersectingTiles != null)
		{
			for(int j = intersectingTiles.length - 1; j >= 0; j--)
			{
				int tileIndex=intersectingTiles[j].getIndex();
				if(layerIndices[tileIndex]==currentLayer)
				{
					initTileImage(tileIndex,false);
					dBounds.x=intersectingTiles[j].getX()-errMargin;dBounds.y=intersectingTiles[j].getY()-errMargin;
					ui.drawTile(dBounds,bounds,PuzzleCanvas.DRAW_TILEBUFFER, PuzzleCanvas.DRAW_BACKGROUND);
				}
			}
		}
	}

	private Rectangle ddbBounds=null;
	private void drawDragBuffer(Rectangle bounds,int tileIndex,ConnectedSet tileSet, boolean selected)
	{
		if(ddbBounds==null)ddbBounds=new Rectangle(0,0,tileSize+errMargin*2,tileSize+errMargin*2);
		tileSet.setGroup(tileIndex);
		for(int i=tileSet.getNext(); i>=0; i=tileSet.getNext())
		{
			initTileImage(i,selected);
			ddbBounds.x=tiles[i].getX()-bounds.x-errMargin;ddbBounds.y=tiles[i].getY()-bounds.y-errMargin;
			ui.drawTile(ddbBounds,null,PuzzleCanvas.DRAW_TILEBUFFER,PuzzleCanvas.DRAW_DRAGBUFFER);
		}
	}

	public void mouseClicked(MouseSensetiveShapeEvent e)
	{}
	
	private boolean isTileSelected(int tileIndex)
	{
		boolean result=false;
		selectedTiles.setGroup(selectedGroup);
		for(int i=selectedTiles.getNext();i>=0&&!result;i=selectedTiles.getNext()) result=connectedTiles.isConnected(tileIndex,i);
		return result;
	}
 
    public void mousePressed(MouseSensetiveShapeEvent e)
    {
		int tileIndex=((MouseSensetiveTile)((MouseSensetiveShape [])(e.getSource()))[0]).getIndex();
		adjustedMouseX = e.getMouseEvent().getX();
		adjustedMouseY = e.getMouseEvent().getY();
		mouseX=adjustedMouseX;
		mouseY=adjustedMouseY;

		ui.requestFocusInWindow();

		if(mouseCount==0)
		{
			/*if(dragIndex>=0)
			{
				//In case of second event on multi-button mouse
				mouseReleased(e.getMouseEvent());
			}
			else */
			if(selectedGroup>=0 && isTileSelected(tileIndex))
			{
				//Let the other mousePressed handler know that this has been caught
				dragging=true;
			}
			else
			{
				if(selectedGroup>=0)
				{
					clearSelection();
				}
				dragIndex=tileIndex;
				//Remove connected tiles from the background
				dragBounds=pickConnectedTiles(dragIndex,connectedTiles,dragBounds);
				dragAllowance=getDragAllowance(dragIndex,connectedTiles,dragBounds,dragAllowance);
				//Clean up - draw the background onto the foreground
				ui.erase(dragBounds);
				draw(dragBounds);
				ui.clear(dragBounds);
				ui.clearDragBuffer(dragBounds.width,dragBounds.height);
				drawDragBuffer(dragBounds,dragIndex,connectedTiles,false);	
				ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
				//Update the graphics
				ui.repaint(dragBounds);
			}
		}
		e.consume();
	}
    public void mouseReleased(MouseSensetiveShapeEvent e){}
	
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e)
	{
		if(mouseCount==0)
		{
			if(dragIndex<0)
			{
				if(!dragging&&selectedGroup>=0)
				{
					clearSelection();
				}
				if(selectedGroup<0)
				{
					dragBounds.x=e.getX();
					dragBounds.y=e.getY();
					dragBounds.width=0;
					dragBounds.height=0;
				}
			}
		}
		mouseCount++;
	}
	
	private Point cnPos=new Point();
	/**
	 * Checks if two tiles are in their correct relative positions, within the limits of the snap threshold
	 * @param tile1 tile to check against
	 * @param tile2 tile to check
	 * @param correction storage for the return value
	 * @return The x and y translation factors required to correct tile2's position relative to tile1
	 */
	private Point checkNeighbors(MouseSensetiveTile tile1, MouseSensetiveTile tile2,Point correction)
	{
		Point result = null;
		//Get pixel offset
		int dX = (tile2.getX() - tile1.getX());
		int signX = dX<0?-1:1;
		//convert to index offset
		dX = (dX + signX*(tileSpacingX/2))/(tileSpacingX);
		
		//Get pixel offset
		int dY = (tile2.getY() - tile1.getY());
		int signY = dY<0?-1:1;
		//Convert to index offset
		dY = (dY + signY*(tileSpacingY/2))/(tileSpacingY);
		//Check if it is the correct neighbor for its position
		cnPos.x=dX;cnPos.y=dY;
		int index = tileManager.getNeighborIndex(tile1.getTileIndex(),cnPos);
		int index2 = tile2.getTileIndex();
		if(index >-1 && index==index2 && tileManager.getRotation(tile1.getTileIndex()) == tileManager.getRotation(index2))
		{
			//There is a neighbor on that side, it's index matches, and rotation is the same
			int adjustX = tile2.getX() - dX*tileSpacingX - tile1.getX();
			int adjustY = tile2.getY() - dY*tileSpacingY - tile1.getY();
			//Check if the tiles are close enough to 'snap'
			if(-snapThreshold < adjustX && adjustX < snapThreshold && -snapThreshold < adjustY && adjustY < snapThreshold)
			{
				result=correction;
				result.x=adjustX;
				result.y=adjustY;
			}
		}
		return result;
	}
	
	private void adjustTiles(ConnectedSet indices, int group, Point offset)
	{
		indices.setGroup(group);
		for(int i=indices.getNext();i>=0;i=indices.getNext())
		{
			tiles[i].moveTo(tiles[i].getX()+offset.x,tiles[i].getY()+offset.y);
		}
	}

	private Rectangle mrBounds=new Rectangle();
	private Rectangle mrBounds2=new Rectangle();
	private Point mrPos=new Point();
	public void mouseReleased(MouseEvent e)
	{
		mouseCount--;
		if(mouseCount==0)
		{
			int tileCount;
			if(dragIndex>=0)
			{
				selectedTiles.reset();
				mrBounds=getConnectedBounds(dragIndex,connectedTiles,mrBounds);
				//Check each connected tile for neighbors
				int avgXOffset=0;
				int avgYOffset=0;
				connectedTiles.setGroup(dragIndex);
				//Loop through the whole connected set
				for(int i=connectedTiles.getNext(); i>=0; i=connectedTiles.getNext())
				{
					MouseSensetiveShape [] intersectingTiles = boardManager.getIntersectingShapes(tiles[i].getBounds());
					if(intersectingTiles != null)
					{
						for(int j=intersectingTiles.length-1; j>=0; j--)
						{
							//Find out if this tile lines up as a neighbor
							Point adjustment = checkNeighbors(tiles[i],(MouseSensetiveTile)intersectingTiles[j],mrPos);
							if(adjustment != null)
							{
								int jIndex=((MouseSensetiveTile)intersectingTiles[j]).getIndex();
								//Remove the tile and its neighbors from the board
								mrBounds.add(pickConnectedTiles(jIndex,connectedTiles,mrBounds2));
								//Keep track of the weighted average
								tileCount=connectedTiles.getGroupSize(jIndex);
								avgXOffset+=tileCount*adjustment.x;
								avgYOffset+=tileCount*adjustment.y;
								//Adjust the position
								adjustment.x*=-1;
								adjustment.y*=-1;
								adjustTiles(connectedTiles,jIndex,adjustment);
								//Add the tile and its neighbors to the list of tile sets that will be snapped together
								selectedTiles.connect(dragIndex,jIndex);
								if(j > 0)
								{
									//Reevaluate intersecting tiles - some may no longer be on the board
									intersectingTiles = boardManager.getIntersectingShapes(tiles[dragIndex].getBounds());
									j = intersectingTiles==null ? 0 : intersectingTiles.length;
								}
							}
						}
					}
				}

				//snap the sets together
				int prevSet=-1;
				selectedTiles.setGroup(dragIndex);
				for(int i=selectedTiles.getNext(); i>=0; i=selectedTiles.getNext())
				{
					if(prevSet >=0) connectedTiles.connect(prevSet,i);
					prevSet = i;
				}
				
				tileCount=connectedTiles.getGroupSize(dragIndex);

				if(tileCount==tiles.length)
				{
					finishGame();
				}
				else
				{
					//Center the result
					mrPos.x=avgXOffset/tileCount;
					mrPos.y=avgYOffset/tileCount;
					adjustTiles(connectedTiles,dragIndex,mrPos);
					dropConnectedTiles(dragIndex,connectedTiles);
					ui.erase(mrBounds);
					draw(mrBounds);
					ui.clear(mrBounds);
					ui.repaint(mrBounds);
					dragIndex=-1;
				}
			}
			else if(selectedGroup<0)
			{
				//Multi-select
				mrBounds=correctRectangle(dragBounds,mrBounds);
				setSelection(mrBounds);
				mrBounds.x-=1;mrBounds.y-=1;mrBounds.width+=2;mrBounds.height+=2;
				mrBounds.add(dragBounds);
				ui.clear(mrBounds);
				ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
				ui.repaint(mrBounds);
			}
			//reset the multi-select drag signal
			dragging=false;
		}
	}
	
	private Rectangle ssDragBounds=new Rectangle();
	private Rectangle ssDragAllowance=new Rectangle();
	/**
	 * dragBounds will be modified
	 */
	private void setSelection(Rectangle bounds)
	{
		//Selection is different from basic dragging
		// - The selected tiles remain "off" the board (in the foreground) between drags
		// - Event handling is never disabled for the selected tiles
		boolean boundsSet=false;
		selectedTiles.reset();
		selectedGroup=-1;
		int z=-1;
		MouseSensetiveShape [] intersectingTiles=boardManager.getIntersectingShapes(bounds);
		for(int i=intersectingTiles.length-1; i>=0; i--)
		{
			//Add connected group to the selection
			int index=((MouseSensetiveTile)intersectingTiles[i]).getIndex();
			z+=connectedTiles.getGroupSize(index);
			if(selectedGroup<0){selectedGroup=index;}
			else{selectedTiles.connect(index,selectedGroup);}

			//Remove connected group from the board and calculate bounds
			if(!boundsSet)
			{
				dragBounds=pickConnectedTiles(index,connectedTiles,dragBounds);
				dragAllowance=getDragAllowance(index,connectedTiles,dragBounds,dragAllowance);
				boundsSet=true;
			}
			else
			{
				ssDragBounds=pickConnectedTiles(index,connectedTiles,ssDragBounds);
				dragBounds.add(ssDragBounds);
				ssDragAllowance=getDragAllowance(index,connectedTiles,ssDragBounds,ssDragAllowance);
				dragAllowance.add(ssDragAllowance);
			}

			if(i > 0)
			{
				//Reevaluate intersecting tiles - some may no longer be on the board
				intersectingTiles = boardManager.getIntersectingShapes(bounds);
				i=intersectingTiles==null?0:intersectingTiles.length;
			}
		}
		ui.erase(dragBounds);
		draw(dragBounds);
		ui.clearDragBuffer(dragBounds.width,dragBounds.height);
		selectedTiles.setGroup(selectedGroup);
		for(int i=selectedTiles.getNext();i>=0;i=selectedTiles.getNext())
		{
			drawDragBuffer(dragBounds,i,connectedTiles,true);	
			connectedTiles.setGroup(i);
			for(int j=connectedTiles.getNext();j>=0;j=connectedTiles.getNext())
			{
				tiles[j].setZOrder(z--);
				boardManager.addShape(tiles[j]);
			}
		}
	}
	
	private void clearSelection()
	{
		selectedTiles.setGroup(selectedGroup);
		for(int i=selectedTiles.getNext();i>=0;i=selectedTiles.getNext())
		{
			connectedTiles.setGroup(i);
			for(int j=connectedTiles.getNext();j>=0;j=connectedTiles.getNext())
			{
				boardManager.removeShape(tiles[j]);
			}
			dropConnectedTiles(i,connectedTiles);
		}
		ui.erase(dragBounds);
		draw(dragBounds);
		ui.clear(dragBounds);
		ui.repaint(dragBounds);
		selectedGroup=-1;
	}
	
	/**
	 * Displays the finished puzzle right side up and centered.
	 */
	private void finishGame()
	{
		Rectangle bounds=new Rectangle();
		ui.removeMouseListener(this);
		ui.removeMouseMotionListener(this);
		gameComplete=true;
		int rs=tileManager.getRotationSteps();
		int rotationSteps=tileManager.getRotationCount(0);
		bounds=getConnectedBounds(0,connectedTiles,bounds);

		adjustedMouseX=bounds.x;
		adjustedMouseY=bounds.y;
		if(rotationSteps>0) moveTiles(0,connectedTiles,adjustedMouseX,adjustedMouseY,TileManager.SPIN_CCW*rotationSteps);

		dragBounds=getConnectedBounds(0,connectedTiles,dragBounds);
		ui.clearDragBuffer(dragBounds.width,dragBounds.height);
		drawDragBuffer(dragBounds,0,connectedTiles,false);

		dragBounds.x=(boardBounds.width-tileManager.getBoardWidth())/2;
		dragBounds.y=(boardBounds.height-tileManager.getBoardHeight())/2;

		ui.erase(bounds);
		ui.clear(bounds);

		ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);

		bounds.add(dragBounds);
		ui.repaint(bounds);
	}
	
	
	/**
	 * Returns the bounding box of the connected set
	 * @param tileIndex index of a tile belonging to the connected set
	 * @param tileSet ConnectedSet defining the group of tiles
	 * @param result storage for the return value
	 */
	private Rectangle getConnectedBounds(int tileIndex,ConnectedSet tileSet,Rectangle result)
	{
		boolean resultInitialized=false;
		tileSet.setGroup(tileIndex);
		//Find the bounding box of the connected set
		for(int i=tileSet.getNext(); i>=0; i=tileSet.getNext())
		{
			Rectangle bounds = tiles[i].getBounds();
			if(resultInitialized)
			{
				result.add(bounds);
			}
			else
			{
				resultInitialized=true;
				copyRect(bounds,result);
			}
		}
		if(result!=null)
		{
			result.x -= errMargin;
			result.y -= errMargin;
			result.width += errMargin*2;
			result.height += errMargin*2;
		}
		return result;
	}
	
	private Rectangle mdBounds=new Rectangle();
	private Rectangle mdBounds2=new Rectangle();
	public void mouseDragged(MouseEvent e)
	{
		mouseX = e.getX();
		mouseY = e.getY();
		if(dragIndex>=0)
		{
			//Move connected group
			copyRect(dragBounds,mdBounds);
			moveTiles(dragIndex,connectedTiles,mouseX,mouseY,0);
			ui.clear(mdBounds);
			ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
			mdBounds.add(dragBounds);
			ui.repaint(mdBounds);
		}
		else if(selectedGroup>=0)
		{
			//Move multi-selection
			copyRect(dragBounds,mdBounds);
			adjustDragCoords(mouseX,mouseY);
			selectedTiles.setGroup(selectedGroup);
			for(int i=selectedTiles.getNext();i>=0;i=selectedTiles.getNext())
			{
				connectedTiles.setGroup(i);
				for(int j=connectedTiles.getNext();j>=0;j=connectedTiles.getNext())
				{
					boardManager.removeShape(tiles[j]);
					tiles[j].moveTo(tiles[j].getX() + dX, tiles[j].getY() + dY);
					boardManager.addShape(tiles[j]);
				}
			}
			ui.clear(mdBounds);
			ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
			mdBounds.add(dragBounds);
			ui.repaint(mdBounds);
		}
		else
		{
			//Adjust multi-select region
			mdBounds=correctRectangle(dragBounds,mdBounds);
			mdBounds.x-=1;mdBounds.y-=1;mdBounds.width+=2;mdBounds.height+=2;
			dragBounds.width=mouseX-dragBounds.x;
			dragBounds.height=mouseY-dragBounds.y;
			mdBounds2=correctRectangle(dragBounds,mdBounds2);
			ui.clear(mdBounds);
			ui.drawRect(mdBounds2,PuzzleCanvas.DRAW_FOREGROUND);
			mdBounds2.x-=1;mdBounds2.y-=1;mdBounds2.width+=2;mdBounds2.height+=2;
			mdBounds.add(mdBounds2);
			ui.repaint(mdBounds);
		}
	}
	
	private Point mtPoint=new Point();
	/**
	 * Positions and rotates a set of tiles, adjusting the dragbuffer and dragbounds accordingly
	 */
	private void moveTiles(int tileIndex,ConnectedSet tileSet,int x,int y,int rotateDirection)
	{
		if(rotateDirection!=0)
		{
			double rotationStep = tileManager.getRotationStep();
			//Rotate around the center of the selection
			AffineTransform rot = AffineTransform.getRotateInstance(rotateDirection*rotationStep,adjustedMouseX,adjustedMouseY);
			
			tileSet.setGroup(tileIndex);
			for(int i=tileSet.getNext(); i>=0; i=tileSet.getNext())
			{
				tileManager.rotate(tiles[i].getTileIndex(),rotateDirection);
				mtPoint.x=tiles[i].getX() + tileSize/2 + errMargin;mtPoint.y=tiles[i].getY() + tileSize/2 + errMargin;
				rot.transform(mtPoint,mtPoint);
				tiles[i].moveTo(mtPoint.x - tileSize/2 - errMargin,mtPoint.y - tileSize/2 - errMargin);
			}

			int x1 = tiles[tileIndex].getX();
			int y1 = tiles[tileIndex].getY();
			//Realign tiles to fix rotation errors
			tileSet.setGroup(tileIndex);
			boolean boundsSet=false;
			for(int i=tileSet.getNext(); i>=0; i=tileSet.getNext())
			{
				int x2 = tiles[i].getX();
				int y2 = tiles[i].getY();
				int dX = (x2 - x1 + (x2>x1 ? 1 : -1)*tileSpacingX/2)/tileSpacingX;
				int dY = (y2 - y1 + (y2>y1 ? 1 : -1)*tileSpacingY/2)/tileSpacingY;
				tiles[i].moveTo(x1 + dX*tileSpacingX,y1 + dY*tileSpacingY);
			}
			dragBounds=getConnectedBounds(tileIndex,tileSet,dragBounds);
			dragAllowance=getDragAllowance(tileIndex,tileSet,dragBounds,dragAllowance);
			ui.clearDragBuffer(dragBounds.width+errMargin*2,dragBounds.height+errMargin*2);
			drawDragBuffer(dragBounds,dragIndex,connectedTiles,false);
		}

		adjustDragCoords(x,y);

		tileSet.setGroup(tileIndex);
		for(int i=tileSet.getNext(); i>=0; i=tileSet.getNext())
		{
			tiles[i].moveTo(tiles[i].getX() + dX, tiles[i].getY() + dY);
		}
	}
	
	private void adjustDragCoords(int x, int y)
	{
		int minX=adjustedMouseX-dragAllowance.x;
		int minY=adjustedMouseY-dragAllowance.y;
		int maxX=boardBounds.width+adjustedMouseX-dragAllowance.x-dragAllowance.width;
		int maxY=boardBounds.height+adjustedMouseY-dragAllowance.y-dragAllowance.height;
		x = x<minX?minX:x<maxX?x:maxX;
		y = y<minY?minY:y<maxY?y:maxY;
		dX = x - adjustedMouseX;
		dY = y - adjustedMouseY;
		adjustedMouseX = x;
		adjustedMouseY = y;
		dragBounds.x+=dX;
		dragBounds.y+=dY;
		dragAllowance.x+=dX;
		dragAllowance.y+=dY;
	}

	/**
	 * Rearranges corners so width and height are positive
	 */
	private Rectangle correctRectangle(Rectangle toCorrect,Rectangle result)
	{
		result.x=(toCorrect.width<0?toCorrect.x+toCorrect.width:toCorrect.x)-1;
		result.width=(toCorrect.width<0?toCorrect.width*-1:toCorrect.width)+2;
		result.y=(toCorrect.height<0?toCorrect.y+toCorrect.height:toCorrect.y)-1;
		result.height=(toCorrect.height<0?toCorrect.height*-1:toCorrect.height)+2;
		return result;
	}


	public void mouseMoved(MouseEvent e){}
	
	private Rectangle kpBounds=new Rectangle();
	public void keyPressed(KeyEvent e)
	{
		int keyCode=e.getKeyCode();
		switch(keyCode)
		{
			case KeyEvent.VK_LEFT:
			case KeyEvent.VK_RIGHT:
				if(dragIndex>=0)
				{
					copyRect(dragBounds,kpBounds);
					moveTiles(dragIndex,connectedTiles,mouseX,mouseY,keyCode==KeyEvent.VK_LEFT?TileManager.SPIN_CCW:TileManager.SPIN_CW);
					//Redraw
					ui.clear(kpBounds);
					ui.drawTile(dragBounds,null,PuzzleCanvas.DRAW_DRAGBUFFER,PuzzleCanvas.DRAW_FOREGROUND);
					kpBounds.add(dragBounds);
					ui.repaint(kpBounds);
				}
				break;
		}
	}

	public void keyReleased(KeyEvent e){}
	
	public void keyTyped(KeyEvent e){}
}
