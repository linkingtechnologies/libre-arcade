/**
 *   Copyright (C) 2010  Jonathan Hulka
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Changelog
 * 2010 07 08 - Jon
 * - Changed 'game' menu to 'file'
 * - Created puzzle menu for game options
 *   - Layers
 *   - Background color
 *   - Preview
 * Moved control of layers and preview to menu level
 * Integrated color chooser for background color selection and made necessary changes to PuzzleCanvas and PuzzleHandler
 * 2010 06 16 - Jon
 * Began retrofitting to use ConnectedSet - ConnectedSet requires some debugging
 * 2010 06 14 - Jon
 * Finished reintegrating into the new structure.
 * 20100611 - Jon
 * Moved tile drawing code into PuzzleCanvas
 * 20100607 - Jon
 * Upgraded menu building and handling code to use GUILoader
 * The Nimbus look and feel is now used, if available
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;

import javax.swing.UIManager;
	import javax.swing.UIManager.*;

import hulka.event.*;
import hulka.graphics.*;
import hulka.gui.*;
import hulka.util.JVMVersion;

class GUI
{
	Dimension boardSize=null;
	JScrollPane boardPane=null;
	PuzzleCanvas boardCanvas=null;
	JFrame frame=null;
	NewPuzzleDialog newDialog=null;
	PuzzleHandler puzzleHandler=null;
	GUILoader guiLoader=null;
	
	public static void main(String [] args)
	{
		JVMVersion version = new JVMVersion();
		if(version.check(1,6,0))
		{
			// turn on anti-aliasing for smooth fonts.
			System.setProperty( "swing.aatext", "true" );
			// try to load Nimbus look and feel
			try {
				for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
					if ("Nimbus".equals(info.getName())) {
						UIManager.setLookAndFeel(info.getClassName());
						break;
					}
				}
			} catch (Exception ex){}
			GUI ui = new GUI();
		}
		else
		{
			JOptionPane.showMessageDialog(null,
				"You must have Java version 1.6 to run this program.\nYour version is " + version.getMajor() + "." + version.getMinor() + ".\nPlease upgrade at www.java.com",
				"Invalid JVM version", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public GUI()
	{
		if(buildGui()) showGui();
	}
	
	private boolean buildGui()
	{
		boolean result = false;
		guiLoader = new GUILoader("gui.xml");
		if(guiLoader.loadGUI())
		{
			result=false;
			try
			{
				newDialog=new NewPuzzleDialog(frame);
			}catch(Exception ex){ex.printStackTrace();}
			frame = guiLoader.getFrame();
			GameMenuListener gml=new GameMenuListener(this);
			guiLoader.getActionCoordinator().addActionListener("game",gml);
			FileMenuListener fml=new FileMenuListener(this);
			frame.addWindowListener(fml);
			guiLoader.getActionCoordinator().addActionListener("file",fml);
			
			boardPane=new JScrollPane();
			boardPane.setPreferredSize(new Dimension(550,350));
			frame.setContentPane(boardPane);
			
			frame.pack();
			frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			result=true;
		}
		return result;
	}

	private void showGui()
	{
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setVisible(true);
		Rectangle area=null;
//To do: find out if there is a better way to do this, rather than waiting for resize.
		//Assuming there is enough space for at least 600px across
		//Wait for resizing to occur
		while(area==null||area.width<600)
		{
			try{Thread.sleep(10);}catch(Exception ex){}
			area=SwingUtilities.calculateInnerArea(boardPane,area);
		}
		boardSize=new Dimension(area.width,area.height);
		boardCanvas=new PuzzleCanvas(boardSize);
		boardPane.setViewportView(boardCanvas);

		guiLoader.showDocument("credits");
	}

	public boolean closeGame()
	{
		boolean ok=false;
//To do: once save and load are implemented, integrate a gamesaved flag
		if(puzzleHandler==null||puzzleHandler.isGameComplete()||puzzleHandler.isGameSaved())
		{
			if(puzzleHandler!=null)puzzleHandler.disconnect();
			ok=true;
		}
		else if(JOptionPane.showConfirmDialog(frame,"Close current game?","Closing Game.",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION)
		{
			puzzleHandler.disconnect();
			puzzleHandler=null;
			ok=true;
		}
		return ok;
	}
	
	public void startGame()
	{
		newDialog.setVisible(true);
		if(newDialog.getResponse()==NewPuzzleDialog.RESPONSE_OK && closeGame())
		{
			puzzleHandler=newDialog.getPuzzleHandler(boardSize);
			boardCanvas.setPuzzleImage(newDialog.getScaledImage(boardSize));
			puzzleHandler.connect(boardCanvas);
		}
	}
	
	public void loadGame()
	{
			JOptionPane.showMessageDialog(null,
				"Feature not implemented yet",
				"Load Game", JOptionPane.ERROR_MESSAGE);
	}
	
	public void saveGame()
	{
			JOptionPane.showMessageDialog(null,
				"Feature not implemented yet",
				"Save Game", JOptionPane.ERROR_MESSAGE);
	}
	
	public void quit()
	{
		if(closeGame())
		{
			frame.setVisible(false);
			frame.dispose();
			System.exit(0);
		}
	}
	
	public void showPreview(){if(boardCanvas!=null&&puzzleHandler!=null) boardCanvas.showPreview();}
	
	public void chooseColor(){if(boardCanvas!=null)boardCanvas.chooseColor(frame);if(puzzleHandler!=null)puzzleHandler.redraw();}
	
	public void setLayer(int layer)
	{
		if(puzzleHandler!=null&&puzzleHandler instanceof JigsawHandler)
		{
			((JigsawHandler)puzzleHandler).setLayer(layer);
		}
	}
}
